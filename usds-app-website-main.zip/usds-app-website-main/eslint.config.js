import js from '@eslint/js'
import globals from 'globals'
import reactHooks from 'eslint-plugin-react-hooks'
import reactRefresh from 'eslint-plugin-react-refresh'
import tseslint from 'typescript-eslint'
import { globalIgnores } from 'eslint/config'

export default tseslint.config([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      js.configs.recommended,
      tseslint.configs.recommended,
      reactHooks.configs['recommended-latest'],
      reactRefresh.configs.vite,
    ],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
  },
  {
    files: ['src/**/*.{ts,tsx}'],
    ignores: ['src/constants/stakingVaultConfig.ts', 'src/config/env.ts'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          paths: [
            {
              name: '@/config/env',
              importNames: ['STAKING_TX_HISTORY_ORIGIN'],
              message:
                'Use stakingTxHistoryUrl() from @/constants/stakingVaultConfig instead.',
            },
          ],
        },
      ],
    },
  },
  {
    files: ['src/staking/runtime/**/*.{ts,tsx}'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              group: ['@/components/*', '@/staking/ui', '@/staking/vault/composer'],
              message: 'staking/runtime must not import UI, components, or vault composer',
            },
          ],
        },
      ],
    },
  },
  {
    files: ['src/staking/execution/**/*.{ts,tsx}'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              group: ['@/components/*', '@/staking/ui'],
              message: 'staking/execution must not import components or presentation UI',
            },
          ],
        },
      ],
    },
  },
  {
    files: ['src/staking/tx/**/*.{ts,tsx}'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              group: [
                '@/components/pages/staking/*',
                '@/staking/ui',
                '@/staking/refresh/*',
              ],
              message:
                'staking/tx must not import presentation components or refresh internals (use @/staking/tx/types; callbacks from composer)',
            },
          ],
        },
      ],
    },
  },
  {
    files: ['src/staking/refresh/**/*.{ts,tsx}'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              group: ['@/components/*', '@/staking/ui'],
              message: 'staking/refresh must not import UI or components',
            },
            {
              group: ['@/staking/runtime/network', '@/staking/runtime/network/*'],
              message:
                'staking/refresh must not import network glue (orchestrator-only; G4d)',
            },
          ],
        },
      ],
    },
  },
  {
    files: ['src/staking/history/**/*.{ts,tsx}'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              group: ['@/components/*', '@/staking/ui'],
              message: 'staking/history must not import UI or components',
            },
            {
              group: ['@/staking/runtime/network', '@/staking/runtime/network/*'],
              message:
                'staking/history must not import network glue (history-only; G4d)',
            },
          ],
        },
      ],
    },
  },
  {
    files: ['src/staking/orchestration/**/*.{ts,tsx}'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              group: ['@/components/*', '@/staking/ui'],
              message:
                'staking/orchestration must not import UI or components',
            },
          ],
        },
      ],
    },
  },
  {
    files: [
      'src/staking/history/**/*.{ts,tsx}',
      'src/staking/refresh/**/*.{ts,tsx}',
      'src/staking/runtime/network/**/*.{ts,tsx}',
      'src/staking/vault/composer/**/*.{ts,tsx}',
      'src/staking/core/runtimeSelectionContext.tsx',
      'src/hooks/useStakingGasEstimate.ts',
      'src/hooks/useWithdrawalProtocolFee.ts',
      'src/hooks/useStakingVault.ts',
    ],
    rules: {
      'react-hooks/exhaustive-deps': 'off',
    },
  },
  {
    files: ['src/staking/**/*.{ts,tsx}'],
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              group: ['@/lib/staking/*', '@/lib/tron/*'],
              message: 'Use canonical @/staking/* paths (legacy lib shims removed)',
            },
          ],
        },
      ],
    },
  },
])
