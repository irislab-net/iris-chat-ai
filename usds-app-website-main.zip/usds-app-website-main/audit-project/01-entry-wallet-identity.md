# Phase 01 — Entry & Wallet Identity

**Status:** Complete (audit only)  
**Route under test:** `/staking/app`  
**Date:** 2026-05-30

---

## Scope

Audit of staking app entry from first paint through wallet identity stabilization:

- First page load and bootstrap gating
- AppKit singleton readiness vs WalletConnect session hydration
- Disconnected / connecting / reconnecting visual states
- First-time connect and reconnect-on-refresh
- Manual disconnect and stale WC restore suppression
- In-wallet account switch (Trust Wallet)
- Disconnect A → switch to B → connect B
- Wrong network and chain change during load
- Source-of-truth for wallet identity across navbar, form, balances, reads, and tx persistence

**Out of scope:** Code changes, tx execution internals, hook dependency warnings.

---

## Components / files inspected

| Layer | Files |
|---|---|
| **Route & bootstrap** | `src/routes.tsx`, `src/lib/lazyAfterAppKit.ts`, `src/components/layout/AppKitRouteGate.tsx`, `src/providers/AppKitReadyProvider.tsx`, `src/providers/BootstrapOrchestrationProvider.tsx`, `src/components/layout/InitialSplashOverlay.tsx`, `src/contexts/BootstrapReadinessContext.tsx` |
| **App shell** | `src/components/pages/staking/StakingApp.tsx`, `StakingVaultProvider.tsx`, `StakingAppForm.tsx`, `StakingAppBalance.tsx`, `StakingAppNetworkChip.tsx` |
| **Raw AppKit hooks** | `src/hooks/useWallet.tsx`, `useEtheriumWallet.tsx`, `useAppKitHookReadyGuard.ts`, `useAppKitEvmIsolationOnPassiveTron.ts` |
| **Effective identity** | `src/hooks/useWalletAccountIdentityGuard.ts`, `src/lib/wallet/walletAccountIdentityOrchestrator.ts`, `src/lib/wallet/walletManualDisconnectGuard.ts`, `src/lib/wallet/appKitSessionHydrationObserve.ts`, `src/lib/wallet/walletAccountIdentityTelemetry.ts` |
| **Runtime publish (navbar)** | `src/staking/runtime/useStakingVaultRuntimePlanes.ts`, `src/staking/identity/stakingRuntimeWalletIdentity.ts`, `stakingRuntimeWalletIdentityBridge.ts`, `stakingNavbarVisualHold.ts` |
| **Vault composer** | `src/hooks/useStakingVault.ts`, `stakingVaultPublicAssembly.ts`, `useStakingVaultRefreshPlane.ts`, `useStakingVaultBalanceRefresh.ts`, `useStakingVaultTokenReads.ts`, `stakingVaultDerivedFlags.ts` |
| **Forms & lifecycle** | `StakingAppDepositForm.tsx`, `StakingAppWithdrawForm.tsx`, `src/hooks/useStakingFormLifecycle.ts` |
| **Tx persistence** | `TransactionStatusProvider.tsx`, `stakingTxSessionPersistence.ts` |
| **Navbar wallet UI** | `src/components/layout/NavbarWalletSection.tsx` |
| **Connect orchestration** | `openUnifiedWallet.ts`, `useUnifiedWalletOrchestration.ts` |
| **Diagnostics / traces** | `installMobileStakingWcSessionTrace.ts`, `mobileStakingLanLog.ts`, `useStakingConnectStallWatchdog.ts` |

---

## Current behavior

### Entry sequence (`/staking/app`)

1. **Route gate:** `lazyAfterAppKit` awaits `initializeAppKit()` before loading the `StakingApp` chunk. `AppKitRouteGate` shows `BrandLoadingMark` until `AppKitReadyProvider` latches `ready === true` (AppKit singleton committed).
2. **Splash overlay:** `InitialSplashOverlay` waits for `appKitReady && stakingVaultHydratedForSplash`. On staking route, vault reports hydration via `StakingVaultProvider` → `vaultDataReady`.
3. **WC observation:** On AppKit init, `observeAppKitSessionHydrationOnStartup()` starts a **12s hydration grace** window and telemetry; read-only, never resets sessions.
4. **Vault mount:** `StakingVaultProvider` → `useStakingVaultState()` → `useStakingVaultRuntimePlanes()` wires identity, reads, balances, tx gates.

### Identity pipeline (EVM staking)

```
useAppKitAccount({ namespace: "eip155" })          ← raw AppKit
        │
        ▼
useWalletAccountIdentityGuard()                     ← hydration settle + disconnect side-effects
        │
        ▼
resolveEffectiveEvmWalletIdentity()                 ← manual-disconnect guard + pre-settle block
        │
        ├── executionAddress / executionConnected   ← forms, affiliate, tx persistence match
        │
        ▼
resolveStakingRuntimeWalletIdentity()               ← runtimeWallet / stakingOwnerAddress
        │
        ├── publishStakingRuntimeWalletIdentity()   ← navbar on /staking/app
        └── runtimeWalletAddress                    ← balance/history reads
```

**Parallel path:** `useEtheriumWallet` reads **raw** AppKit address for EIP-1193 provider/signer hydration. `canTransact` requires **guarded** `executionConnected` + `executionAddress` + signer.

### Hydration settle timing

- `useWalletAccountIdentityGuard` sets `hydrationSettled` when `!isWithinAppKitHydrationGrace()` **or** after a **12.5s** timer (whichever fires first on mount).
- Until settled, if AppKit reports connected, `resolveEffectiveEvmWalletIdentity` **forces** `effectiveConnected: false` and `effectiveAddress: undefined` (telemetry: `local_wallet_address_ignored_until_appkit_ready`).

### Manual disconnect guard

- Stored in `sessionStorage` key `waddle_wallet_manual_disconnect_guard_v1`, **30 min TTL**.
- When guard active and AppKit restores the **same** address after settle → identity suppressed (disconnected UX).
- When AppKit shows a **different** address → guard cleared automatically (`live_appkit_new_account`).
- Explicit connect gesture (`noteWalletFreshConnectGesture` via `useWallet.open` / `openUnifiedWallet`) clears guard.

### AppKit disconnect side-effect

When `useWalletAccountIdentityGuard` detects `prevConnected && !appKitConnected` (status `disconnected` or transition from `connected`), it calls `performWalletManualDisconnect()` — sets guard **and** calls `appKit.disconnect("eip155")`. **No `hydrationSettled` guard** on this path.

### Navbar vs form on `/staking/app`

- Navbar uses `usePublishedStakingRuntimeWalletIdentity(true)` (published runtime), **not** raw AppKit.
- **`isLoading` is hardcoded false** on staking app (`useStakingAppNavbarWallet`: `isLoading = useRuntimeIdentity ? false : appKit.isLoading`).
- Visual anti-flicker: `STAKING_NAV_VISUAL_HOLD_MS` (**1200ms**) can keep last connected chip during transient identity gaps.

### Transaction snapshot owner

- Persisted in `sessionStorage` (`waddle_staking_tx_session_v1`).
- Restore gated by `sessionMatchesAccount(row, executionAddress, executionChainId)` — uses **effective** execution address, not raw AppKit.
- Mismatch → session cleared (`persisted_wallet_mismatch_on_restore`).

### Wrong network

- `selectIsWrongNetwork`: EVM requires `executionConnected`, correct namespace, `numericChainId !== expectedChainId`.
- `canTransact` false; CTA switches to network action via `openUnifiedWallet` Networks view.
- `selectVaultDataReady` returns **true** when wrong network (does not block splash on network alone).

---

## Expected UX

| Moment | Expected |
|---|---|
| Cold load, no wallet | “Connect Wallet” in navbar and form; balances empty/zero; no flash of prior address |
| AppKit / WC hydrating | Clear “connecting/reconnecting” or stable skeleton; no stale address; no submit until identity settled |
| Valid WC restore on refresh | Seamless reconnect; same address in navbar, form meta, and balances |
| Manual disconnect + refresh | Stay disconnected until user explicitly connects; no silent WC restore of old account |
| Account switch in wallet | Immediate identity update across toolbar, form, balances; in-flight tx protected |
| Wrong network | Prominent switch-network CTA; no stake/unstake until corrected |
| Active tx + identity change | Tx modal stays authoritative; no new submit for wrong account |

---

## Wallet identity state matrix

| State | Raw AppKit (`eip155`) | Effective identity | Runtime publish (navbar) | Staking reads | Tx submit gate |
|---|---|---|---|---|---|
| AppKit not ready | unavailable | unavailable | empty | idle / zero | blocked (no vault) |
| WC hydrating, unsettled | `connecting` / connected | **forced disconnected** | empty or visual hold | gated off (`executionConnected` false) | `canTransact` false |
| WC hydrating, settled, no guard | connected + address | address applied | published address | keyed to `runtimeWalletAddress` | blocked until signer + meta |
| Disconnected | disconnected | disconnected | disconnected | zero / dash | blocked |
| Manual disconnect guard + same restore | connected + same addr | **suppressed disconnected** | disconnected (unless visual hold) | zero / gated | blocked |
| Manual disconnect guard + new addr B | connected + B | B (guard cleared) | B | B reads | normal gates |
| Wrong network | connected | connected | connected chip possible | meta may error; `vaultDataReady` true | `canTransact` false |
| Account switch A→B | B | B (immediate) | B after publish | reset key changes → balances cleared | `canTransact` recalculated |
| Tron passive runtime | eip155 isolated/disconnected | Tron passive / unified | Tron identity | Tron base58 reads | Tron path (out of EVM table) |

---

## Connect / reconnect state matrix

| Scenario | AppKit status | Navbar branch | Form CTA | Balance card | Notes |
|---|---|---|---|---|---|
| 1. No wallet | `disconnected` | disconnected | Connect | zero / not connected dash | Stable |
| 2. AppKit not ready | n/a | route gate loading | not mounted | not mounted | `AppKitRouteGate` |
| 3. WC hydrating (unsettled) | `connecting` / connected | **disconnected** (no spinner) | Connect | zero | Up to ~12.5s false disconnected |
| 4. WC restore (settled) | connected | connected (or 1.2s hold) | enabled path | loads for address | Expected happy path |
| 5. Manual disconnect + refresh | may reconnect internally | disconnected if guard suppresses | Connect | zero | User must tap Connect |
| 6. Switch in Trust Wallet | connected, new addr | updates after publish | brief window then reset | reset on address key | 600ms form debounce |
| 7. WC restore old addr after disconnect | connected, old addr | guard → disconnected | Connect | zero | Guard works |
| 8. AppKit connected, effective guarded | connected | **may show connected** (hold) | Connect | zero | Toolbar/form mismatch risk |
| 11. Wrong network | connected | connected (amber warning on Tron) | Switch network | gated / ready flag | EVM switch via AppKit |
| 12. Chain change on load | connected | connected | amount kept (EVM) | balance reset | `useStakingFormLifecycle` |

---

## Account mismatch risks

| Risk | Likelihood | Mitigation today | Residual |
|---|---|---|---|
| Raw AppKit address ≠ effective address | Medium during guard/hydration | Reads/forms use effective; `canTransact` uses effective | Signer hydrates on raw AppKit (blocked from submit) |
| Navbar shows A, form uses B | Low–Medium | Publish bridge from same runtime planes | **1.2s visual hold** can show stale A while form disconnected |
| Persisted tx session for A, live wallet B | Medium on switch | `sessionMatchesAccount` clears session | User loses in-flight modal on mismatch (intentional) |
| Affiliate / PnL for wrong wallet | Low | `useAffiliateFirestoreStats(executionAddress)` | Clears when effective address changes |
| History for wrong wallet | Low | History keyed to `stakingOwnerAddress` / runtime | Refetch on identity change |
| Account switch during active signature | Medium | Form `onWalletDisconnect` **defers** reset during approval/deposit signature tracks | Identity guard does not receive `hasActiveTx`; telemetry only in `useEtheriumWallet` |

---

## Stale account restore risks

| Vector | Guarded? | Mechanism |
|---|---|---|
| WC auto-restore after user disconnect | **Yes** (same address) | `walletManualDisconnectGuard` + `stale_account_restore_suppressed_by_disconnect_guard` |
| WC restore before hydration settled | **Yes** | Pre-settle block in `resolveEffectiveEvmWalletIdentity` |
| WC restore different account without user gesture | Partial | New address clears guard; user did not explicitly disconnect B |
| Persisted tx session reviving wrong wallet | **Yes** | `sessionMatchesAccount` + precheck trace `account_restore_mismatch_detected` |
| Navbar flash of old address | Partial | 1200ms visual hold **intentionally** retains last chip |
| Balance flash of old wallet | **Low** | `vaultBalanceResetKey` uses `executionAddress`; `balanceViewReady` false when disconnected |
| Local persisted wallet address (non-AppKit) | N/A | **No separate localStorage wallet address** — only guard row + tx session rows in sessionStorage |

---

## Files / components ownership map

| Concern | Owner | Consumers |
|---|---|---|
| Raw AppKit account | `@reown/appkit/react` hooks | `useWallet`, `useEtheriumWallet`, runtime planes input |
| Effective EVM identity | `walletAccountIdentityOrchestrator` + `useWalletAccountIdentityGuard` | `useStakingVaultRuntimePlanes`, forms, tx provider |
| Manual disconnect guard | `walletManualDisconnectGuard` (sessionStorage) | orchestrator resolve + disconnect perform |
| Runtime identity publish | `stakingRuntimeWalletIdentityBridge` | `NavbarWalletSection` on `/staking/app` |
| Navbar visual hold | `stakingNavbarVisualHold` + `useStakingNavbarVisualIdentity` | Navbar chip only |
| Staking read address | `runtimeWalletAddress` / `stakingOwnerAddress` | balances, history, token reads |
| Tx execution address | `executionAddress` (guarded) | deposit/withdraw, persistence match, affiliate |
| Signer / provider | `useEtheriumWallet` (**raw** AppKit) | `canTransact`, gas, submit |
| Connect CTA | `openUnifiedWallet` via vault / navbar | Clears guard on gesture |
| Tx snapshot owner | `TransactionStatusProvider` + `stakingTxSessionPersistence` | Modal/toast rehydrate |
| WC session topic (read-only) | `observeAppKitSessionSnapshot` | Diagnostics / LAN log |
| EIP-1193 events | `useEtheriumWallet` (`accountsChanged` only) | Telemetry; no direct UI mutation |

---

## Issues found

| ID | Severity | Area | Scenario | Expected UX | Actual UX | Risk | Evidence | Suggested fix direction | Files |
|---|---|---|---|---|---|---|---|---|---|
| P01-001 | **P1** | Hydration | 4 — WC restore on refresh | Returning user sees connected state within ~1–2s | Effective identity **forced disconnected** until hydration settles (up to **12.5s**); Connect CTA shown despite valid WC session | Blocked user, unnecessary reconnect tap | `resolveEffectiveEvmWalletIdentity` L101–112; guard timer L37–38 in `useWalletAccountIdentityGuard`; 12s grace in `appKitSessionHydrationObserve` | Differentiate “session restoring” from “never connected”; allow settled restore earlier when AppKit status is `connected` + address stable; surface reconnecting state in form **and** navbar | `walletAccountIdentityOrchestrator.ts`, `useWalletAccountIdentityGuard.ts`, form CTA copy |
| P01-002 | **P1** | Navbar | 3, 8 — hydrating / guarded disconnect | Connecting or disconnected clearly everywhere | On `/staking/app`, navbar **`isLoading` always false**; no “Connecting…” during WC restore | User thinks app is broken or disconnected only in form | `NavbarWalletSection.tsx` L260: `isLoading = useRuntimeIdentity ? false : appKit.isLoading` | Drive navbar loading from AppKit `status === "connecting"` **or** `!hydrationSettled && wcKeysPresent` even when using runtime identity | `NavbarWalletSection.tsx`, expose settle flag from guard |
| P01-003 | **P1** | Cross-surface | 8 — AppKit connected, effective guarded | Toolbar and form agree | Navbar **visual hold (1200ms)** may show connected chip while form shows **Connect** | Wrong-wallet perception | `stakingNavbarVisualHold.ts` L5; `NavbarWalletSection.tsx` L166–175 | When `suppressedByDisconnectGuard` or pre-settle, force navbar disconnected (skip hold) | `stakingNavbarVisualHold.ts`, orchestrator → publish bridge |
| P01-004 | **P1** | Disconnect guard | 5, 7 — manual disconnect / WC blip | Guard only on explicit user disconnect | **Any** AppKit disconnect edge triggers `performWalletManualDisconnect` (including transient WC / isolation) | Unexpected reconnect requirement; Trust WC churn | `useWalletAccountIdentityGuard.ts` L65–77; `performWalletManualDisconnect` | Gate auto-disconnect perform on explicit user action vs telemetry-only on transient drops; debounce disconnect during hydration | `useWalletAccountIdentityGuard.ts`, `walletAccountIdentityOrchestrator.ts` |
| P01-005 | **P2** | Account switch | 6 — switch inside Trust | Immediate consistent identity | Form reset debounced **600ms**; balance reset immediate on effective address | Brief window: new address + old amount/slider | `useStakingFormLifecycle.ts` L35, L154–167 | Reduce debounce for confirmed AppKit address change when not `connecting`; or reset amount immediately on effective address change | `useStakingFormLifecycle.ts`, deposit/withdraw forms |
| P01-006 | **P2** | Signer split | 9 — persisted vs AppKit | Single source of truth for all execution paths | `useEtheriumWallet` hydrates signer from **raw** AppKit while gates use **effective** identity | Confusing diagnostics; future bypass if gate regresses | `useEtheriumWallet.tsx` L44–45 vs `useStakingVaultRuntimePlanes.ts` L83–88 | Pass effective address into signer hydration or skip hydration when effective disconnected | `useEtheriumWallet.tsx`, runtime planes |
| P01-007 | **P2** | Active tx | 10 — tx active + account change | Block new tx; clear telemetry | Identity guard omits `hasActiveTx`; only `useEtheriumWallet` accountsChanged traces mismatch | Incomplete observability; relies on form deferral | Guard call site L83–86 no `hasActiveTx`; orchestrator L182–188 | Pass `isStakingTxModalActivityActive()` into guard; surface account-mismatch banner in tx modal | `useStakingVaultRuntimePlanes.ts`, `TransactionStatusProvider.tsx` |
| P01-008 | **P2** | Bootstrap | 2 — AppKit not ready | Single loading experience | `AppKitRouteGate` + `InitialSplashOverlay` can both show loaders sequentially | Double splash perception | `AppKitRouteGate.tsx`, `InitialSplashOverlay.tsx`, `BootstrapOrchestrationProvider.tsx` | Coordinate gates or dismiss route gate once shell splash owns bootstrap | layout providers |
| P01-009 | **P2** | Wrong network | 11 — wrong network before interact | Switch network CTA stable | `vaultDataReady` true when wrong network; balance card may show ready state while network wrong | Minor confusion on loading semantics | `selectVaultDataReady` L44 in `stakingVaultDerivedFlags.ts` | Distinct `networkReady` vs `vaultDataReady` in balance skeleton copy | selectors, `StakingAppBalance.tsx` |
| P01-010 | **P3** | Tron isolation | EVM session on Tron runtime | Clean Tron identity | `AppKitEvmIsolationOnPassiveTron` disconnects eip155 on Tron entry → may trigger manual disconnect guard side-effects | EVM users switching runtime may see guard | `useAppKitEvmIsolationOnPassiveTron.ts` L119–120 | Exclude programmatic isolation from manual-disconnect guard | isolation hook + identity guard |
| P01-011 | **P3** | Diagnostics | WC session topic | Trace available in dev | `.local-debug/mobile-staking.ndjson` empty in workspace; LAN log requires env flag | Harder field audit | `mobileStakingLogEnv.ts`, empty ndjson | Populate traces during manual QA runs (no code change required for audit) | diagnostics config |

---

## Scenario checklist (audit scenarios 1–12)

| # | Scenario | Old wallet too early? | Form stale address? | Wrong balance wallet? | Toolbar = form? | Connect CTA stable? | States visually clear? | Guard blocks restore? | New tx blocked when uncertain? |
|---|---|---|---|---|---|---|---|---|---|
| 1 | No wallet | No | No | No | Yes | Yes | Yes | n/a | Yes |
| 2 | AppKit not ready | No | n/a | n/a | n/a | n/a | Partial (double loader) | n/a | Yes |
| 3 | WC hydrating | **Possible (navbar hold)** | No (effective empty) | No | **No** | Misleading (Connect while restoring) | **No** | Yes (pre-settle) | Yes |
| 4 | WC reconnect | After settle: No | No | No | Mostly | Yes after settle | **Poor until settle** | n/a | Yes until signer ready |
| 5 | Manual disconnect + refresh | No | No | No | Mostly | Yes | Guard ok; **no reconnecting hint** | **Yes** | Yes |
| 6 | Account switch in Trust | No | Brief amount lag | No | Yes after publish | Yes | Partial (debounce) | n/a | Yes during signer regen |
| 7 | WC restores old after disconnect | **Hold risk** | No | No | **Possible mismatch** | Connect (correct) | Confusing if chip persists | **Yes** | Yes |
| 8 | AppKit connected, effective guarded | **Yes (hold)** | No | No | **No** | Connect | **No** | Yes | Yes |
| 9 | Persisted ≠ AppKit | No | No | No | Yes | Yes | n/a | Tx session cleared | Yes |
| 10 | Active tx + account change | No | Deferred reset | No | Yes | Tx modal dominates | Partial | Session mismatch clears | **Deferred, not blocked new** — mitigated by tx modal |
| 11 | Wrong network | No | No | Gated | Yes | Switch CTA | Adequate | n/a | Yes |
| 12 | Chain change on load | No | No | Reset | Yes | Yes | Amount kept (expected) | n/a | Yes until stable |

---

## Evidence from code / traces

### Identity forced disconnected during hydration

```101:112:src/lib/wallet/walletAccountIdentityOrchestrator.ts
  if (!settled && appKitConnected) {
    traceWalletAccountIdentity("local_wallet_address_ignored_until_appkit_ready", {
      liveAppKitAddress: appKitAddress ?? null,
      appKitStatus: input.appKitStatus ?? null,
    })
    return {
      effectiveAddress: undefined,
      effectiveConnected: false,
      manualDisconnectGuard: guardStillActive,
      suppressedByDisconnectGuard: false,
      hydrationSettled: settled,
    }
  }
```

### Navbar loading suppressed on staking app

```260:261:src/components/layout/NavbarWalletSection.tsx
  const isLoading = useRuntimeIdentity ? false : appKit.isLoading
  const tronWrongNetwork =
```

### Manual disconnect on AppKit disconnect edge

```65:77:src/hooks/useWalletAccountIdentityGuard.ts
    if (
      prevConnected &&
      !input.appKitConnected &&
      (status === "disconnected" || prevStatus === "connected") &&
      !disconnectHandledRef.current
    ) {
      disconnectHandledRef.current = true
      void performWalletManualDisconnect({
        previousAddress: prevAddress,
        source: "appkit_account_disconnected",
        hasActiveTx: input.hasActiveTx,
      })
    }
```

### Tx persistence uses effective address

```1536:1547:src/components/pages/staking/TransactionStatusProvider.tsx
    if (
      row.walletAddress?.trim() &&
      executionAddress?.trim() &&
      !sessionMatchesAccount(row, executionAddress, executionChainId)
    ) {
      traceWalletAccountIdentity("account_restore_mismatch_detected", {
        persistedAddress: row.walletAddress,
        liveAppKitAddress: executionAddress,
        chainId: executionChainId,
        source: "persisted_hydrate_precheck",
      })
      clearPersistedStakingTxSession("persisted_wallet_mismatch_on_restore")
    }
```

### Trace artifacts

- `.local-debug/mobile-staking.ndjson` — empty (no runtime capture in repo)
- LAN log events defined: `local_wallet_address_ignored_until_appkit_ready`, `stale_account_restore_suppressed_by_disconnect_guard`, `account_restore_mismatch_detected`
- WC session topic read via `observeAppKitSessionSnapshot()` → `session_topic_present` (diagnostics only)

---

## Severity summary

| Severity | Count | IDs |
|---|---|---|
| P0 | 0 | — (submit gates hold; no confirmed wrong-account tx path) |
| P1 | 4 | P01-001, P01-002, P01-003, P01-004 |
| P2 | 5 | P01-005 – P01-009 |
| P3 | 2 | P01-010, P01-011 |

---

## Suggested fix direction (phase-level themes)

1. **Unify “connecting / restoring” UX** across navbar, form CTA, and balance meta using AppKit status + hydration settle + guard state (without weakening pre-settle safety).
2. **Constrain navbar visual hold** when identity is guard-suppressed or pre-settle — prefer transient skeleton over stale address.
3. **Narrow auto-`performWalletManualDisconnect`** to explicit user disconnect; treat WC transient drops as observability-only during hydration.
4. **Thread `hasActiveTx` into identity guard** for complete account-mismatch telemetry and optional tx-modal banner.
5. **Align signer hydration** with effective identity to remove raw/guard split.

---

## Do-not-touch constraints

- Do **not** reset WalletConnect sessions on startup (`appKitSessionHydrationObserve` is read-only by design).
- Do **not** add a second AppKit instance or Wagmi.
- Do **not** change `sessionMatchesAccount` fallback semantics without migration plan (v1/v2 persistence).
- Do **not** remove manual disconnect guard TTL without product decision on stale restore.
- Do **not** bypass `canTransact` / `selectTxExecutionReady` gates when fixing UX copy or loading states.
- Preserve `AppKitEvmIsolationOnPassiveTron` behavior intent on Tron runtime (isolate eip155 contamination).

---

## Prioritized findings (rollup)

1. **P01-001** — False disconnected up to 12.5s on WC restore (biggest reconnect friction).
2. **P01-002** — No navbar connecting state on staking app during WC hydrate.
3. **P01-003** — Navbar visual hold vs form Connect mismatch after guard/disconnect.
4. **P01-004** — Aggressive auto manual-disconnect on any AppKit disconnect edge.
5. **P01-005** — Account switch debounce leaves amount on new address briefly.
6. **P01-006** — Signer hydration uses raw AppKit (latent inconsistency).
7. **P01-007** — Active tx not wired into identity guard `hasActiveTx`.
8. **P01-008** — Double bootstrap loaders.
9. **P01-009** — `vaultDataReady` semantics when wrong network.
10. **P01-010** — Tron EVM isolation triggering disconnect guard.
11. **P01-011** — Empty LAN trace file (QA process).

---

**Next phase:** [`02-data-loading-balances-history.md`](./02-data-loading-balances-history.md)
