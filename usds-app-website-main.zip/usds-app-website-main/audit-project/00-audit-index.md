# Staking UI/UX Audit — Master Index

**Status:** Audit in progress (index only; phase files pending)  
**Created:** 2026-05-30  
**Mode:** Audit only — no production fixes in this pass

---

## Purpose

Structured, phase-by-phase audit of the Matrix staking app UI/UX: entry through wallet identity, data loading, deposit/withdraw forms, transaction modal/toast lifecycle, refresh/recovery/persistence, mobile Trust Wallet flows, copy/accessibility, visual stability, and cross-component consistency.

Findings will be documented per phase with severity, evidence, and suggested fix direction. **No code changes** unless explicitly requested in a follow-up task.

---

## Audit constraints (global)

| Constraint | Rationale |
|---|---|
| **Do not implement fixes** | Audit-only deliverable |
| **Do not refactor architecture** | Preserve existing staking/wallet layering |
| **Do not change wallet/session/transaction logic** | Sensitive production paths (AppKit, WC, tx execution) |
| **Do not touch hook dependency warnings** | Out of scope; avoid incidental churn |
| **Do not edit production code** | Unless explicitly requested later |
| **Preserve AppKit boundaries** | Single init, no startup session reset, no Wagmi |
| **Preserve tx lifecycle invariants** | Deposit, withdraw, approve, allowance, recovery flows |
| **Preserve read/provider separation** | RPC reads independent from wallet providers where possible |

---

## Severity scale

| Level | Definition | Examples |
|---|---|---|
| **P0** | Can cause wrong transaction perception, duplicate gas, stuck tx, wrong account, hidden success/failure | Misleading success toast, CTA enabled for wrong account, duplicate submit |
| **P1** | Major confusion or blocked user | Cannot proceed after wallet return, opaque error with no recovery path |
| **P2** | Visual instability / copy confusion | Layout shift, inconsistent status labels, ambiguous CTA text |
| **P3** | Polish | Spacing, motion timing, minor copy tone |

---

## Finding format (required in every phase file)

Each phase file must use this table for individual findings:

| ID | Severity | Area | Scenario | Expected UX | Actual UX | Risk | Evidence | Suggested fix direction | Files |
|---|---|---|---|---|---|---|---|---|---|

**Phase file sections (required):**

1. Scope  
2. Components/files inspected  
3. Current behavior  
4. Expected UX  
5. Issues found (table above)  
6. Evidence from code/traces if available  
7. Severity summary  
8. Suggested fix direction (phase-level themes)  
9. Do-not-touch constraints (phase-specific)

---

## Phase index

| # | File | Status | Primary focus |
|---|---|---|---|
| 0 | [`00-audit-index.md`](./00-audit-index.md) | **Created** | Master index, constraints, navigation |
| 1 | [`01-entry-wallet-identity.md`](./01-entry-wallet-identity.md) | **Complete** | Landing → app entry, connect, account identity, network chip |
| 2 | [`02-data-loading-balances-history.md`](./02-data-loading-balances-history.md) | Pending | Balances, APY, history loading, empty/error states |
| 3 | [`03-deposit-form-cta-slider.md`](./03-deposit-form-cta-slider.md) | Pending | Deposit form, amount slider, CTA states, terms consent |
| 4 | [`04-withdraw-form-cta-slider.md`](./04-withdraw-form-cta-slider.md) | Pending | Withdraw form, amount slider, CTA states |
| 5 | [`05-transaction-modal-toast.md`](./05-transaction-modal-toast.md) | Pending | Tx modal, step rail, lifecycle toast, detached progress |
| 6 | [`06-refresh-recovery-state-persistence.md`](./06-refresh-recovery-state-persistence.md) | Pending | Refresh orchestration, session persistence, on-chain recovery |
| 7 | [`07-mobile-trust-wallet-flows.md`](./07-mobile-trust-wallet-flows.md) | Pending | Mobile WC, deep links, wallet handoff, Trust Wallet |
| 8 | [`08-copy-status-accessibility.md`](./08-copy-status-accessibility.md) | Pending | Copy constants, status labels, a11y (focus, aria, contrast) |
| 9 | [`09-visual-layout-motion-cls.md`](./09-visual-layout-motion-cls.md) | Pending | Layout grid, glass panels, motion, CLS, safe areas |
| 10 | [`10-cross-component-consistency.md`](./10-cross-component-consistency.md) | Pending | Deposit vs withdraw parity, toast vs modal, CTA ellipsis policy |
| 11 | [`11-prioritized-fix-plan.md`](./11-prioritized-fix-plan.md) | Pending | Consolidated P0–P3 backlog, fix ordering, regression risks |

---

## Codebase map (audit targets by phase)

### Phase 01 — Entry & wallet identity

**Scope:** User path from marketing landing to connected staking app; wallet connect UX; account/network identity display and guards.

**Key files (initial list):**

- `src/components/pages/staking/staking.tsx` — landing CTA to `/staking/app`
- `src/components/pages/staking/StakingApp.tsx` — app shell, terms consent gate
- `src/components/pages/staking/StakingVaultProvider.tsx` — vault/runtime context
- `src/components/pages/staking/StakingAppNetworkChip.tsx`
- `src/hooks/useWallet.tsx`, `src/hooks/useEtheriumWallet.tsx`
- `src/hooks/useWalletAccountIdentityGuard.ts`
- `src/lib/wallet/walletAccountIdentityOrchestrator.ts`
- `src/lib/wallet/walletAccountIdentityTelemetry.ts`
- `src/lib/wallet/walletManualDisconnectGuard.ts`
- `src/staking/orchestration/openUnifiedWallet.ts`
- `src/components/pages/staking/AppKitTronIdentityDiagnosticsMount.tsx`

**Do-not-touch:** AppKit init, session restore, WC startup recovery.

---

### Phase 02 — Data loading, balances, history

**Scope:** Balance/APY presentation, loading skeletons, error surfaces, transaction history fetch and display.

**Key files (initial list):**

- `src/components/pages/staking/StakingAppBalance.tsx`
- `src/components/pages/staking/StakingApyBadge.tsx`
- `src/components/pages/staking/RollingTokenAmount.tsx`
- `src/components/pages/staking/StakingAppTransactionHistory.tsx`
- `src/components/pages/staking/StakingAppErrorSurface.tsx`
- `src/staking/vault/composer/useStakingVaultComposerBalanceState.ts`
- `src/staking/vault/composer/useStakingVaultHistoryPlane.ts`
- `src/staking/refresh/useStakingVaultBalanceRefresh.ts`
- `src/staking/runtime/useStakingVaultRuntimePlanes.ts`

**Do-not-touch:** RPC provider architecture, polling intervals, Firestore subscription wiring (read perf skill applies).

---

### Phase 03 — Deposit form, CTA, slider

**Scope:** Deposit amount input, slider, validation, primary CTA label/state machine, terms consent interaction.

**Key files (initial list):**

- `src/components/pages/staking/StakingAppForm.tsx`
- `src/components/pages/staking/StakingAppDepositForm.tsx`
- `src/components/pages/staking/StakingFormLayout.tsx`
- `src/components/pages/staking/StakingFormActionSummary.tsx`
- `src/components/pages/staking/StakingFormBalanceMetaRow.tsx`
- `src/components/pages/staking/StakingCtaEllipsisLabel.tsx`, `StakingCtaReason.tsx`
- `src/components/pages/staking/StakingTermsConsentProvider.tsx`, `StakingTermsConsentSurface.tsx`
- `src/staking/ui/stakingAmountSliderVisual.ts`
- `src/staking/cta/stakingSnapshotCtaPhase.ts`, `stakingCtaEllipsisPolicy.ts`
- `src/constants/stakingCtaMessages.ts`, `stakingCtaShortLabels.ts`

**Do-not-touch:** Tx execution guards, allowance logic, gas estimation internals.

---

### Phase 04 — Withdraw form, CTA, slider

**Scope:** Withdraw parity with deposit; unstake amount constraints; CTA disabled/enabled semantics.

**Key files (initial list):**

- `src/components/pages/staking/StakingAppWithdrawForm.tsx`
- Shared form components listed in Phase 03
- `src/staking/tx/stakingWithdrawRecoveryFromSnapshot.ts` (UX impact of recovery only)

**Do-not-touch:** Withdraw execution path, vault contract calls.

---

### Phase 05 — Transaction modal & toast

**Scope:** In-form tx status surface, step rail, lifecycle toast banner, detached progress toast, Sonner presentation.

**Key files (initial list):**

- `src/components/pages/staking/TransactionStatusProvider.tsx`
- `src/components/pages/staking/TransactionStatusSurface.tsx`
- `src/components/pages/staking/TransactionStatusContext.tsx`
- `src/components/pages/staking/transactionStatusModel.ts`
- `src/components/pages/staking/TransactionDepositStepRail.tsx`
- `src/components/pages/staking/transactionDepositStepModel.ts`
- `src/components/pages/staking/StakingTxLifecycleToastBanner.tsx`
- `src/components/pages/staking/StakingActiveTxAmbient.tsx`
- `src/components/pages/staking/StakingAmbientTxPresentationProvider.tsx`
- `src/staking/notifications/stakingDetachedTxProgressToast.tsx`
- `src/staking/notifications/stakingTxLifecycleToastActions.ts`
- `src/staking/notifications/stakingTxLifecycleToastPresentation.ts`
- `src/components/ui/sonner.tsx`, `staking-sonner.css`, `sonnerUtils.ts`
- `src/constants/stakingTransactionUxCopy.ts`
- `src/constants/stakingNotificationLayout.ts`, `stakingNotificationSpec.ts`
- `src/constants/stakingModalSpec.ts`
- `src/lib/stakingTransactionMessages.ts`

**Do-not-touch:** Tx state machine transitions, broadcast/receipt polling, wallet dispatch bridge.

---

### Phase 06 — Refresh, recovery, state persistence

**Scope:** Post-tx refresh, persisted tx session restore, approval/withdraw recovery, stale provider guards.

**Key files (initial list):**

- `src/staking/tx/stakingTxSessionPersistence.ts`
- `src/staking/tx/stakingTxOnChainRecovery.ts`
- `src/staking/tx/stakingApprovalRecoveryFromSnapshot.ts`
- `src/staking/tx/stakingPostReturnApprovalVerification.ts`
- `src/staking/tx/stakingRecoveredWalletWaitHandoff.ts`
- `src/staking/tx/stakingStakeWalletWaitTerminal.ts`
- `src/staking/tx/stakingTxStaleProviderUpdateGuard.ts`
- `src/staking/tx/transactionStatusSnapshotHelpers.ts`
- `src/staking/refresh/useStakingVaultBalanceRefresh.ts`

**Do-not-touch:** Recovery trigger conditions, session invalidation rules.

---

### Phase 07 — Mobile & Trust Wallet flows

**Scope:** Mobile WalletConnect handoff, return-from-wallet UX, Trust Wallet connect/debug paths, LAN diagnostic traces.

**Key files (initial list):**

- `src/lib/wallet/openStakingTxWalletHandoff.ts`
- `src/staking/tx/stakingTxWalletDispatchBridge.ts`
- `src/staking/diagnostics/mobileStakingFlowStep.ts`
- `src/staking/diagnostics/mobileStakingLanLog.ts`
- `src/staking/diagnostics/installMobileStakingWcSessionTrace.ts`
- `src/staking/diagnostics/useMobileStakingLanLogBootstrap.ts`
- `src/staking/diagnostics/stakingTrustWalletConnectDebug.ts`
- `src/staking/diagnostics/stakingTxMobileDeepLinkTrace.ts`
- `src/config/mobileStakingLogEnv.ts`
- `vite/plugins/mobileStakingLogDevPlugin.ts`
- `scripts/mobile-staking-log-tail.mjs`, `mobile-staking-log-clear.mjs`

**Evidence sources:** `.local-debug/mobile-staking.ndjson` (when populated during manual runs)

**Do-not-touch:** WC session lifecycle, deep-link URL schemes, AppKit mobile config.

---

### Phase 08 — Copy, status & accessibility

**Scope:** User-facing strings, status phase labels, button text truncation, focus management, screen reader semantics.

**Key files (initial list):**

- `src/constants/stakingCopy.ts`
- `src/constants/stakingTransactionUxCopy.ts`
- `src/constants/stakingCtaMessages.ts`, `stakingCtaShortLabels.ts`
- `src/constants/stakingTermsConsent.ts`
- `src/lib/stakingTransactionMessages.ts`
- `src/staking/tx/types/transactionStatusWirePhase.ts`
- Form/modal/toast components (aria labels, live regions)

**Do-not-touch:** Wire-phase enum values used by tx orchestration (copy-only audit).

---

### Phase 09 — Visual layout, motion & CLS

**Scope:** Responsive grid, liquid glass panels, safe-area padding, rolling number animation, layout shift during load/tx.

**Key files (initial list):**

- `src/components/pages/staking/StakingApp.tsx` — grid, safe-area, order breakpoints
- `src/components/pages/staking/stakingGlassPanel.ts`
- `src/components/pages/staking/StakingCtaEllipsis.module.css`
- `src/components/pages/staking/RollingTokenAmount.tsx`
- `src/staking/identity/stakingNavbarVisualHold.ts`
- `src/staking/diagnostics/txVisualOwnershipTrace.ts`
- `src/components/ui/staking-sonner.css`

**Do-not-touch:** Runtime picker dev panel visibility logic.

---

### Phase 10 — Cross-component consistency

**Scope:** Deposit vs withdraw CTA parity, modal vs toast ownership, ambient tx vs form status, ellipsis/truncation policy alignment.

**Key files (initial list):**

- All form and tx presentation files from Phases 03–05
- `src/staking/cta/stakingCtaDiagnostics.ts`
- `src/staking/diagnostics/txVisualOwnershipTrace.ts`
- `src/components/pages/staking/stakingAmbientTxPresentationContext.ts`

---

### Phase 11 — Prioritized fix plan

**Scope:** Roll up findings from Phases 01–10 into ordered backlog with regression notes and fix-batch recommendations.

**Inputs:** Finding IDs from all phase files  
**Output:** P0-first implementation roadmap (documentation only; no code)

---

## Supporting skills & rules

| Resource | Use during audit |
|---|---|
| `.cursor/skills/audit-before-implementation/SKILL.md` | Per-phase inspection discipline |
| `.cursor/skills/staking-transactions/SKILL.md` | Tx flow invariants when reviewing Phases 05–07 |
| `.cursor/skills/staking-read-performance/SKILL.md` | Read/provider notes for Phase 02 |
| `.cursor/rules/appkit-boundaries.mdc` | Wallet/session boundary checks |
| `.cursor/rules/core.mdc` | Minimal-change mindset for fix directions |

---

## Audit workflow

```mermaid
flowchart LR
  A[00 Index] --> B[01 Entry / Identity]
  B --> C[02 Data Loading]
  C --> D[03 Deposit]
  D --> E[04 Withdraw]
  E --> F[05 Modal / Toast]
  F --> G[06 Refresh / Recovery]
  G --> H[07 Mobile / Trust]
  H --> I[08 Copy / A11y]
  I --> J[09 Visual / CLS]
  J --> K[10 Consistency]
  K --> L[11 Fix Plan]
```

1. Complete one phase file at a time; do not implement fixes inline.  
2. Cross-reference finding IDs across phases (e.g. `P05-003` referenced in Phase 11).  
3. Prefer code citations and trace excerpts over assumptions.  
4. Mark phase status in this index when each file is completed.

---

## Trace & debug artifacts

| Artifact | Location | Relevance |
|---|---|---|
| Mobile staking LAN log | `.local-debug/mobile-staking.ndjson` | Phase 07 evidence |
| Mobile log tail script | `scripts/mobile-staking-log-tail.mjs` | Dev-time trace capture |
| Vite mobile log plugin | `vite/plugins/mobileStakingLogDevPlugin.ts` | Dev log ingestion |

---

## Next step

Create and complete **`01-entry-wallet-identity.md`** as the first audit phase. Update the Status column in the Phase index above when each subsequent file is written.
