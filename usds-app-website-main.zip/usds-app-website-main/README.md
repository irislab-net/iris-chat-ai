# Wallet Landing

## Documentation

Active staking documentation is intentionally small and canonical:

- `docs/staking-domain-boundaries.md` ? architecture boundaries
- `docs/staking-runtime-contracts.md` ? runtime ownership and tx continuity
- `docs/staking-runtime-edgecases.md` ? lifecycle, retry, mobile, and BFCache behavior
- `docs/staking-maintenance-rules.md` ? operational maintenance rules
- `docs/deploy-runtime-assets.md` ? deploy/runtime observability and build scripts
- `docs/staking-sentry-event-taxonomy.md` ? Sentry and runtime telemetry taxonomy
- `docs/archive/migration-phase-reports/README.md` ? historical archive index
