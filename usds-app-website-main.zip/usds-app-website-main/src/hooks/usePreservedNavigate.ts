import {
  buildPreservedTo,
  type PreserveLocationOptions,
} from "@/lib/routing/preserveLocationParams"
import { useCallback } from "react"
import {
  useLocation,
  useNavigate,
  type NavigateOptions,
} from "react-router-dom"

/**
 * `useNavigate` wrapper that forwards the current location's search params
 * and hash onto a static target path by default. Mirrors the React-Router
 * `navigate(to, options)` signature; preservation can be tuned per call:
 *
 *     const navigate = usePreservedNavigate()
 *     navigate("/staking/app")                       // forwards ?ref / hash
 *     navigate("/staking/app", { preserveSearch: false })
 *     navigate("/staking/app?ref=0xABC")              // target wins on ref
 */
export function usePreservedNavigate() {
  const navigate = useNavigate()
  const location = useLocation()

  return useCallback(
    (
      target: string,
      options?: NavigateOptions & PreserveLocationOptions
    ): void => {
      const {
        preserveSearch,
        preserveHash,
        keys,
        ...navOptions
      } = options ?? {}
      const to = buildPreservedTo(target, location, {
        preserveSearch,
        preserveHash,
        keys,
      })
      navigate(to, navOptions)
    },
    [navigate, location]
  )
}
