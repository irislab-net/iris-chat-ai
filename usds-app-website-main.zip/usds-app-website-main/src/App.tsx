import Footer from "@/components/layout/footer"
import { InitialSplashOverlay } from "@/components/layout/InitialSplashOverlay"
import Navbar from "@/components/layout/navbar"
import RouteLoadingFallback from "@/components/layout/RouteLoadingFallback"
import ScrollToTop from "@/components/layout/scrollToTop"
import { Toaster } from "@/components/ui/sonner"
import { AppKitReadyProvider } from "@/providers/AppKitReadyProvider"
import { BootstrapOrchestrationProvider } from "@/providers/BootstrapOrchestrationProvider"
import { TelegramEscalationProvider } from "@/providers/TelegramEscalationProvider"
import { Suspense, useEffect } from "react"
import { BrowserRouter } from "react-router-dom"
import "./App.css"
import AppRoutes from "./routes"

function App() {
  useEffect(() => {
    if (!import.meta.env.DEV) return
    const until = Date.now() + 12_000
    const onFocusIn = (e: FocusEvent) => {
      if (Date.now() > until) {
        document.removeEventListener("focusin", onFocusIn)
        return
      }
      const t = e.target
      if (t instanceof HTMLElement) {
        const id = t.id ? `#${t.id}` : ""
         
        console.log("[focus-debug]", t.tagName + id, t.className?.slice?.(0, 96))
      }
    }
    document.addEventListener("focusin", onFocusIn)
    return () => document.removeEventListener("focusin", onFocusIn)
  }, [])

  return (
    <BrowserRouter>
      <AppKitReadyProvider>
        <BootstrapOrchestrationProvider>
          <TelegramEscalationProvider>
            <ScrollToTop />
            <Navbar />

            <div className='flex flex-col min-h-screen'>
              <main className='flex-1'>
                <Suspense fallback={<RouteLoadingFallback />}>
                  <AppRoutes />
                </Suspense>
              </main>

              <Footer />
            </div>

            <Toaster />

            <InitialSplashOverlay />
          </TelegramEscalationProvider>
        </BootstrapOrchestrationProvider>
      </AppKitReadyProvider>
    </BrowserRouter>
  )
}

export default App
