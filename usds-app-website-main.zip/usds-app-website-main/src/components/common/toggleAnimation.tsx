import { queryScopedTargets, setScopedIfPresent } from "@/lib/gsapScopedTargets"
import { cn } from "@/lib/utils"
import type { SVGIcon } from "@/types/icon"
import { useGSAP } from "@gsap/react"
import gsap from "gsap"
import { useEffect, useRef } from "react"

function ToggleAnimation({
  className,
  scrollTrigger = false,
  open = false,
  onScrollComplete,
  ...props
}: {
  icon?: SVGIcon
  className?: string
  scrollTrigger?: boolean
  open?: boolean
  onScrollComplete?: () => void
}) {
  const containerRef = useRef<HTMLDivElement>(null)
  const timeline = useRef<GSAPTimeline>(null)

  useGSAP(
    () => {
      const root = containerRef.current
      const svg = root?.querySelector("svg")
      if (!root || !svg) return

      const viewBox = (svg.getAttribute("viewBox") ?? "0 0 24 24").split(" ")
      const viewBoxWidth = parseInt(viewBox[2], 10)
      const viewBoxHeight = parseInt(viewBox[3], 10)

      const cx = viewBoxWidth / 2
      const cy = viewBoxHeight / 2

      setScopedIfPresent(root, "circle, ellipse", {
        transformOrigin: "center",
      })
      setScopedIfPresent(root, "path, rect", {
        opacity: 0,
        drawSVG: "50% 50%",
      })
      setScopedIfPresent(root, "line", {
        opacity: 0,
        drawSVG: "0% 0%",
      })
      setScopedIfPresent(root, ".scale-on-toggle", {
        scale: 0,
      })

      timeline.current = gsap.timeline({
        scrollTrigger: scrollTrigger
          ? {
              trigger: root,
              start: "top 100%",
              end: "center 90%",
              toggleActions: "play play reverse reset",
            }
          : undefined,
        onComplete: () => {
          onScrollComplete?.()
        },
      })

      if (!scrollTrigger) timeline.current.pause(0)

      const duration = 0.5
      const circles = queryScopedTargets(root, "circle, ellipse")
      const scaleEls = queryScopedTargets(root, ".scale-on-toggle")
      const paths = queryScopedTargets(root, "path, rect")
      const lines = queryScopedTargets(root, "line")

      if (circles.length > 0) {
        timeline.current.from(circles, {
          attr: { cx, cy },
          stagger: duration / 10,
          duration,
          ease: "back.inOut",
        })
      }

      if (scaleEls.length > 0) {
        const at = circles.length > 0 ? "<" : undefined
        timeline.current.to(
          scaleEls,
          {
            scale: 1,
            stagger: duration / 10,
            duration,
            ease: "back.inOut",
          },
          at,
        )
      }

      if (paths.length > 0) {
        timeline.current
          .to(paths, {
            drawSVG: "0% 100%",
            duration,
            ease: "power2.inOut",
          })
          .to(
            paths,
            {
              opacity: 1,
              duration: 0.1,
            },
            "<",
          )
      }

      if (lines.length > 0) {
        timeline.current
          .to(lines, {
            drawSVG: "0% 100%",
            duration,
            ease: "power2.inOut",
          })
          .to(
            lines,
            {
              opacity: 1,
              duration: 0.1,
            },
            "<",
          )
      }
    },
    { scope: containerRef, dependencies: [props.icon, scrollTrigger] },
  )

  useEffect(() => {
    if (open) timeline.current?.play(0)
    else timeline.current?.reverse()
  }, [open])

  return (
    <div ref={containerRef} className={cn("size-[1em] relative", className)}>
      {props.icon && <props.icon className='size-full' overflow='visible' />}
    </div>
  )
}

export default ToggleAnimation
