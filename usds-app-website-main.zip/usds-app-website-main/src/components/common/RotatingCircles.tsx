import { useGSAP } from "@gsap/react"
import { gsap } from "gsap"
import { useRef } from "react"

interface CircleSetConfig {
  radius: number
  dotCount: number
  dotSize: number
  speed: number
  direction: 1 | -1
  opacity: number
  viewBox: number
  size: string
}

interface RotatingCirclesProps {
  className?: string
  circleSets?: CircleSetConfig[]
}

const defaultCircleSets: CircleSetConfig[] = [
  {
    radius: 360,
    dotCount: 18,
    dotSize: 20,
    speed: 200, // Much slower - 4x slower than original
    direction: 1,
    opacity: 0.1,
    viewBox: 900,
    size: "size-[40rem] md:size-[70rem]",
  },
  {
    radius: 480,
    dotCount: 22,
    dotSize: 30,
    speed: 250, // Much slower - 4x slower than original
    direction: -1,
    opacity: 0.2,
    viewBox: 1200,
    size: "size-[60rem] md:size-[100rem]",
  },
  {
    radius: 600,
    dotCount: 26,
    dotSize: 40,
    speed: 300, // Much slower - 4x slower than original
    direction: 1,
    opacity: 0.3,
    viewBox: 1500,
    size: "size-[80rem] md:size-[130rem]",
  },
  {
    radius: 720,
    dotCount: 30,
    dotSize: 50,
    speed: 350, // Much slower - 4x slower than original
    direction: -1,
    opacity: 0.4,
    viewBox: 1800,
    size: "size-[100rem] md:size-[163rem]",
  },
]

function RotatingCircles({
  className = "",
  circleSets = defaultCircleSets,
}: RotatingCirclesProps) {
  const containerRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    if (!containerRef.current) return

    const circles = containerRef.current.querySelectorAll(".circle-set")

    // Create rotation animations for each set at different speeds
    circles.forEach((set, index) => {
      const config = circleSets[index]
      if (!config) return

      gsap.to(set, {
        rotation: 360 * config.direction,
        duration: config.speed,
        repeat: -1,
        ease: "none",
      })
    })

    // Create scaling animations for individual circles
    const allCircles = containerRef.current.querySelectorAll("circle")

    allCircles.forEach(circle => {
      // Set transform origin to the circle's center
      gsap.set(circle, {
        transformOrigin: "center center",
      })

      // Create much slower scaling animation for each circle
      const randomScale = 1 + Math.random() * 0.3 + 0.2 // Random scale between 1.2 and 1.5
      const randomDuration = 8 + Math.random() * 8 // Random duration between 8-16 seconds (much slower)
      const randomDelay = Math.random() * 4 // Random delay between 0-4 seconds

      gsap.to(circle, {
        scale: randomScale,
        duration: randomDuration,
        repeat: -1,
        yoyo: true,
        ease: "power1.inOut",
        delay: randomDelay,
      })
    })

    return () => {
      gsap.killTweensOf(circles)
      gsap.killTweensOf(allCircles)
    }
  }, [circleSets])

  // Generate concentric circles with dots
  const generateCircleSet = (config: CircleSetConfig) => {
    const dots = []
    for (let i = 0; i < config.dotCount; i++) {
      const angle = (i / config.dotCount) * 2 * Math.PI
      const x = Math.cos(angle) * config.radius
      const y = Math.sin(angle) * config.radius

      dots.push(
        <circle
          key={i}
          cx={x}
          cy={y}
          r={config.dotSize}
          fill='var(--color-neutral-300)'
          opacity={config.opacity}
        />
      )
    }
    return dots
  }

  return (
    <div
      ref={containerRef}
      className={`absolute inset-0 pointer-events-none overflow-hidden ${className}`}
    >
      {circleSets.map((config, index) => (
        <div
          key={index}
          className={`circle-set absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2`}
        >
          <svg
            viewBox={`-${config.viewBox} -${config.viewBox} ${
              config.viewBox * 2
            } ${config.viewBox * 2}`}
            className={config.size}
          >
            {generateCircleSet(config)}
          </svg>
        </div>
      ))}
    </div>
  )
}

export default RotatingCircles
