import { cn } from "@/lib/utils"
import type { FeatureCardData } from "@/types/card"
import FeatureCard from "./featureCard"

function FeatureCardGrid({
  cards,
  className,
  cardClassName,
  bgClassName,
  children,
}: {
  cards: FeatureCardData[]
  children?: React.ReactNode
  className?: string
  cardClassName?: string
  bgClassName?: string
}) {
  return (
    <div className={cn("grid grid-cols-1 gap-1", className)}>
      {cards.map((card, index) => (
        <FeatureCard
          key={index}
          card={card}
          className={cardClassName}
          bgClassName={bgClassName}
        />
      ))}

      {children}
    </div>
  )
}

export default FeatureCardGrid
