import {
  buildPreservedTo,
  type PreserveLocationOptions,
} from "@/lib/routing/preserveLocationParams"
import { forwardRef } from "react"
import { Link, useLocation, type LinkProps } from "react-router-dom"

export type PreservedLinkProps = Omit<LinkProps, "to"> &
  PreserveLocationOptions & {
    /**
     * Static destination path. Same shape callers pass to `<Link to="…">`:
     *   "/staking/app", "/staking/app?ref=0xABC", "/staking/app#section".
     * Target search/hash always wins on key conflicts.
     */
    to: string
  }

/**
 * Drop-in replacement for `<Link>` that forwards the current location's
 * search params and hash onto the destination. Used for referral / Telegram
 * deep-link continuity without changing call-site ergonomics.
 *
 * Wire it ONLY where preservation is desired (currently the staking-funnel
 * navigations). Everywhere else, plain `<Link>` continues to work and we
 * keep the original behavior.
 */
export const PreservedLink = forwardRef<HTMLAnchorElement, PreservedLinkProps>(
  function PreservedLink(
    { to, preserveSearch, preserveHash, keys, ...rest },
    ref
  ) {
    const location = useLocation()
    const merged = buildPreservedTo(to, location, {
      preserveSearch,
      preserveHash,
      keys,
    })
    return <Link ref={ref} to={merged} {...rest} />
  }
)
