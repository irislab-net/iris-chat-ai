import { cn } from "@/lib/utils"
import type { AnimationHandle } from "@/types/animation"
import type { FeatureCardData } from "@/types/card"
import { useRef } from "react"
import Frame from "./frame"
import ToggleAnimation from "./toggleAnimation"

function FeatureItem({
  feature,
  toggleAnimation,
  className,
}: {
  feature: FeatureCardData
  toggleAnimation?: boolean
  className?: string
}) {
  const iconRef = useRef<AnimationHandle>(null)

  const handleIconAnimation = () => {
    iconRef.current?.play()
  }

  function getIcon() {
    if (feature.animatedIcon)
      return (
        <feature.animatedIcon ref={iconRef} className={feature.iconClassName} />
      )

    if (!feature.icon) return null

    if (toggleAnimation)
      return (
        <ToggleAnimation
          scrollTrigger
          icon={feature.icon}
          className={feature.iconClassName}
        />
      )

    return <feature.icon className={feature.iconClassName} />
  }

  return (
    <Frame
      className={cn(
        "flex flex-col md:flex-row items-start gap-2 md:gap-7 p-7",
        className
      )}
      onMouseEnter={handleIconAnimation}
      onTouchStart={handleIconAnimation}
    >
      <div className='flex items-center gap-4 md:sticky md:top-24'>
        {getIcon()}

        <strong className='font-semibold text-neutral-700 font-brand'>
          {feature.title}
        </strong>
      </div>

      <p className='md:ms-auto md:max-w-[30em] text-neutral-600/75 text-left'>
        {feature.description}
      </p>
    </Frame>
  )
}

function FeatureList({
  list,
  toggleAnimation,
}: {
  list: FeatureCardData[]
  toggleAnimation?: boolean
}) {
  return (
    <div className='flex flex-col gap-2'>
      {list.map((feature, index) => (
        <FeatureItem
          key={index}
          feature={feature}
          toggleAnimation={toggleAnimation}
          className={cn(index % 2 !== 0 ? "bg-neutral-50" : null)}
        />
      ))}
    </div>
  )
}

export default FeatureList
