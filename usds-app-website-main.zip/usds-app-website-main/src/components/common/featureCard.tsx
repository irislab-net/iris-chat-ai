import { cn } from "@/lib/utils"
import type { AnimationHandle } from "@/types/animation"
import type { FeatureCardData } from "@/types/card"
import React, { useRef } from "react"
import GrowingCard from "./growingCard"

function FeatureCard({
  card,
  className,
  bgClassName,
  children,
}: {
  card: FeatureCardData
  className?: string
  bgClassName?: string
  children?: React.ReactNode
}) {
  const iconAnimationRef = useRef<AnimationHandle>(null)

  const iconClassName = cn(
    "size-5 min-w-5 group-hover/growing-card:scale-125 transition-transform duration-300 delay-100 ease-in-out",
    card.iconClassName
  )

  const handleIconAnimation = () => {
    iconAnimationRef.current?.play()
  }

  return (
    <GrowingCard
      className={cn(
        "flex items-start gap-3 text-xs text-neutral-600 p-4",
        card.className,
        className
      )}
      bgClassName={cn(bgClassName, card.bgClassName)}
      onMouseEnter={handleIconAnimation}
      onTouchStart={handleIconAnimation}
    >
      {!card.animatedIcon && card.icon && (
        <card.icon className={iconClassName} />
      )}

      {card.animatedIcon && (
        <card.animatedIcon ref={iconAnimationRef} className={iconClassName} />
      )}

      <div className='flex flex-col gap-2'>
        <strong className='block text-sm font-semibold text-neutral-900'>
          {card.title}
        </strong>

        {card.description && (
          <p className='text-xs text-neutral-700'>{card.description}</p>
        )}

        {children}
      </div>
    </GrowingCard>
  )
}

export default FeatureCard
