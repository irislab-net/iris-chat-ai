import { cn } from "@/lib/utils"
import type { Tab, Tabs } from "@/types/tabs"
import { useGSAP } from "@gsap/react"
import gsap from "gsap"
import { useRef } from "react"
import { Button } from "../ui/button"

function LargeTabs({
  tabs = [],
  active,
  activeClassName,
  className,
  setActiveTab,
}: {
  tabs?: Tabs
  active?: Tab
  activeClassName?: string
  setActiveTab?: (tab: Tab) => void
  className?: string
}) {
  const containerRef = useRef<HTMLDivElement>(null)

  const handleSetActiveTab = (tab: Tab) => {
    setActiveTab?.(tab)
  }

  useGSAP(
    () => {
      // Animate the active paragraph
      const activeTabParagraph = containerRef.current?.querySelector(
        ".large-tab[data-active='true'] p"
      )

      if (!activeTabParagraph) return

      if (activeTabParagraph) {
        // Set initial state
        gsap.set(activeTabParagraph, {
          opacity: 0,
          y: 20,
          display: "block",
          delay: 0.4,
        })

        // Animate in with delay
        gsap.to(activeTabParagraph, {
          opacity: 1,
          y: 0,
          duration: 0.4,
          delay: 0.5,
          ease: "power2.out",
        })
      }
    },
    { scope: containerRef, dependencies: [active] }
  )

  return (
    <div
      ref={containerRef}
      className={cn("flex gap-4 md:gap-10 w-full max-w-full", className)}
    >
      {tabs.map((tab, index) => (
        <Button
          key={index}
          variant='plain'
          data-active={active?.title === tab.title}
          className={cn(
            "large-tab relative flex items-start justify-start flex-col py-4 md:py-8 px-0 gap-2 md:gap-4 transition-all duration-500 flex-1 h-auto w-auto",
            active?.title === tab.title &&
              `${activeClassName ?? ""} ${
                tab.className ?? ""
              } border-current flex-[1.5]`
          )}
          onClick={() => handleSetActiveTab(tab)}
          onMouseEnter={() => handleSetActiveTab(tab)}
        >
          <div
            className={cn(
              "absolute top-0 inset-x-0 h-[4px] rounded-xl bg-neutral-200/50 transition-all duration-300",
              active?.title === tab.title && "bg-current"
            )}
          ></div>

          <strong
            className={cn(
              "text-xl md:text-2xl font-semibold transition-colors duration-500 font-brand",
              active?.title === tab.title &&
                `${activeClassName ?? ""} ${tab.className ?? ""}`
            )}
          >
            {tab.title}
          </strong>
        </Button>
      ))}
    </div>
  )
}

export default LargeTabs
