import { cn } from "@/lib/utils"
import type { SVGIcon } from "@/types/icon"
import { useGSAP } from "@gsap/react"
import gsap from "gsap"
import { Box } from "lucide-react"
import { useRef } from "react"
import { AaveIcon } from "../icons/aave"
import { AlchemyIcon } from "../icons/alchemy"
import { AvalancheIcon } from "../icons/avalanche"
import { BinanceIcon } from "../icons/binance"
import { BitcoinIcon } from "../icons/bitcoin"
import { CircleCompanyIcon } from "../icons/circleCompany"
import { CoinmarketcapIcon } from "../icons/coinmarketcap"
import { CurveDexIcon } from "../icons/curveDex"
import { DefilamaIcon } from "../icons/defilama"
import { EthereumIcon } from "../icons/etherium"
import { GoogleCloudIcon } from "../icons/googleCloud"
import { PolygonIcon } from "../icons/polygon"
import { RangoExchangeIcon } from "../icons/rangoExchange"
import { SolanaIcon } from "../icons/solana"
import { SuiIcon } from "../icons/sui"
import { TronIcon } from "../icons/tron"
import { UnswapIcon } from "../icons/unswap"
import { ZeroXIcon } from "../icons/zeroX"
import Frame from "./frame"

interface LogoData {
  src: string
  name: string
  icon?: SVGIcon
}

function LogosGrid({
  children,
  className,
}: {
  children?: React.ReactNode
  className?: string
}) {
  const containerRef = useRef<HTMLDivElement>(null)
  const allLogos: LogoData[] = [
    {
      src: "",
      name: "Bitcoin",
      icon: BitcoinIcon,
    },
    {
      src: "",
      name: "Ethereum",
      icon: EthereumIcon,
    },
    {
      src: "",
      name: "Solana",
      icon: SolanaIcon,
    },
    {
      src: "",
      name: "Binance",
      icon: BinanceIcon,
    },
    {
      src: "",
      name: "Polygon",
      icon: PolygonIcon,
    },
    {
      src: "",
      name: "Sui",
      icon: SuiIcon,
    },
    {
      src: "",
      name: "Tron",
      icon: TronIcon,
    },
    {
      src: "",
      name: "Avalanche",
      icon: AvalancheIcon,
    },
    {
      src: "",
      name: "Aave",
      icon: AaveIcon,
    },
    {
      src: "",
      name: "Alchemy",
      icon: AlchemyIcon,
    },
    {
      src: "",
      name: "Coinmarketcap",
      icon: CoinmarketcapIcon,
    },
    {
      src: "",
      name: "Google Cloud",
      icon: GoogleCloudIcon,
    },
    {
      src: "",
      name: "ZeroX",
      icon: ZeroXIcon,
    },
    {
      src: "",
      name: "Rango Exchange",
      icon: RangoExchangeIcon,
    },
    {
      src: "",
      name: "Defilama",
      icon: DefilamaIcon,
    },
    {
      src: "",
      name: "Circle",
      icon: CircleCompanyIcon,
    },
    {
      src: "",
      name: "Curve Dex",
      icon: CurveDexIcon,
    },
    {
      src: "",
      name: "Unswap",
      icon: UnswapIcon,
    },
  ]

  const firstLogos = allLogos.slice(0, 9)
  const lastLogos = allLogos.slice(9)

  const renderLogos = (logos: LogoData[], className?: string) => {
    return (
      <div
        className={cn(
          "flex-1 grid grid-cols-3 grid-rows-2 md:grid-rows-3 gap-4",
          className
        )}
      >
        {logos.map((logo, index) => (
          <div
            key={index}
            title={logo.name}
            className='group/small-logo small-logo md:aspect-square'
          >
            <Frame className='rounded-2xl bg-neutral-50/0 flex items-center justify-center h-full w-full p-4 md:p-0'>
              <div title={logo.name} className='logo text-neutral-700'>
                {logo.icon ? (
                  <logo.icon className='size-7 group-hover/small-logo:scale-150 group-active/small-logo:scale-150 transition-transform duration-300 ease-in-out' />
                ) : (
                  <Box className='size-7 opacity-50' />
                )}
              </div>
            </Frame>
          </div>
        ))}
      </div>
    )
  }

  useGSAP(
    () => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: containerRef.current,
          toggleActions: "restart none none none",
          start: "top 100%",
          end: "bottom 75%",
        },
      })

      tl.from(".small-logo", {
        y: 100,
        opacity: 0,
        duration: 0.5,
        stagger: {
          amount: 0.25,
        },
        ease: "sine.inOut",
      }).from(
        ".small-logo .logo",
        {
          y: 50,
          opacity: 0,
          duration: 1,
          stagger: {
            amount: 0.25,
          },
          ease: "elastic.inOut",
        },
        "-=0.8"
      )
    },
    { scope: containerRef }
  )

  return (
    <div
      ref={containerRef}
      className={cn(
        "flex flex-col md:items-center sm:flex-row gap-4 w-full",
        className
      )}
    >
      {renderLogos(firstLogos.slice(0, 6), "sm:hidden")}
      {renderLogos(firstLogos, "hidden sm:grid")}
      <Frame className='rounded-4xl bg-neutral-50 flex items-center justify-center col-span-3 row-span-3 h-[200px] md:h-[280px] sm:h-auto sm:flex-1'>
        {children}
      </Frame>
      {renderLogos(lastLogos.slice(0, 6), "sm:hidden")}
      {renderLogos(lastLogos, "hidden sm:grid")}
    </div>
  )
}

export default LogosGrid
