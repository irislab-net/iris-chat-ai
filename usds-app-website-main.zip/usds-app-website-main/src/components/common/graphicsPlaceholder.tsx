import { cn } from "@/lib/utils"
import { Shapes } from "lucide-react"
import React from "react"

const GraphicsPlaceholder = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div">
>(
  (
    {
      showText = true,
      className,
    }: {
      showText?: boolean
      className?: string
    },
    ref
  ) => {
    return (
      <div
        ref={ref}
        className={cn(
          "flex flex-col gap-4 items-center justify-center w-full bg-neutral-200/50 text-neutral-500 rounded-[inherit] text-center",
          className
        )}
      >
        <Shapes className='size-8 text-neutral-400' />
        {showText && <span className='px-2'>Some graphics will be here!</span>}
      </div>
    )
  }
)

export default GraphicsPlaceholder
