import { cn } from "@/lib/utils"
import type { Steps } from "@/types/steps"

function StepList({
  steps = [],
  stepClassName,
  className,
}: {
  steps?: Steps
  stepClassName?: string
  className?: string
}) {
  return (
    <div className={cn("space-y-5", className)}>
      {steps.map((step, index) => (
        <div key={index} className='flex items-start gap-3'>
          <div
            style={{ transitionDelay: index * 0.1 + "s" }}
            className={cn(
              "size-6 min-w-6 rounded-full bg-neutral-200 text-neutral-700 text-xs flex items-center justify-center mt-1 transition-all duration-300",
              stepClassName
            )}
          >
            {index + 1}
          </div>

          <div>
            <p className='text-sm font-semibold'>{step.title}</p>

            <p className='text-xs text-neutral-600'>{step.description}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

export default StepList
