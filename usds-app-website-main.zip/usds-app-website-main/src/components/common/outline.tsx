import { cn } from "@/lib/utils"
import type { ContentOutline } from "@/types/outline"
import { useEffect, useState } from "react"
import { Button } from "../ui/button"

function Outline({
  title,
  outline,
  className,
  listClassName,
  children,
}: {
  title?: string
  outline: ContentOutline[]
  className?: string
  listClassName?: string
  children?: React.ReactNode
}) {
  const [active, setActive] = useState<string>(outline[0]?.id || "")

  useEffect(() => {
    setActive(outline[0]?.id || "")

    const handleScroll = () => {
      const items = outline.map(item => ({
        id: item.id,
        element: document.getElementById(item.id),
      }))

      const scrollPosition = window.scrollY + 56 // Offset for sticky header

      for (let i = items.length - 1; i >= 0; i--) {
        const item = items[i]
        if (item.element && item.element.offsetTop <= scrollPosition) {
          setActive(item.id)
          break
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [outline])

  return (
    <div
      className={cn("sticky top-20 w-[250px] min-w-[250px] h-full", className)}
    >
      <div className={cn("flex flex-col border-neutral-200/50", listClassName)}>
        {title && (
          <strong className='text-xs text-neutral-400 px-4 mb-2 font-normal'>
            {title}
          </strong>
        )}

        {outline.map(item => (
          <a key={item.id} href={`#${item.id}`} className='flex flex-col'>
            <Button
              variant='ghost'
              className={`w-full justify-start ${
                active === item.id
                  ? "text-neutral-900 font-semibold"
                  : "text-neutral-500"
              }`}
              onClick={() => {
                setActive(item.id)
              }}
            >
              {item.title}
            </Button>
          </a>
        ))}

        {children}
      </div>
    </div>
  )
}

export default Outline
