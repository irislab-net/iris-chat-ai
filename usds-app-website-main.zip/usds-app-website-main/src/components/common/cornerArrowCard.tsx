import { cn } from "@/lib/utils"
import { useGSAP } from "@gsap/react"
import { gsap } from "gsap"
import { ArrowDown, ArrowUpRight } from "lucide-react"
import { useRef, useState } from "react"
import { Link } from "react-router-dom"
import Frame from "./frame"

function CornerArrowCard({
  title,
  link,
  arrowDirection = "upRight",
  className,
  children,
}: {
  title: string
  link?: string
  arrowDirection?: "upRight" | "down"
  className?: string
  children?: React.ReactNode
}) {
  const arrowRef = useRef<HTMLDivElement>(null)
  const [isAnimating, setIsAnimating] = useState(false)
  const { contextSafe } = useGSAP()

  const handleMouseEnter = contextSafe(() => {
    if (isAnimating || !arrowRef.current) return

    setIsAnimating(true)

    const tl = gsap.timeline({
      onComplete: () => setIsAnimating(false),
    })

    tl.to(arrowRef.current, {
      x: arrowDirection === "upRight" ? "125%" : "0",
      y: arrowDirection === "upRight" ? "-125%" : "150%",
      duration: 0.2,
      ease: "sine.in",
    }).from(arrowRef.current, {
      x: arrowDirection === "upRight" ? "-125%" : "0",
      y: arrowDirection === "upRight" ? "125%" : "-125%",
      duration: 0.5,
      delay: 0.1,
      ease: "elastic.out(1,0.75)",
    })
  })

  return (
    <Link
      to={link ?? "#"}
      onMouseEnter={handleMouseEnter}
      target='_blank'
      rel='noopener noreferrer'
    >
      <Frame
        className={cn(
          "group flex flex-col gap-2 ps-5 pe-3 pt-4 pb-7 cursor-pointer border border-neutral-200/75 hover:border-neutral-300/75 transition-colors",
          className
        )}
      >
        <div className='flex items-start gap-4'>
          <strong className='text-lg md:text-xl font-medium pt-2'>
            {title}
          </strong>

          <div className='flex items-center justify-center min-w-10 size-10 ms-auto rounded-full overflow-hidden border border-neutral-200 group-hover:border-neutral-300 transition-colors'>
            <div ref={arrowRef}>
              {arrowDirection === "upRight" ? (
                <ArrowUpRight className='size-4' />
              ) : (
                <ArrowDown className='size-4' />
              )}
            </div>
          </div>
        </div>

        <div className='text-neutral-500 tracking-tight'>{children}</div>
      </Frame>
    </Link>
  )
}

export default CornerArrowCard
