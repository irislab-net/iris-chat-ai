import { cn } from "@/lib/utils"
import AnimatedText from "./animatedText"
import Heading from "./heading"
import LandingSection from "./landingSection"

function PageHeaderSection({
  header,
  description,
  className,
  children,
}: {
  header: string
  description?: string
  className?: string
  children?: React.ReactNode
}) {
  return (
    <LandingSection
      className={cn(
        "flex flex-wrap gap-2 items-end justify-between",
        className
      )}
    >
      <Heading animate className='text-2xl md:text-5xl'>
        {header}
      </Heading>

      {description && (
        <p className='text-base md:text-xl text-muted-foreground leading-7 font-medium max-w-md'>
          <AnimatedText>{description}</AnimatedText>
        </p>
      )}

      {children}
    </LandingSection>
  )
}

export default PageHeaderSection
