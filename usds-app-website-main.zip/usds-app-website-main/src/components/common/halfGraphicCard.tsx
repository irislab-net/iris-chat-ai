import { cn } from "@/lib/utils"
import { ArrowRight } from "lucide-react"
import { Button } from "../ui/button"
import Frame from "./frame"
import GraphicsPlaceholder from "./graphicsPlaceholder"
import type { SVGIcon } from "@/types/icon"
import ToggleAnimation from "./toggleAnimation"

function HalfGraphicalCard({
  title,
  description,
  reverse = false,
  buttonLink,
  buttonText = "Learn more",
  buttonClassName,
  className,
  ...props
}: {
  title?: string
  reverse?: boolean
  description?: string
  graphic?: React.ExoticComponent<React.ComponentPropsWithoutRef<"svg">> | React.ExoticComponent<React.ComponentPropsWithoutRef<"div">>
  icon?: SVGIcon
  buttonText?: string
  buttonLink?: string
  buttonClassName?: string
  className?: string
}) {
  return (
    <Frame
      className={cn(
        "flex flex-col md:flex-row md:items-center w-full bg-neutral-50 overflow-hidden",
        reverse && "md:flex-row-reverse",
        className
      )}
    >
      <div className='relative w-full md:w-1/2 !h-[180px] md:!h-[250px] overflow-hidden'>
        {props.graphic ? (
          <props.graphic className='size-full' />
        ) : props.icon ? (
          <div className='size-full p-4 flex items-center justify-center'>
            <ToggleAnimation
              scrollTrigger
              icon={props.icon}
              className='!size-22'
            />
          </div>
        ) : (
          <GraphicsPlaceholder className='h-full' />
        )}
      </div>

      <div className='flex-1 flex flex-col text-center md:text-left md:items-start gap-4 px-8 pb-8 md:pt-8 md:px-12 md:max-w-1/2'>
        {title && (
          <strong className='text-neutral-700 text-2xl font-semibold border-b border-neutral-300 pb-4 w-full font-brand'>
            {title}
          </strong>
        )}

        {description && <p className='text-neutral-500'>{description}</p>}

        {buttonLink && (
          <Button
            variant='underline'
            size='lg'
            className={cn(
              "border-neutral-500 !h-auto !px-1 !py-2",
              buttonClassName
            )}
          >
            <span>{buttonText}</span>
            <ArrowRight />
          </Button>
        )}
      </div>
    </Frame>
  )
}

export default HalfGraphicalCard
