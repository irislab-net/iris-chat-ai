import React from "react"

export const AaveIcon = React.forwardRef<
  SVGSVGElement,
  React.SVGProps<SVGSVGElement>
>((props, ref) => (
  <svg
    ref={ref}
    viewBox='0 0 190.5 190.5'
    fill='currentColor'
    className='size-[1em]'
    xmlns='http://www.w3.org/2000/svg'
    {...props}
  >
    <path d='M190.5,95.3C190.5,42.6,147.9,0,95.3,0S0,42.6,0,95.3s42.6,95.3,95.3,95.3S190.5,147.9,190.5,95.3   L190.5,95.3z' />
    <path
      fill='var(--background)'
      d='M77.5,99.9c8.2-1.3,13.7-9,12.4-17.2c-1.3-8.2-9-13.7-17.2-12.4c-8.2,1.3-13.7,9-12.4,17.2   C61.7,95.7,69.4,101.2,77.5,99.9L77.5,99.9z M116.7,99.9c8.2-1.3,13.7-9,12.4-17.2c-1.3-8.2-9-13.7-17.2-12.4   c-8.2,1.3-13.7,9-12.4,17.2C100.8,95.7,108.5,101.2,116.7,99.9L116.7,99.9z'
    />
    <path
      fill='var(--background)'
      d='M94.7,23.3C54,23.3,21,56.9,21,98.3h18.8c0-31.1,24.4-56.2,54.8-56.2c30.5,0,54.8,25.2,54.8,56.2h18.8   C168.4,56.9,135.4,23.3,94.7,23.3L94.7,23.3L94.7,23.3z'
    />
  </svg>
))
