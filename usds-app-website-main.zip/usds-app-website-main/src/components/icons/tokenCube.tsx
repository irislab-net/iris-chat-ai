import React from "react"

export const TokenCubeIcon = React.forwardRef<
  SVGSVGElement,
  React.SVGProps<SVGSVGElement>
>((props, ref) => (
  <svg
    ref={ref}
    viewBox='0 0 24 24'
    xmlns='http://www.w3.org/2000/svg'
    className='size-[1em]'
    fill='none'
    stroke='currentColor'
    strokeWidth='2'
    strokeLinecap='round'
    strokeLinejoin='round'
    {...props}
  >
    <path d='M12 21L5.04743 17.234C4.40205 16.8844 4 16.2094 4 15.4754V7.66667M12 21L18.9526 17.234C19.598 16.8844 20 16.2094 20 15.4754L20 7.66667M12 21V15M4 7.66667L11.0761 3.98118C11.6551 3.67962 12.3449 3.67962 12.9239 3.98118L20 7.66667M4 7.66667L9.36162 10.5709M20 7.66667L14.6384 10.5709M12 15C13.6569 15 15 13.6569 15 12C15 11.4826 14.869 10.9958 14.6384 10.5709M12 15C10.3431 15 9 13.6569 9 12C9 11.4826 9.13099 10.9958 9.36162 10.5709M14.6384 10.5709C14.1305 9.63523 13.1394 9 12 9C10.8606 9 9.8695 9.63523 9.36162 10.5709' />
  </svg>
))
