import { BrandLoadingMark } from "@/components/layout/BrandLoadingMark"
import {
  STAKING_BOOTSTRAP_DISMISSED_SESSION_KEY,
  STAKING_BOOTSTRAP_MIN_DISPLAY_MS,
} from "@/constants/stakingBootstrapKeys"
import { useBootstrapReadiness } from "@/contexts/BootstrapReadinessContext"
import { stakingLifecycleTrace } from "@/staking/diagnostics"
import { useEffect, useRef, useState } from "react"

function readSessionDismissed(): boolean {
  if (typeof sessionStorage === "undefined") return false
  try {
    return sessionStorage.getItem(STAKING_BOOTSTRAP_DISMISSED_SESSION_KEY) === "1"
  } catch {
    return false
  }
}

function writeSessionDismissed(): void {
  if (typeof sessionStorage === "undefined") return
  try {
    sessionStorage.setItem(STAKING_BOOTSTRAP_DISMISSED_SESSION_KEY, "1")
  } catch {
    /* private mode */
  }
}

/**
 * Full-screen branded loader gated on **real** bootstrap readiness (AppKit + staking vault
 * when on `/staking/app`), with a short minimum display time for branding polish only.
 * Session-scoped dismissal prevents “splash replay” on wallet handoff or tab resume.
 */
export function InitialSplashOverlay({
  minDisplayMs = STAKING_BOOTSTRAP_MIN_DISPLAY_MS,
}: {
  /** Cosmetic floor after readiness — secondary to real readiness signals */
  minDisplayMs?: number
}) {
  const { appKitReady, stakingVaultHydratedForSplash } = useBootstrapReadiness()
  const [gone, setGone] = useState(() => {
    const dismissed = readSessionDismissed()
    return dismissed
  })
  const primaryReady = appKitReady && stakingVaultHydratedForSplash
  const dismissTimerRef = useRef<number | null>(null)

  useEffect(() => {
    if (gone) return
    if (!primaryReady) {
      if (dismissTimerRef.current !== null) {
        window.clearTimeout(dismissTimerRef.current)
        dismissTimerRef.current = null
      }
      return
    }
    if (dismissTimerRef.current !== null) return
    dismissTimerRef.current = window.setTimeout(() => {
      dismissTimerRef.current = null
      writeSessionDismissed()
      setGone(true)
      stakingLifecycleTrace("bootstrap", "initial_splash_dismissed", {
        minDisplayMs,
      })
    }, minDisplayMs)
    return () => {
      if (dismissTimerRef.current !== null) {
        window.clearTimeout(dismissTimerRef.current)
        dismissTimerRef.current = null
      }
    }
  }, [gone, primaryReady, minDisplayMs])

  if (gone) return null

  return (
    <div
      className='fixed inset-0 z-9999 flex flex-col items-center justify-center bg-background'
      aria-busy
      aria-label='Loading'
    >
      <BrandLoadingMark />
    </div>
  )
}
