import { footerLinkColumns, footerSocialLinks } from "@/constants/footerConfig"
import { Link } from "react-router-dom"
import AnimatedLogo from "../common/animatedLogo"

function Footer() {
  return (
    <div className='pb-4'>
      <div className='bg-neutral-100 p-12 flex flex-col gap-8 rounded-xl'>
        <div className='flex flex-col md:flex-row gap-8'>
          <div className='flex flex-col flex-1 gap-3'>
            <div className='flex items-center gap-2 text-neutral-600'>
              <AnimatedLogo className='text-2xl' />
              <strong className='text-xl'>Matrix</strong>
            </div>

            <p className='text-neutral-500 text-xs text-left'>
              Matrix.com provides information and resources about the
              fundamentals of the decentralised non-custodial liquidity protocol
              called the Matrix Protocol, comprised of open-source
              self-executing smart contracts that are deployed on various
              permissionless public blockchains, such as Ethereum (the "Matrix
              Protocol" or the "Protocol"). Matrix Labs does not control or
              operate any version of the Matrix Protocol on any blockchain
              network.
            </p>
          </div>

          <div className='flex-1 grid gap-5 sm:grid-cols-2 md:grid-cols-3 text-sm text-left text-neutral-500 [&_a:hover]:text-neutral-700'>
            {footerLinkColumns.map(column => (
              <div
                key={column.title}
                className='flex flex-col items-start gap-2'
              >
                <strong className='text-neutral-600'>{column.title}</strong>

                {column.links.map(link => (
                  <Link key={link.title} to={link.link}>
                    {link.title}
                  </Link>
                ))}
              </div>
            ))}
          </div>
        </div>

        <div className='flex items-center gap-4'>
          {footerSocialLinks.map(link => (
            <Link
              key={link.title}
              to={link.link}
              title={link.title}
              target='_blank'
              rel='noopener noreferrer'
            >
              <link.icon className='size-6 text-neutral-500 hover:text-neutral-900' />
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}

export default Footer
