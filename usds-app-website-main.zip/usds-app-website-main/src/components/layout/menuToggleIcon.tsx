import { cn } from "@/lib/utils"
import { useRef } from "react"
import { gsap } from "gsap"
import { useGSAP } from "@gsap/react"

interface MenuToggleIconProps {
  className?: string
  isOpen?: boolean
}

function MenuToggleIcon({ className, isOpen = false }: MenuToggleIconProps) {
  const topLineRef = useRef<SVGPathElement>(null)
  const middleLineRef = useRef<SVGPathElement>(null)
  const bottomLineRef = useRef<SVGPathElement>(null)

  useGSAP(() => {
    const tl = gsap.timeline()

    gsap.set(topLineRef.current, {
      transformOrigin: "left",
    })
    gsap.set(bottomLineRef.current, {
      transformOrigin: "left",
    })
    gsap.set(middleLineRef.current, {
      transformOrigin: "center",
    })

    if (isOpen) {
      // Animate to X
      tl.to(topLineRef.current, {
        rotation: 45,
        duration: 0.3,
        x: 4,
        ease: "back.out",
      })
        .to(
          bottomLineRef.current,
          {
            rotation: -45,
            duration: 0.3,
            x: 4,
            ease: "back.out",
          },
          0
        )
        .to(
          middleLineRef.current,
          {
            scaleX: 0,
            opacity: 0,
            duration: 0.3,
            ease: "power2.out",
          },
          0
        )
    } else {
      // Animate back to hamburger
      tl.to(topLineRef.current, {
        rotation: 0,
        y: 0,
        x: 0,
        duration: 0.3,
        ease: "back.out",
      })
        .to(
          bottomLineRef.current,
          {
            rotation: 0,
            y: 0,
            x: 0,
            duration: 0.3,
            ease: "back.out",
          },
          0
        )
        .to(
          middleLineRef.current,
          {
            scaleX: 1,
            opacity: 1,
            duration: 0.3,
            ease: "power2.out",
          },
          0
        )
    }
  }, [isOpen])

  return (
    <svg
      viewBox='0 0 24 24'
      fill='none'
      stroke='currentColor'
      strokeWidth='2'
      strokeLinecap='round'
      strokeLinejoin='round'
      overflow='visible'
      xmlns='http://www.w3.org/2000/svg'
      className={cn("size-[1em]", className)}
    >
      <path ref={topLineRef} d='M3 6H21' />
      <path ref={middleLineRef} d='M3 12H21' />
      <path ref={bottomLineRef} d='M3 18H21' />
    </svg>
  )
}

export default MenuToggleIcon
