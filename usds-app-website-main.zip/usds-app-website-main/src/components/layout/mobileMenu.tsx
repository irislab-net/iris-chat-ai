import menuItems from "@/constants/menuConfig"
import { cn } from "@/lib/utils"
import { Link, useLocation } from "react-router-dom"
import DocsSidebar from "../pages/docs/docsSidebar"

function MobileMenu({
  isOpen,
  onClose,
}: {
  isOpen: boolean
  onClose: () => void
}) {
  const location = useLocation()

  const isDocsPage = location.pathname.startsWith("/docs")

  return (
    <>
      {/* Full Screen Menu */}
      <div
        className={cn(
          "fixed inset-0 bg-background z-30 md:hidden transition-all duration-300 ease-in-out",
          isOpen
            ? "opacity-100 translate-y-0 pointer-events-auto"
            : "opacity-0 translate-y-4 pointer-events-none"
        )}
        style={{ top: "56px" }}
      >
        {/* Menu Content */}
        <div className='h-full flex flex-col'>
          {/* Menu Items */}
          {isDocsPage ? (
            <DocsSidebar
              className='flex-1 p-6 overflow-y-auto'
              onLinkClick={onClose}
            />
          ) : (
            <div className='flex-1 p-6 space-y-4 overflow-y-auto'>
              {menuItems.map(item => {
                const largeItems = item.subItems?.filter(
                  subItem => subItem.largeInMobile
                )
                const smallItems = item.subItems?.filter(
                  subItem => !subItem.largeInMobile
                )

                return (
                  <div key={item.title} className='space-y-2'>
                    <div className='pb-3 rounded-lg space-y-4'>
                      <div className='font-medium text-foreground text-lg mb-2'>
                        {item.title}
                      </div>

                      {largeItems && (
                        <div className='space-y-4'>
                          {largeItems.map(product => {
                            const Icon = product.icon

                            return (
                              <Link
                                key={product.title}
                                to={product.link || "#"}
                                onClick={onClose}
                                className='block rounded-md hover:bg-accent transition-colors'
                              >
                                <div className='relative flex flex-col gap-3 bg-neutral-800 text-background rounded-lg p-4 overflow-hidden'>
                                  {Icon && <Icon className='size-7' />}

                                  <div className='flex flex-col'>
                                    <div className='font-semibold text-sm'>
                                      {product.title}
                                    </div>

                                    {product.description && (
                                      <div className='text-xs text-neutral-400'>
                                        {product.description}
                                      </div>
                                    )}
                                  </div>

                                  <div className='absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/4 opacity-5'>
                                    {Icon && <Icon className='size-18' />}
                                  </div>
                                </div>
                              </Link>
                            )
                          })}
                        </div>
                      )}

                      {smallItems && (
                        <div className='space-y-4'>
                          {smallItems.map(subItem => {
                            const Icon = subItem.icon

                            return (
                              <Link
                                key={subItem.title}
                                to={subItem.link || "#"}
                                onClick={onClose}
                                className='group/link flex items-center gap-3 p-2 rounded-md hover:bg-neutral-100 transition-colors'
                              >
                                {Icon && (
                                  <div className='p-3 rounded-lg bg-neutral-50 group-hover/link:bg-background transition-colors'>
                                    <Icon className='size-6 text-neutral-600' />
                                  </div>
                                )}

                                <div className='flex-1'>
                                  <div className='font-semibold text-neutral-700 text-sm'>
                                    {subItem.title}
                                  </div>

                                  {subItem.description && (
                                    <div className='text-xs text-neutral-500'>
                                      {subItem.description}
                                    </div>
                                  )}
                                </div>
                              </Link>
                            )
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </>
  )
}

export default MobileMenu
