import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"
import menuItems from "@/constants/menuConfig"
import { useAppKitReady } from "@/hooks/useAppKitReady"
import { cn } from "@/lib/utils"
import type { AnimationHandle } from "@/types/animation"
import type { SubMenuItem } from "@/types/menu"
import React, { memo, useCallback, useEffect, useRef, useState } from "react"
import { Link, useLocation } from "react-router-dom"
import USDMIcon from "@/components/icons/usdm"
import GlowingButton from "../common/glowingButton"
import { Button } from "../ui/button"
import MenuToggleIcon from "./menuToggleIcon"
import MobileMenu from "./mobileMenu"
import {
  NavbarStatusPillsDesktop,
  NavbarStatusPillsMobile,
} from "./navbarStatusPills"
import { NavbarWalletDesktop, NavbarWalletMobile } from "./NavbarWalletSection"

const ListItem = memo(function ListItem({
  title,
  children,
  href,
  onHover,
  icon: Icon,
  subItem,
  index,
  setItemRef,
  ...props
}: React.ComponentPropsWithoutRef<"li"> & {
  href: string
  onHover: (subItem: SubMenuItem, index: number) => void
  icon?: React.ComponentType<{ className?: string }>
  iconClassName?: string
  subItem: SubMenuItem
  index: number
  setItemRef: (index: number, ref: HTMLLIElement | null) => void
}) {
  const itemRef = useRef<HTMLLIElement>(null)

  useEffect(() => {
    setItemRef(index, itemRef.current)
  }, [index, setItemRef])

  return (
    <li
      ref={itemRef}
      {...props}
      onMouseEnter={() => onHover(subItem, index)}
      className='relative z-10 [&>a]:bg-transparent [&>a]:hover:bg-transparent [&>a]:focus:bg-transparent'
    >
      <NavigationMenuLink asChild>
        <Link to={href} className='group/list-item block'>
          <div className='flex items-start gap-3 rounded-md'>
            {Icon && (
              <div className='flex items-center justify-center size-10 rounded-md bg-background border border-neutral-100'>
                <Icon className='size-4 text-neutral-400 group-hover/list-item:text-neutral-700 transition-[color,transform] duration-300' />
              </div>
            )}

            <div className='flex-1'>
              <div className='text-sm leading-none font-medium'>{title}</div>
              <p className='text-muted-foreground text-nowrap text-sm leading-snug mt-1'>
                {children}
              </p>
            </div>
          </div>
        </Link>
      </NavigationMenuLink>
    </li>
  )
})

function ItemGraphics({ item }: { item: SubMenuItem }) {
  const iconRef = useRef<AnimationHandle>(null)

  const iconClassName = "size-32 animate-appear"

  useEffect(() => {
    setTimeout(() => {
      if (iconRef.current) {
        iconRef.current.play()
      }
    }, 200)
  }, [item])

  return (
    <div className='relative flex h-full w-[250px] px-4 py-8 items-center justify-center rounded-xl bg-neutral-900 text-background transition-[background-color,color,opacity] duration-300'>
      <div className='relative flex pointer-events-none z-10'>
        {[item].map(i => (
          <React.Fragment key={i.title}>
            {!i.animatedIcon && i.icon && <i.icon className={iconClassName} />}

            {i.animatedIcon && (
              <i.animatedIcon ref={iconRef} className={iconClassName} />
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  )
}

function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [hoveredItem, setHoveredItem] = useState<SubMenuItem | null>(null)
  const [, setHoveredIndex] = useState(0)
  const [backgroundPosition, setBackgroundPosition] = useState({
    top: 0,
  })
  const [progress, setProgress] = useState(0)
  const [isProgressActive, setIsProgressActive] = useState(false)

  const itemRefs = useRef<{ [key: number]: HTMLLIElement | null }>({})
  const hoverMeasureRafRef = useRef<number | null>(null)
  const location = useLocation()

  const isDocsPage = location.pathname.startsWith("/docs")
  const isRootDocsPage = location.pathname === "/docs"
  const isHomeLandingPage = location.pathname === "/"
  const isStakingApp = location.pathname === "/app"
  const isStakingPage = isHomeLandingPage || isStakingApp
  const appKitReady = useAppKitReady()

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY

      setIsScrolled(scrollTop > 35)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    return () => {
      if (hoverMeasureRafRef.current !== null) {
        cancelAnimationFrame(hoverMeasureRafRef.current)
        hoverMeasureRafRef.current = null
      }
    }
  }, [])

  // Initialize background position to first item
  useEffect(() => {
    const timer = setTimeout(() => {
      requestAnimationFrame(() => {
        const firstItem = itemRefs.current[0]
        if (firstItem) {
          const rect = firstItem.getBoundingClientRect()
          const parentRect = firstItem.parentElement?.getBoundingClientRect()

          if (parentRect) {
            setBackgroundPosition({
              top: rect.top - parentRect.top,
            })
          }
        }
      })
    }, 100) // Small delay to ensure refs are set

    return () => clearTimeout(timer)
  }, [])

  // Animate the progress bar when navigating
  useEffect(() => {
    setProgress(0)

    const raf = requestAnimationFrame(() => {
      setIsProgressActive(true)
      setProgress(Math.max(30, Math.random() * 70))
    })

    // When location changes settle, complete the bar
    const finish = setTimeout(() => {
      setProgress(100)

      setTimeout(() => {
        setIsProgressActive(false)

        setTimeout(() => {
          setProgress(0)
          cancelAnimationFrame(raf)
        }, 100)
      }, 300) // wait for transition
    }, 600) // adjust this to match your data load speed

    return () => {
      clearTimeout(finish)
      cancelAnimationFrame(raf)
    }
  }, [location])

  const openMobileMenu = () => {
    setIsMobileMenuOpen(true)
    document.body.style.overflowY = "hidden"
  }

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false)
    document.body.style.overflowY = "auto"
  }

  const toggleMobileMenu = () => {
    if (isMobileMenuOpen) {
      closeMobileMenu()
    } else {
      openMobileMenu()
    }
  }

  const setItemRef = useCallback((index: number, ref: HTMLLIElement | null) => {
    itemRefs.current[index] = ref
  }, [])

  const scheduleMenuBackgroundMeasure = useCallback((index: number | "first") => {
    if (hoverMeasureRafRef.current !== null) {
      cancelAnimationFrame(hoverMeasureRafRef.current)
    }
    hoverMeasureRafRef.current = requestAnimationFrame(() => {
      hoverMeasureRafRef.current = null
      const itemElement =
        index === "first" ? itemRefs.current[0] : itemRefs.current[index]
      if (!itemElement) return
      const rect = itemElement.getBoundingClientRect()
      const parentRect = itemElement.parentElement?.getBoundingClientRect()
      if (!parentRect) return
      setBackgroundPosition({
        top: rect.top - parentRect.top,
      })
    })
  }, [])

  const handleItemHover = useCallback(
    (subItem: SubMenuItem, index: number) => {
      setHoveredItem(subItem)
      setHoveredIndex(index)
      scheduleMenuBackgroundMeasure(index)
    },
    [scheduleMenuBackgroundMeasure],
  )

  const clearHoveredItem = useCallback(() => {
    setHoveredItem(null)
    scheduleMenuBackgroundMeasure("first")
  }, [scheduleMenuBackgroundMeasure])

  return (
    <div
      className={cn(
        "fixed top-0 inset-x-0 z-50 bg-background transition-[transform] duration-500",
        isScrolled && !isStakingPage && "md:-translate-y-6"
      )}
    >
      {isDocsPage && !isRootDocsPage && (
        <div
          className={cn(
            "fixed top-0 left-0 right-0 h-1 bg-blue-500 transition-[opacity,transform] duration-300 origin-left opacity-0",
            isProgressActive && "opacity-100"
          )}
          style={{ transform: `scaleX(${progress / 100})` }}
        ></div>
      )}

      <div className='md:pt-6 md:px-12 max-w-[1080px] mx-auto'>
        <nav className='relative flex justify-between items-center px-6 md:px-0'>
          <Link
            to='/'
            className='flex h-[56px] items-center gap-2'
            onClick={closeMobileMenu}
            aria-label='Matrix USDM home'
          >
            <GlowingButton
              asGlowShell
              loopGlow={isHomeLandingPage}
              className='size-9 shrink-0 rounded-full'
            >
              <span className='relative z-10 flex size-9 items-center justify-center overflow-visible rounded-full bg-background'>
                <USDMIcon
                  autoplay
                  repeat={-1}
                  repeatDelay={2.5}
                  className='size-8 shrink-0 overflow-visible text-neutral-800'
                  aria-hidden
                />
              </span>
            </GlowingButton>

            {isDocsPage && (
              <small className='animate-appear text-neutral-500 text-sm'>
                Documentation
              </small>
            )}
          </Link>

          <div className='hidden md:flex items-center gap-4'>
            <NavbarStatusPillsDesktop loopGlow={isHomeLandingPage} />

            <div className='flex items-center gap-2'>
              <NavigationMenu>
                <NavigationMenuList>
                  {menuItems.map(item => (
                    <NavigationMenuItem key={item.title}>
                      <GlowingButton
                        asGlowShell
                        loopGlow={isHomeLandingPage}
                      >
                        <NavigationMenuTrigger
                          asChild
                          onMouseEnter={clearHoveredItem}
                          className='inline-flex h-8 w-auto rounded-[inherit] p-0 text-sm font-medium shadow-none bg-background hover:bg-accent hover:text-accent-foreground focus:bg-accent focus-visible:ring-0 data-[state=open]:bg-accent/50 data-[state=open]:text-accent-foreground data-[state=open]:hover:bg-accent'
                        >
                          <Button
                            variant='outline'
                            size='sm'
                            className='relative z-10 h-8 rounded-[inherit] bg-clip-padding px-3!'
                          >
                            <span className='text-xs'>{item.title}</span>
                          </Button>
                        </NavigationMenuTrigger>
                      </GlowingButton>

                      <NavigationMenuContent>
                        <div className='flex gap-2'>
                          {item.subItems && item.subItems.length > 0 && (
                            <>
                              <div className='group/menu-content flex-1 relative'>
                                {/* Moving background element */}
                                <div
                                  className='absolute left-0 right-0 bg-muted/50 rounded-md h-14 opacity-0 scale-90 transition-[opacity,transform] duration-300 ease-out will-change-[opacity,transform] group-hover/menu-content:opacity-100 group-hover/menu-content:scale-100'
                                  style={{
                                    top: `${backgroundPosition.top}px`,
                                  }}
                                />

                                <ul className='relative'>
                                  {item.subItems.map((subItem, index) => (
                                    <ListItem
                                      key={subItem.title}
                                      href={subItem.link || "#"}
                                      title={subItem.title}
                                      onHover={handleItemHover}
                                      icon={subItem.icon}
                                      iconClassName={subItem.iconClassName}
                                      subItem={subItem}
                                      index={index}
                                      setItemRef={setItemRef}
                                    >
                                      {subItem.description}
                                    </ListItem>
                                  ))}
                                </ul>
                              </div>

                              <div className='flex-1'>
                                <ItemGraphics
                                  item={hoveredItem || item.subItems[0]}
                                />
                              </div>
                            </>
                          )}
                        </div>
                      </NavigationMenuContent>
                    </NavigationMenuItem>
                  ))}
                </NavigationMenuList>
              </NavigationMenu>

              {appKitReady ? (
                <NavbarWalletDesktop loopGlow={isHomeLandingPage} />
              ) : (
                <div
                  className='h-10 min-w-[148px] animate-pulse rounded-4xl bg-neutral-100'
                  aria-hidden
                />
              )}
            </div>
          </div>

          <div className='flex items-center gap-2 md:hidden'>
            <NavbarStatusPillsMobile loopGlow={isHomeLandingPage} />

            {appKitReady ? (
              <NavbarWalletMobile loopGlow={isHomeLandingPage} />
            ) : (
              <div
                className='h-8 min-w-[108px] animate-pulse rounded-4xl bg-neutral-100'
                aria-hidden
              />
            )}
            
            <GlowingButton
              variant='outline'
              size='sm'
              buttonClassName='!px-2.5'
              onClick={toggleMobileMenu}
              aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
            >
              <MenuToggleIcon
                className='text-xl text-neutral-700'
                isOpen={isMobileMenuOpen}
              />
            </GlowingButton>

       
          </div>

          <div
            className={`h-px absolute bottom-0 inset-x-1 bg-neutral-200 transition-opacity duration-300 ${isScrolled ? "opacity-100" : "opacity-0"
              }`}
          ></div>
        </nav>
      </div>

      {isStakingPage ? (
        <div
          aria-hidden
          className='pointer-events-none absolute top-full inset-x-0 z-10 h-3 bg-linear-to-b from-background to-transparent'
        />
      ) : null}

      {/* Mobile Menu */}
      <MobileMenu isOpen={isMobileMenuOpen} onClose={closeMobileMenu} />
    </div>
  )
}

export default Navbar
