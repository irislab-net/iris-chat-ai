import * as React from "react"

import { cn } from "@/lib/utils"

type AvatarLoadState = {
  imageFailed: boolean
  setImageFailed: (failed: boolean) => void
}

const AvatarLoadContext = React.createContext<AvatarLoadState | null>(null)

function Avatar({ className, children, ...props }: React.ComponentProps<"span">) {
  const [imageFailed, setImageFailed] = React.useState(false)
  const value = React.useMemo(
    () => ({ imageFailed, setImageFailed }),
    [imageFailed]
  )
  return (
    <span
      data-slot="avatar"
      className={cn(
        "relative flex shrink-0 overflow-hidden rounded-full border border-neutral-200/75 bg-white/95",
        className
      )}
      {...props}
    >
      <AvatarLoadContext.Provider value={value}>
        {children}
      </AvatarLoadContext.Provider>
    </span>
  )
}

function AvatarImage({
  className,
  onError,
  ...props
}: React.ComponentProps<"img">) {
  const ctx = React.useContext(AvatarLoadContext)
  if (ctx?.imageFailed) return null
  return (
    <img
      data-slot="avatar-image"
      className={cn("aspect-square size-full object-contain", className)}
      onError={e => {
        onError?.(e)
        ctx?.setImageFailed(true)
      }}
      {...props}
    />
  )
}

function AvatarFallback({
  className,
  children,
  ...props
}: React.ComponentProps<"span">) {
  const ctx = React.useContext(AvatarLoadContext)
  if (!ctx?.imageFailed) return null
  return (
    <span
      data-slot="avatar-fallback"
      className={cn(
        "flex size-full items-center justify-center rounded-full bg-neutral-100 text-[9px] font-semibold tracking-tight text-neutral-600",
        className
      )}
      {...props}
    >
      {children}
    </span>
  )
}

export { Avatar, AvatarImage, AvatarFallback }
