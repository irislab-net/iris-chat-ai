import {
  STAKING_TOAST_DESKTOP_OFFSET,
  STAKING_TOAST_MEDIA_NARROW,
  STAKING_TOAST_MOBILE_OFFSET,
} from "@/constants/stakingNotificationLayout"
import { cn } from "@/lib/utils"
import type { CSSProperties } from "react"
import { useSyncExternalStore } from "react"
import { Toaster as Sonner, type ToasterProps } from "sonner"

import "./staking-sonner.css"

function subscribeNarrowViewport(onStoreChange: () => void): () => void {
  if (typeof window === "undefined") return () => {}
  const mq = window.matchMedia(STAKING_TOAST_MEDIA_NARROW)
  const listener = () => onStoreChange()
  mq.addEventListener("change", listener)
  return () => mq.removeEventListener("change", listener)
}

function getNarrowViewportSnapshot(): boolean {
  return (
    typeof window !== "undefined" &&
    window.matchMedia(STAKING_TOAST_MEDIA_NARROW).matches
  )
}

function getNarrowViewportServerSnapshot(): boolean {
  return false
}

function useStakingNarrowToastViewport(): boolean {
  return useSyncExternalStore(
    subscribeNarrowViewport,
    getNarrowViewportSnapshot,
    getNarrowViewportServerSnapshot
  )
}

const STAKING_SONNER_TOAST_OPTIONS: NonNullable<ToasterProps["toastOptions"]> = {
  classNames: {
    toast: cn("min-w-0 shadow-none"),
    content: "min-w-0 flex-1",
  },
}

const Toaster = ({
  position: positionProp,
  offset: offsetProp,
  mobileOffset: mobileOffsetProp,
  toastOptions: toastOptionsProp,
  className: classNameProp,
  style: styleProp,
  theme,
  ...restProps
}: ToasterProps) => {
  void theme
  const narrow = useStakingNarrowToastViewport()
  const position =
    positionProp ?? (narrow ? "top-center" : "bottom-right")
  const offset = offsetProp ?? STAKING_TOAST_DESKTOP_OFFSET
  const mobileOffset = mobileOffsetProp ?? STAKING_TOAST_MOBILE_OFFSET

  const toastOptions: ToasterProps["toastOptions"] = {
    ...STAKING_SONNER_TOAST_OPTIONS,
    ...toastOptionsProp,
    classNames: {
      ...STAKING_SONNER_TOAST_OPTIONS.classNames,
      ...toastOptionsProp?.classNames,
    },
  }

  return (
    <Sonner
      {...restProps}
      position={position}
      offset={offset}
      mobileOffset={mobileOffset}
      theme="light"
      richColors={false}
      gap={10}
      className={cn("staking-sonner-toaster", "toaster group", classNameProp)}
      toastOptions={toastOptions}
      style={
        {
          ...(styleProp && typeof styleProp === "object" ? styleProp : {}),
          "--border-radius": "1.25rem",
          "--normal-bg": "rgba(255, 255, 255, 0.55)",
          "--normal-text": "rgb(23 23 23)",
          "--normal-border": "rgba(255, 255, 255, 0.5)",
        } as CSSProperties
      }
    />
  )
}

export { Toaster }
