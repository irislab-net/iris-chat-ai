import { initializeAppKit } from "@/lib/appKitBootstrap"
import { initSentry } from "@/lib/sentry"
import { ensureCryptoRandomUuidPolyfill } from "@/lib/safeRandomUuid"
import {
  installRuntimeBuildChangeObservation,
} from "@/lib/runtimeDeployCorrelation"
import { installStaleChunkRecovery } from "@/lib/wallet/installStaleChunkRecovery"
import { installWalletConnectHandoffTiming } from "@/lib/wallet/walletConnectHandoffTiming"
import { installWalletConnectGlobalErrorRecovery } from "@/lib/wallet/walletConnectSessionRecovery"
import { useGSAP } from "@gsap/react"
import gsap from "gsap"

ensureCryptoRandomUuidPolyfill()
installStaleChunkRecovery()
installWalletConnectGlobalErrorRecovery()
initSentry()
installRuntimeBuildChangeObservation()
installWalletConnectHandoffTiming()
if (typeof window !== "undefined") {
  void initializeAppKit()
}
import DrawSVGPlugin from "gsap/DrawSVGPlugin"
import MorphSVGPlugin from "gsap/MorphSVGPlugin"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { SplitText } from "gsap/SplitText"
import { StrictMode } from "react"
import { createRoot } from "react-dom/client"
import App from "./App.tsx"
import "./index.css"
import { getRuntimeTelemetryRolloutStage, getSentryDsn } from "@/config/env"
import {
  installRuntimeTelemetryDevMemorySink,
  registerRuntimeTelemetryOpenTelemetryLikeSink,
} from "@/lib/runtimeTelemetry/runtimeTelemetry"
import {
  installStakingVisibilityBreadcrumbs,
  registerStakingRuntimeTelemetrySentryBridge,
} from "@/lib/stakingSentry"

installStakingVisibilityBreadcrumbs()

if (getSentryDsn()) {
  registerStakingRuntimeTelemetrySentryBridge()
}
if (getRuntimeTelemetryRolloutStage() >= 1) {
  if (import.meta.env.DEV) {
    installRuntimeTelemetryDevMemorySink()
  }
  registerRuntimeTelemetryOpenTelemetryLikeSink()
}

gsap.registerPlugin(useGSAP)
gsap.registerPlugin(DrawSVGPlugin)
gsap.registerPlugin(MorphSVGPlugin)
gsap.registerPlugin(ScrollTrigger)
gsap.registerPlugin(SplitText)

if (import.meta.env.DEV) {
  void import("gsap/GSDevTools").then(({ default: GSDevTools }) => {
    gsap.registerPlugin(GSDevTools)
  })
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
