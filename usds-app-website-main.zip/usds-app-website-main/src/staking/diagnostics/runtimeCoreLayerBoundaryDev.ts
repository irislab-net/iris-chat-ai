/**
 * DEV-only static import boundary check for `staking/core` and `staking/dev`.
 * Loaded once when runtime selection boots (see `runtimeSelectionContext.tsx`).
 */

const FORBIDDEN_IMPORT_PREFIXES = [
  "@/components/",
  "@/hooks/",
  "components/pages/",
  "from \"@/pages/",
  "from '@/pages/",
] as const

const CORE_GLOB = import.meta.glob("../core/**/*.ts", {
  query: "?raw",
  import: "default",
  eager: true,
}) as Record<string, string>

const DEV_GLOB = import.meta.glob("../dev/**/*.ts", {
  query: "?raw",
  import: "default",
  eager: true,
}) as Record<string, string>

function collectForbiddenImportViolations(): string[] {
  const violations: string[] = []
  const entries = { ...CORE_GLOB, ...DEV_GLOB }

  for (const [path, source] of Object.entries(entries)) {
    if (path.endsWith("runtimeCoreLayerBoundaryDev.ts")) continue
    for (const prefix of FORBIDDEN_IMPORT_PREFIXES) {
      if (source.includes(prefix)) {
        violations.push(`${path} → ${prefix}`)
      }
    }
  }
  return violations
}

function runRuntimeCoreLayerBoundaryCheckDev(): void {
  if (!import.meta.env.DEV) return

  const violations = collectForbiddenImportViolations()
  if (violations.length === 0) {
    console.debug("[runtime-core-boundary] staking/core+dev: no forbidden imports")
    return
  }

  console.error(
    "[runtime-core-boundary] staking/core or staking/dev imports forbidden layers:",
    violations
  )
}

runRuntimeCoreLayerBoundaryCheckDev()
