import { cn } from "@/lib/utils"

/**
 * Visual-only class names for staking amount sliders (deposit / withdraw).
 * Radix Slider primitive, value math, and form slot hierarchy stay unchanged.
 *
 * Note: avoid `transform: scale()` on the thumb — Radix positions it with inline
 * `transform`, which would override class-based scaling. Depth uses shadow + filter.
 */
export const STAKING_AMOUNT_SLIDER_ROOT_CLASSNAME = cn(
  "isolate py-1.5 motion-reduce:transition-none"
)

/** Inactive rail: layered glass, dual-frequency tick texture, ambient depth */
export const STAKING_AMOUNT_SLIDER_TRACK_CLASSNAME = cn(
  "border border-white/55",
  "shadow-[inset_0_1px_2px_rgba(255,255,255,0.92),inset_0_-1px_1px_rgba(15,23,42,0.09),0_1px_2px_rgba(15,23,42,0.06),0_4px_14px_-4px_rgba(15,23,42,0.1),0_14px_32px_-14px_rgba(15,23,42,0.07)]",
  "bg-[linear-gradient(180deg,rgba(255,255,255,0.62)_0%,rgba(246,247,249,0.98)_42%,rgba(228,230,235,1)_100%),linear-gradient(180deg,rgba(255,255,255,0.35)_0%,transparent_55%),repeating-linear-gradient(90deg,rgba(255,255,255,0)_0px,rgba(255,255,255,0)_9px,rgba(15,23,42,0.034)_9px,rgba(15,23,42,0.034)_10px),repeating-linear-gradient(90deg,rgba(255,255,255,0)_0px,rgba(255,255,255,0)_39px,rgba(15,23,42,0.02)_39px,rgba(15,23,42,0.02)_40px)]",
  "data-[orientation=horizontal]:h-2.5 sm:data-[orientation=horizontal]:h-2.5"
)

/** Polished black glass fill — vertical gloss, specular lip, bloom into inactive */
export const STAKING_AMOUNT_SLIDER_RANGE_CLASSNAME = cn(
  "rounded-full",
  "origin-center scale-y-[1.14] will-change-transform",
  "bg-[linear-gradient(180deg,#c4c4c4_0%,#6a6a6a_10%,#383838_28%,#181818_58%,#0b0b0b_82%,#030303_100%)]",
  "shadow-[inset_0_2px_1px_rgba(255,255,255,0.45),inset_0_-4px_8px_rgba(0,0,0,0.55),inset_0_-18px_22px_-14px_rgba(0,0,0,0.35),0_0_0_1px_rgba(255,255,255,0.12),1px_0_2px_rgba(0,0,0,0.35),5px_0_18px_-3px_rgba(0,0,0,0.42),12px_0_36px_-8px_rgba(255,255,255,0.07),0_-1px_0_rgba(255,255,255,0.06)]"
)

/**
 * Reference-style knob: dense glossy black graphite shell + smaller inset pearl center.
 * `::before` is a filled disk (not a ring). Avoid scale() — Radix uses inline transform.
 */
export const STAKING_AMOUNT_SLIDER_THUMB_CLASSNAME = cn(
  "relative z-10 size-[24px] shrink-0 rounded-full",
  "cursor-grab active:cursor-grabbing",
  "border border-white/[0.07]",
  "bg-[radial-gradient(ellipse_92%_86%_at_50%_16%,rgba(255,255,255,0.24)_0%,rgba(255,255,255,0.05)_24%,transparent_48%),radial-gradient(circle_at_50%_112%,rgba(255,255,255,0.05)_0%,transparent_42%),linear-gradient(148deg,#353535_0%,#161616_38%,#0a0a0a_72%,#030303_100%)]",
  "shadow-[0_0_0_0.5px_rgba(255,255,255,0.06),inset_0_2px_3px_rgba(255,255,255,0.14),inset_0_-4px_8px_rgba(0,0,0,0.55),0_1px_2px_rgba(0,0,0,0.35),0_4px_10px_-2px_rgba(0,0,0,0.45),0_10px_22px_-8px_rgba(0,0,0,0.35)]",
  "outline-none ring-0 ring-offset-0 hover:ring-0 hover:ring-offset-0",
  "before:pointer-events-none before:absolute before:inset-0 before:m-auto before:size-[8px] before:rounded-full",
  "before:bg-[radial-gradient(circle_at_50%_42%,#ffffff_0%,#f3f3f3_52%,#e4e4e4_88%)]",
  "before:shadow-[inset_0_1px_1px_rgba(255,255,255,0.92),inset_0_-1px_2px_rgba(0,0,0,0.1),0_0_6px_-1px_rgba(0,0,0,0.35)]",
  "before:content-['']",
  "transition-[box-shadow,filter] duration-200 ease-[cubic-bezier(0.25,0.1,0.25,1)]",
  "hover:brightness-[1.04] hover:shadow-[0_0_0_0.5px_rgba(255,255,255,0.08),inset_0_2px_4px_rgba(255,255,255,0.18),inset_0_-4px_9px_rgba(0,0,0,0.58),0_1px_3px_rgba(0,0,0,0.4),0_5px_14px_-2px_rgba(0,0,0,0.48),0_12px_26px_-8px_rgba(0,0,0,0.38)]",
  "focus-visible:brightness-[1.04] focus-visible:shadow-[0_0_0_0.5px_rgba(255,255,255,0.08),inset_0_2px_4px_rgba(255,255,255,0.18),inset_0_-4px_9px_rgba(0,0,0,0.58),0_1px_3px_rgba(0,0,0,0.4),0_5px_14px_-2px_rgba(0,0,0,0.48),0_12px_26px_-8px_rgba(0,0,0,0.38)]",
  "focus-visible:ring-2 focus-visible:ring-white/22 focus-visible:ring-offset-0",
  "active:brightness-[0.97] active:shadow-[0_0_0_0.5px_rgba(255,255,255,0.07),inset_0_1px_3px_rgba(255,255,255,0.12),inset_0_-3px_7px_rgba(0,0,0,0.52),0_1px_2px_rgba(0,0,0,0.42),0_3px_8px_-1px_rgba(0,0,0,0.5),0_8px_18px_-6px_rgba(0,0,0,0.4)]",
  "disabled:cursor-not-allowed disabled:brightness-100",
  "disabled:hover:shadow-[0_0_0_0.5px_rgba(255,255,255,0.06),inset_0_2px_3px_rgba(255,255,255,0.14),inset_0_-4px_8px_rgba(0,0,0,0.55),0_1px_2px_rgba(0,0,0,0.35),0_4px_10px_-2px_rgba(0,0,0,0.45),0_10px_22px_-8px_rgba(0,0,0,0.35)]",
  "disabled:active:shadow-[0_0_0_0.5px_rgba(255,255,255,0.06),inset_0_2px_3px_rgba(255,255,255,0.14),inset_0_-4px_8px_rgba(0,0,0,0.55),0_1px_2px_rgba(0,0,0,0.35),0_4px_10px_-2px_rgba(0,0,0,0.45),0_10px_22px_-8px_rgba(0,0,0,0.35)]",
  "motion-reduce:transition-none motion-reduce:hover:brightness-100 motion-reduce:focus-visible:brightness-100 motion-reduce:active:brightness-100"
)
