import { cn } from "@/lib/utils"

/**
 * Shared staking field chrome: amount inputs, select triggers, and similar controls.
 * Mobile-first per product spec; `sm:` matches desktop tightening.
 * Body text uses `text-base` (16px) below `sm` so iOS Safari does not auto-zoom on focus.
 */
export const STAKING_INPUT_BASE = cn(
  "w-full min-w-0 border bg-white/90 py-0 shadow-xs",
  "h-11 min-h-11 rounded-xl px-3.5",
  "text-base text-neutral-800",
  "placeholder:text-[13px] placeholder:leading-snug placeholder:text-neutral-400/85 sm:placeholder:text-sm",
  "sm:h-9 sm:min-h-9 sm:px-3 sm:text-sm",
  "outline-none transition-[border-color,box-shadow] duration-300",
  "focus-visible:ring-2 focus-visible:ring-neutral-900/10 focus-visible:ring-offset-0"
)

export const STAKING_INPUT_NORMAL = cn(
  "border-neutral-300",
  "focus-visible:border-neutral-300"
)

/** Passive (view-only) runtime: readable field, no edit affordance. */
export const STAKING_INPUT_VIEW_ONLY = cn(
  "cursor-default border-neutral-200 bg-neutral-50/90 text-neutral-600",
  "focus-visible:border-neutral-200 focus-visible:ring-0"
)

export const STAKING_INPUT_ERROR = cn(
  "border-red-500 ring-2 ring-red-500/25",
  "focus-visible:border-red-500 focus-visible:ring-red-500/30"
)

/** Outer search bar shell (icon + field) in transaction history. */
export const STAKING_SEARCH_SHELL = cn(
  "relative isolate w-full min-w-0 overflow-hidden rounded-xl",
  "h-11 min-h-11 border border-neutral-300 bg-white/90 shadow-xs",
  "sm:h-8 sm:min-h-8",
  "focus-within:ring-2 focus-within:ring-neutral-900/10 focus-within:ring-offset-0"
)

/** Referrer paste area: borderless inner fill inside liquid card; keeps action-button inset padding. */
export const STAKING_TEXTAREA = cn(
  "w-full min-w-0 cursor-pointer resize-y rounded-xl border-0 border-transparent bg-transparent",
  "min-h-[64px] py-2 pb-9 ps-3.5 pe-3.5 sm:min-h-[76px] sm:py-2.5 sm:pb-10 sm:ps-4 sm:pe-4",
  "font-mono text-[15px] leading-snug text-neutral-800 sm:text-sm",
  "placeholder:text-[13px] placeholder:text-neutral-400/85 sm:placeholder:text-sm",
  "outline-none focus-visible:ring-2 focus-visible:ring-neutral-900/10 focus-visible:ring-offset-0",
  "pointer-coarse:text-[16px]"
)

export const STAKING_SELECT_TRIGGER = cn(
  STAKING_INPUT_BASE,
  STAKING_INPUT_NORMAL,
  "flex w-full items-center justify-between gap-2 whitespace-nowrap",
  "data-[placeholder]:text-neutral-400/85",
  "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
  // SelectTrigger defaults add a thick theme ring; keep staking border-only focus.
  "focus:outline-none focus-visible:outline-none focus-visible:ring-0 focus-visible:ring-offset-0",
  "data-[state=open]:outline-none data-[state=open]:ring-0"
)
