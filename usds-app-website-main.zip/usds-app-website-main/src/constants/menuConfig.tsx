import { AnimatedLayers } from "@/components/icons/animated/animatedLayers"
import { AnimatedMessagesSquare } from "@/components/icons/animated/animatedMessagesSquare"
import { AnimatedOpenBook } from "@/components/icons/animated/animatedOpenBook"
import { AnimatedShieldHalf } from "@/components/icons/animated/animatedShieldHalf"
import type { MenuItem } from "@/types/menu"
import { BookOpen, Home, MessagesSquare, ShieldHalf } from "lucide-react"

const menuItems: MenuItem[] = [
  {
    title: "Menu",
    subItems: [
      {
        title: "Home",
        description: "Protocol overview and how staking works.",
        link: "/",
        icon: Home,
        animatedIcon: AnimatedLayers,
        iconClassName: "text-emerald-500",
      },
      {
        title: "Transparency",
        description: "Audits and security information.",
        link: "/transparency",
        icon: ShieldHalf,
        animatedIcon: AnimatedShieldHalf,
        iconClassName: "text-teal-500",
      },
      {
        title: "Documentation",
        description: "Technical guides for developers.",
        link: "/docs",
        icon: BookOpen,
        animatedIcon: AnimatedOpenBook,
        iconClassName: "text-orange-500",
      },
      {
        title: "FAQ",
        description: "Answers to common questions.",
        link: "/faq",
        icon: MessagesSquare,
        animatedIcon: AnimatedMessagesSquare,
        iconClassName: "text-orange-500",
      },
    ],
  },
]

export default menuItems
