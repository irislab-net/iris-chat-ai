import type { QACategory } from "@/types/qa"

export const faqCategories: QACategory[] = [
  {
    id: "1",
    title: "General",
    questions: [
      {
        question: "What is Matrix?",
        answer:
          "Matrix is the protocol behind USDM — a synthetic dollar designed to trade near a $1 target. In this public experience, Matrix focuses on transparent USDM staking: you connect a wallet, review on-chain contracts, and participate without giving up custody of your keys.",
      },
      {
        question: "What product does this site cover?",
        answer:
          "This site covers the USDM synthetic dollar and its staking flow. The homepage explains how USDM is allocated and how rewards are generated. The [staking app](/app) is where you connect a wallet, deposit a supported stablecoin such as USDT, and view your resulting USDM position and estimated rewards. Supporting pages include [docs](/docs), [transparency](/transparency), and [risks](/risks).",
      },
      {
        question: "How is Matrix different from a traditional financial institution?",
        answer:
          "Traditional institutions hold custody and gate access. Matrix staking is non-custodial:\n\n1. **You sign every transaction** in your own wallet.\n2. **Activity is verifiable on-chain** through public contracts and explorers.\n3. **Rewards are variable** — target APY reflects protocol conditions and is not guaranteed.\n4. **Access depends on the network**, not business hours.",
      },
      {
        question: "Who is this for?",
        answer:
          "This product is for users who want to participate in USDM staking with clear on-chain transparency. You should understand that USDM is a synthetic dollar, that the peg is a design target rather than a promise, and that rewards depend on realized protocol revenue and remain subject to market, liquidity, smart contract, operational, and regulatory risks.",
      },
    ],
  },
  {
    id: "2",
    title: "USDM",
    questions: [
      {
        question: "What is USDM?",
        answer:
          "USDM is the Matrix protocol token — a **synthetic dollar** designed to trade near a $1 target through **protocol-owned liquidity** and **automated peg monitoring**. It is the token you hold when you participate in supported Matrix staking flows.",
      },
      {
        question: "Is USDM the same as USDT or USDC?",
        answer:
          "No. USDT and USDC are third-party stablecoins. USDM is a Matrix-issued synthetic dollar whose value is supported by protocol design — including protocol-owned liquidity and automated peg monitoring — rather than a traditional bank or issuer redemption model. It is designed to trade near $1; that target is not guaranteed.",
      },
      {
        question: "Is USDM a governance token, ownership token, or investment product?",
        answer:
          "No. USDM is not presented as a governance token, equity-like claim, or ownership right in Matrix. It is the synthetic dollar used for protocol participation in supported public flows.",
      },
      {
        question: "Where do USDM rewards come from?",
        answer:
          "Variable rewards depend on **realized protocol revenue** from cross-venue arbitrage and liquidity operations. An operational reserve and buffer policy help support continuity during changing conditions, but they do not guarantee peg stability, liquidity, or any level of reward.",
      },
    ],
  },
  {
    id: "3",
    title: "Staking & Rewards",
    questions: [
      {
        question: "How does USDM staking work?",
        answer:
          "Open the [staking app](/app), connect your wallet, select the correct network, and deposit a supported stablecoin such as USDT. You approve each step in your wallet. The Interface displays your resulting **USDM position** and estimated rewards in USDM. Target APY and variable rewards are informational and **not guaranteed** — they depend on realized protocol revenue, reserve policy, and live protocol conditions.",
      },
      {
        question: "What is target APY?",
        answer:
          'Target APY is shown as an **"up to"** figure — a directional indicator based on recent protocol conditions. It is **not guaranteed**. Target APY can change with execution performance, liquidity conditions, reserve utilization, and broader market, smart contract, operational, and regulatory factors.',
      },
      {
        question: "Are rewards guaranteed?",
        answer:
          "No. Rewards are variable and depend on realized protocol revenue from arbitrage and liquidity operations. Target APY is not guaranteed. Outcomes may be lower than shown and are subject to market, liquidity, smart contract, operational, and regulatory risks. Read the full [risks](/risks) page before participating.",
      },
      {
        question: "What is the three-part allocation shown on the homepage?",
        answer:
          "Matrix uses a three-part operating model:\n\n1. **Cross-venue arbitrage** — primary execution bucket for market-neutral spread capture that helps fund variable rewards.\n2. **Liquidity operations** — supports deposits, withdrawals, and venue inventory movement.\n3. **Operational reserve** — buffer capital that supports continuity during changing conditions.\n\nThe chart shows the current operating model, not a promise of personal returns.",
      },
      {
        question: "When can I unstake?",
        answer:
          "You can start an unstake from your wallet when you choose. After you submit, settlement follows network and contract rules. Timing varies with gas, blocks, contract logic, and protocol liquidity. Withdrawals may be subject to protocol fees or minimums shown in the app before you confirm.",
      },
    ],
  },
  {
    id: "4",
    title: "Peg & Liquidity",
    questions: [
      {
        question: "What does “designed to trade near a $1 target” mean?",
        answer:
          "USDM is engineered as a synthetic dollar with a **$1 reference target**. Protocol-owned liquidity and automated peg monitoring are used to support that target in normal conditions. The peg can still drift during stress, low liquidity, or operational events — the target is a design goal, not a guarantee.",
      },
      {
        question: "What is protocol-owned liquidity?",
        answer:
          "Protocol-owned liquidity (POL) is liquidity controlled by the protocol to support USDM market activity and peg management. POL helps the system respond to market conditions, but it does not eliminate de-peg, slippage, or liquidity risk.",
      },
      {
        question: "What is automated peg monitoring?",
        answer:
          "Automated peg monitoring — sometimes referred to as a peg bot in operational materials — watches USDM market prices against the $1 target and triggers protocol responses when deviations occur. Monitoring reduces manual reaction time; it does not guarantee the peg is maintained at all times.",
      },
      {
        question: "What is the operational reserve / buffer policy?",
        answer:
          "A portion of protocol capital is allocated to an **operational reserve** — buffer capital intended to absorb periods of spread compression, smooth infrastructure volatility, and support continuity during changing conditions. The reserve supports operations; it is not a guarantee of peg stability, withdrawals, or reward levels.",
      },
    ],
  },
  {
    id: "5",
    title: "Transparency",
    questions: [
      {
        question: "Where can I verify contracts and addresses?",
        answer:
          "Active contract addresses — including the official USDM token and staking vault — are listed on the [docs addresses page](/docs/resources/addresses). Addresses are sourced from the same runtime configuration used by the app. You can also open verified contracts on the relevant block explorer from the [staking app](/app) and homepage.",
      },
      {
        question: "Can I verify staking activity on-chain?",
        answer:
          "Yes. Stakes and unstakes are recorded on-chain. The [staking app](/app) shows your balance and transaction history; you can cross-check activity on a public block explorer. The homepage includes a direct link to the vault contract on the active network.",
      },
      {
        question: "Where are audits and security materials?",
        answer:
          "Audit reports and interface security practices are published on the [transparency](/transparency) page. Audits reduce smart contract risk but do not eliminate it. Review audits alongside the [risks](/risks) page before participating.",
      },
      {
        question: "Where can I read more documentation?",
        answer:
          "The [docs](/docs) section includes a protocol overview, Web3 fundamentals, glossary, changelog, and contract addresses. For USDM-specific questions, start with the USDM and Staking sections on this FAQ page.",
      },
    ],
  },
  {
    id: "6",
    title: "Risks",
    questions: [
      {
        question: "What are the main risks of USDM staking?",
        answer:
          "Key risks include:\n\n1. **Smart contract risk** — bugs or vulnerabilities could lead to loss of funds.\n2. **Market and peg risk** — USDM may trade away from the $1 target.\n3. **Liquidity and withdrawal risk** — unstaking timing and amounts can be affected by network and protocol conditions.\n4. **Reward variability** — realized protocol revenue may fall; target APY is not guaranteed.\n5. **Operational and regulatory risk** — protocol operations or rule changes may affect access or outcomes.\n\nSee the full [risks](/risks) page for detail.",
      },
      {
        question: "Can I lose money?",
        answer:
          "Yes. You can lose some or all of the value you stake. USDM is designed to trade near a $1 target, but that target is not guaranteed. Variable rewards depend on realized protocol revenue and may be lower than expected. Never stake more than you can afford to lose.",
      },
      {
        question: "Does USDM provide governance or ownership rights?",
        answer:
          "No. USDM is not publicly described as a governance token, equity-like claim, or ownership right in Matrix.",
      },
      {
        question: "Are USDM returns guaranteed?",
        answer:
          "No. Rewards depend on realized protocol revenue. Outcomes may change and could be lower than expected, subject to market, liquidity, smart contract, operational, and regulatory risks.",
      },
    ],
  },
  {
    id: "7",
    title: "Using the App",
    questions: [
      {
        question: "How do I get started?",
        answer:
          "You need a supported wallet and a web browser. Open the [staking app](/app), connect your wallet, confirm you are on the correct network, accept the staking terms when prompted, then deposit a supported stablecoin such as USDT and approve each transaction step in your wallet. Your position and estimated rewards are displayed in USDM.",
      },
      {
        question: "Do I need to pay network fees?",
        answer:
          "Yes. Staking and unstaking require on-chain transactions. You pay network fees (gas) to the blockchain in the network's native asset unless your wallet or environment states otherwise. The app shows estimated fees before you confirm. Protocol fees or withdrawal limits may also apply as shown in the interface.",
      },
      {
        question: "Why do dashboard numbers change?",
        answer:
          "Balances, reward estimates, and timers refresh as new blocks arrive and live protocol data updates. Target APY and rolling reward displays reflect current conditions — they are informational and not guaranteed. Small shifts are normal.",
      },
      {
        question: "What fees should I review before confirming?",
        answer:
          "Review network gas, any protocol withdrawal or staking fees shown in the form, and the receive summary before you sign. Fee lines update as you change the amount or as estimates refresh. If a figure is still loading, wait for it to resolve before confirming.",
      },
      {
        question: "Does Matrix custody my funds?",
        answer:
          "No. Your keys stay with you. If a balance moves, it is because you signed the transaction. Matrix provides the protocol interface and contracts; it does not hold custody of your wallet assets.",
      },
    ],
  },
]
