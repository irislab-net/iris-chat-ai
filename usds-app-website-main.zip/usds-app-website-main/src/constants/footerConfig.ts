import { GithubIcon } from "@/components/icons/github"
import { InstagramIcon } from "@/components/icons/instagram"
import { TelegramIcon } from "@/components/icons/telegram"
import { XIcon } from "@/components/icons/x"
import type { FooterLinkColumn, FooterSocialLink } from "@/types/footer"
import { contactInfo } from "./contactInfo"

export const footerLinkColumns: FooterLinkColumn[] = [
  {
    title: "Resources",
    links: [
      {
        title: "Home",
        link: "/",
      },
      {
        title: "FAQ",
        link: "/faq",
      },
      {
        title: "Risks",
        link: "/risks",
      },
    ],
  },
  {
    title: "Developers",
    links: [
      {
        title: "Documentation",
        link: "/docs",
      },
      {
        title: "Transparency",
        link: "/transparency",
      },
    ],
  },
  {
    title: "Company",
    links: [
      {
        title: "Privacy Policy",
        link: "/privacy",
      },
      {
        title: "Terms of Use",
        link: "/terms",
      },
      {
        title: "Contact",
        link: `mailto:${contactInfo.email}`,
      },
    ],
  },
]

export const footerSocialLinks: FooterSocialLink[] = [
  {
    title: "X",
    link: "https://x.com/matrixdotxyz",
    icon: XIcon,
  },
  {
    title: "Instagram",
    link: "https://www.instagram.com/matrixdotxyz",
    icon: InstagramIcon,
  },
  {
    title: "GitHub",
    link: "https://github.com/matrixdotxyz",
    icon: GithubIcon,
  },
  {
    title: "Telegram",
    link: "https://t.me/matrixdotxyz",
    icon: TelegramIcon,
  },
]
