export const contactInfo = {
  email: "contact@matrix.app",
}
