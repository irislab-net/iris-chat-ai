import { lazy } from "react"
import type { DocCategory } from "@/types/docs"

const AnimatedBookA = lazy(() =>
  import("@/components/icons/animated/animatedBookA").then(m => ({ default: m.AnimatedBookA })),
)
const AnimatedGlobe = lazy(() =>
  import("@/components/icons/animated/animatedGlobe").then(m => ({ default: m.AnimatedGlobe })),
)
const AnimatedList = lazy(() =>
  import("@/components/icons/animated/animatedList").then(m => ({ default: m.AnimatedList })),
)
const AnimatedMessagesSquare = lazy(() =>
  import("@/components/icons/animated/animatedMessagesSquare").then(m => ({
    default: m.AnimatedMessagesSquare,
  })),
)
const AnimatedShieldHalf = lazy(() =>
  import("@/components/icons/animated/animatedShieldHalf").then(m => ({
    default: m.AnimatedShieldHalf,
  })),
)
const AnimatedSiren = lazy(() =>
  import("@/components/icons/animated/animatedSiren").then(m => ({ default: m.AnimatedSiren })),
)
const AnimatedSlider = lazy(() =>
  import("@/components/icons/animated/animatedSlider").then(m => ({ default: m.AnimatedSlider })),
)
const AnimatedWalletCards = lazy(() =>
  import("@/components/icons/animated/animatedWalletCards").then(m => ({
    default: m.AnimatedWalletCards,
  })),
)

const IntroductionOverview = lazy(
  () => import("@/components/pages/docs/introduction/introductionOverview"),
)
const ResourcesAddresses = lazy(() => import("@/components/pages/docs/resources/resourcesAddresses"))
const ResourcesChangelog = lazy(() => import("@/components/pages/docs/resources/resourcesChangelog"))
const ResourcesGlossary = lazy(() => import("@/components/pages/docs/resources/resourcesGlossary"))
const ResourcesWeb3 = lazy(() => import("@/components/pages/docs/resources/resourcesWeb3"))

export const docsCategoriesConfig: DocCategory[] = [
  {
    title: "Introduction",
    pages: [
      {
        title: "Overview",
        path: "",
        animatedIcon: AnimatedSlider,
        iconClassName: "text-violet-400",
        element: <IntroductionOverview />,
      },
    ],
  },

  {
    title: "Resources",
    pages: [
      {
        title: "Transparency & Audits",
        path: "/transparency",
        animatedIcon: AnimatedShieldHalf,
      },
      {
        title: "FAQ",
        path: "/faq",
        animatedIcon: AnimatedMessagesSquare,
      },
      {
        title: "Risks",
        path: "/risks",
        animatedIcon: AnimatedSiren,
        iconClassName: "text-red-500",
      },
      {
        title: "Addresses",
        path: "resources/addresses",
        animatedIcon: AnimatedWalletCards,
        iconClassName: "text-teal-500",
        element: <ResourcesAddresses />,
      },
      {
        title: "Changelog",
        path: "resources/changelog",
        animatedIcon: AnimatedList,
        iconClassName: "text-purple-500",
        element: <ResourcesChangelog />,
      },
      {
        title: "Web3",
        path: "resources/web3",
        animatedIcon: AnimatedGlobe,
        iconClassName: "text-cyan-500",
        element: <ResourcesWeb3 />,
      },
      {
        title: "Glossary",
        path: "resources/glossary",
        animatedIcon: AnimatedBookA,
        iconClassName: "text-sky-600",
        element: <ResourcesGlossary />,
      },
    ],
  },
]

export const docsRoutesConfig = docsCategoriesConfig.flatMap(category =>
  category.pages
    .flatMap(page => {
      const pages = [page]
      if (page.children) {
        pages.push(
          ...page.children.map(child => ({
            ...child,
            path: `${page.path}/${child.path}`,
          })),
        )
      }
      return pages
    })
    .filter(page => page.element && !page.path.startsWith("/")),
)
