import type { SecurityDocCategory } from "@/types/security"

export const securityDocsConfig: SecurityDocCategory[] = [
  {
    title: "Staking & USDM contract audits",
    link: "/docs/resources/addresses",
    docs: [
      {
        title: "Smart contract security review",
        date: new Date("2025-08-18"),
        link: "/docs/resources/addresses",
      },
      {
        title: "Security assessment",
        date: new Date("2025-08-11"),
        link: "/docs/resources/addresses",
      },
      {
        title: "Smart contract audit report",
        date: new Date("2025-08-11"),
        link: "/docs/resources/addresses",
      },
      {
        title: "Follow-up security review",
        date: new Date("2025-08-13"),
        link: "/docs/resources/addresses",
      },
    ],
  },
]
