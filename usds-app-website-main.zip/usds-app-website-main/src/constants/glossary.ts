import { AnimatedActivity } from "@/components/icons/animated/animatedActivity"
import { AnimatedArrowRightLeft } from "@/components/icons/animated/animatedArrowRightLeft"
import { AnimatedAward } from "@/components/icons/animated/animatedAward"
import { AnimatedCoins } from "@/components/icons/animated/animatedCoins"
import { AnimatedCoinStack } from "@/components/icons/animated/animatedCoinStack"
import { AnimatedCrystalBall } from "@/components/icons/animated/animatedCrystalBall"
import { AnimatedFuel } from "@/components/icons/animated/animatedFuel"
import { AnimatedGlobe } from "@/components/icons/animated/animatedGlobe"
import { AnimatedHeartPulse } from "@/components/icons/animated/animatedHeartPulse"
import { AnimatedLandmark } from "@/components/icons/animated/animatedLandmark"
import { AnimatedLock } from "@/components/icons/animated/animatedLock"
import { AnimatedTrendUp } from "@/components/icons/animated/animatedTrendUp"
import { AnimatedWallet } from "@/components/icons/animated/animatedWallet"
import { AnimatedWaves } from "@/components/icons/animated/animatedWaves"
import { AnimatedZap } from "@/components/icons/animated/animatedZap"
import { SpinningDollarCoin } from "@/components/icons/animated/spinningDollarCoin"
import { BinanceIcon } from "@/components/icons/binance"
import { BridgeIcon } from "@/components/icons/bridge"
import { DeFiIcon } from "@/components/icons/defi"
import { DexIcon } from "@/components/icons/dex"
import { EthereumIcon, EthereumOutlineIcon } from "@/components/icons/etherium"
import { ServerProxyIcon } from "@/components/icons/serverProxy"
import { SwimmingIcon } from "@/components/icons/swimming"
import { TokenCubeIcon } from "@/components/icons/tokenCube"
import type { CardData } from "@/types/card"
import {
  BadgePercent,
  ChartSpline,
  CircleDollarSign,
  CircleFadingArrowUp,
  DiamondPercent,
  FileBadge,
  FileCode,
  GitFork,
  Network,
  RectangleEllipsis,
  RefreshCw,
  Replace,
  ScanEye,
} from "lucide-react"

const glossaryItems: CardData[] = [
  {
    title: "aToken",
    description:
      "Interest-bearing tokens representing a user's share of a liquidity pool. aTokens automatically accrue interest and can be redeemed for underlying assets.",
    icon: CircleDollarSign,
  },
  {
    title: "Address",
    description:
      'A unique identifier for a wallet or smart contract on a blockchain. Usually represented as a hexadecimal string starting with "0x".',
    animatedIcon: AnimatedWallet,
  },
  {
    title: "APY",
    description:
      'Annual Percentage Yield. A way to describe annualized protocol performance. In public Matrix materials, APY is shown as an "up to" informational figure, remains variable, and is not guaranteed.',
    icon: BadgePercent,
  },
  {
    title: "Arbitrage-funded rewards",
    description:
      "Variable staking rewards tied to realized protocol revenue from cross-venue arbitrage and liquidity operations. Outcomes can change and are not guaranteed.",
    animatedIcon: AnimatedTrendUp,
  },
  {
    title: "Audit",
    description:
      "A comprehensive security review of smart contract code conducted by independent security firms to identify vulnerabilities and risks.",
    icon: ScanEye,
  },
  {
    title: "Bridge",
    description:
      "A protocol that enables the transfer of assets between different blockchains. Bridges maintain asset value while moving across networks.",
    icon: BridgeIcon,
  },
  {
    title: "Buffer reserve",
    description:
      "Operational reserve capital allocated to absorb spread compression and support continuity during changing conditions. It does not guarantee peg stability, liquidity, or reward levels.",
    animatedIcon: AnimatedLock,
  },
  {
    title: "Collateral",
    description:
      "Assets pledged as security for a loan or other financial obligation. In DeFi, collateral is used to secure borrowing positions.",
    icon: FileBadge,
  },
  {
    title: "DeFi",
    description:
      "Decentralized Finance. Financial services built on blockchain technology that operate without traditional intermediaries like traditional financial institutions.",
    icon: DeFiIcon,
  },
  {
    title: "DEX",
    description:
      "Decentralized Exchange. A cryptocurrency exchange that operates on blockchain without a central authority, using smart contracts for trading.",
    icon: DexIcon,
  },
  {
    title: "Flash Loan",
    description:
      "A type of uncollateralized loan that must be borrowed and repaid within the same transaction block.",
    animatedIcon: AnimatedZap,
  },
  {
    title: "Fork",
    description:
      "A split in a blockchain that creates two separate versions. Can be hard (permanent) or soft (temporary) forks.",
    icon: GitFork,
  },
  {
    title: "Fungible",
    description:
      "Interchangeable and identical in value. Fungible tokens such as USDT or USDM can be exchanged on a one-to-one basis within the same token contract.",
    icon: Replace,
  },
  {
    title: "Gas",
    description:
      "The fee required to execute transactions on a blockchain. Gas fees compensate network validators for processing transactions.",
    animatedIcon: AnimatedFuel,
  },
  {
    title: "Governance",
    description:
      "The process by which protocol decisions are made through community voting. Token holders can propose and vote on protocol changes.",
    animatedIcon: AnimatedLandmark,
  },
  {
    title: "Health Factor",
    description:
      "A metric that indicates the safety of a borrowing position. Values below 1.0 risk liquidation.",
    animatedIcon: AnimatedHeartPulse,
  },
  {
    title: "Impermanent Loss",
    description:
      "A loss that occurs when providing liquidity to automated market makers due to price changes in the underlying assets.",
    icon: ChartSpline,
  },
  {
    title: "Interest Rate",
    description:
      "The percentage charged for borrowing or earned for lending assets. Can be fixed or variable based on market conditions.",
    animatedIcon: AnimatedActivity,
  },
  {
    title: "Liquidation",
    description:
      "The forced sale of collateral when a borrowing position becomes unsafe. Occurs when health factor drops below 1.0.",
    icon: SwimmingIcon,
  },
  {
    title: "Liquidity Pool",
    description:
      "A collection of tokens locked in smart contracts to facilitate trading. Provides liquidity for DEX trading and lending protocols.",
    animatedIcon: AnimatedWaves,
  },
  {
    title: "LTV",
    description:
      "Loan-to-Value ratio. The percentage of an asset's value that can be borrowed against. Higher LTV means higher borrowing capacity but increased risk.",
    icon: DiamondPercent,
  },
  {
    title: "Mainnet",
    description:
      "The primary blockchain network where real transactions occur. Contrasted with testnet, which is used for testing.",
    icon: Network,
  },
  {
    title: "Meta-transaction",
    description:
      "A transaction where the gas fees are paid by a third party (relayer) instead of the transaction sender.",
    animatedIcon: AnimatedZap,
  },
  {
    title: "Non-custodial",
    description:
      "A wallet or service where users maintain full control over their private keys. No third party has access to user funds.",
    animatedIcon: AnimatedWallet,
  },
  {
    title: "Oracle",
    description:
      "A service that provides external data to smart contracts. Used for price feeds, random numbers, and other off-chain data.",
    animatedIcon: AnimatedCrystalBall,
  },
  {
    title: "Over-collateralization",
    description:
      "The practice of requiring borrowers to provide more collateral than the loan value. Protects against price volatility and liquidation.",
    icon: RefreshCw,
  },
  {
    title: "Peg",
    description:
      "A target price relationship to a reference asset, often the US dollar. USDM is designed to trade near a $1 target; market prices can still deviate during stress or low liquidity.",
    animatedIcon: AnimatedCoins,
  },
  {
    title: "Peg bot",
    description:
      "Operational shorthand for automated peg monitoring systems that watch USDM market prices and trigger protocol responses when deviations from the $1 target occur. Monitoring reduces reaction time; it does not guarantee the peg.",
    animatedIcon: AnimatedZap,
  },
  {
    title: "Peg monitoring",
    description:
      "Automated observation of USDM market prices against the $1 target, used to support protocol-owned liquidity responses. Also referred to as peg bot in operational materials.",
    animatedIcon: AnimatedActivity,
  },
  {
    title: "Peg reserve",
    description:
      "Reserve and buffer capital within the public allocation model that supports operational continuity and peg-management responses. Not a guarantee of $1 market price or full liquidity at all times.",
    animatedIcon: AnimatedWaves,
  },
  {
    title: "Proxy",
    description:
      "A smart contract pattern that allows for upgradeable contracts. The proxy delegates calls to an implementation contract that can be upgraded.",
    icon: ServerProxyIcon,
  },
  {
    title: "Protocol-owned liquidity",
    description:
      "Liquidity controlled by the Matrix protocol (POL) to support USDM market activity and peg management. POL helps respond to market conditions but does not eliminate de-peg or liquidity risk.",
    animatedIcon: AnimatedWaves,
  },
  {
    title: "Rewards",
    description:
      "Protocol distributions or incentives shown to users. In Matrix public materials, rewards should be read as variable outcomes tied to protocol activity, not fixed promises.",
    animatedIcon: AnimatedAward,
  },
  {
    title: "Seed Phrase",
    description:
      "A series of words used to recover a wallet. Also called mnemonic phrase or recovery phrase.",
    icon: RectangleEllipsis,
  },
  {
    title: "Stablecoin",
    description:
      "A cryptocurrency designed to track a reference asset such as the US dollar. USDM is the Matrix synthetic dollar, designed to trade near a $1 target through protocol-owned liquidity and automated peg monitoring.",
    animatedIcon: SpinningDollarCoin,
  },
  {
    title: "Staking",
    description:
      "Participating in supported Matrix flows by connecting a wallet to public vault contracts at /app. Variable rewards may accrue according to live protocol data; withdrawal timing and fees depend on contract and network conditions.",
    animatedIcon: AnimatedCoinStack,
  },
  {
    title: "Synthetic dollar",
    description:
      "A protocol-issued dollar-denominated token engineered to track a $1 reference target. USDM is Matrix's synthetic dollar — not fiat USD and not a bank deposit product.",
    animatedIcon: SpinningDollarCoin,
  },
  {
    title: "Target APY",
    description:
      'An informational "up to" figure shown in public materials based on recent protocol conditions. Target APY is variable, not guaranteed, and should not be read as a promised return.',
    icon: BadgePercent,
  },
  {
    title: "Swap",
    description:
      "The exchange of one cryptocurrency for another. Can be done on DEXs or through centralized exchanges.",
    animatedIcon: AnimatedArrowRightLeft,
  },
  {
    title: "Testnet",
    description:
      "A blockchain network used for testing applications and smart contracts. Uses test tokens with no real value.",
    icon: Network,
  },
  {
    title: "Upgradeable",
    description:
      "A smart contract that can be modified after deployment. Uses proxy patterns to maintain the same address while updating functionality.",
    icon: CircleFadingArrowUp,
  },
  {
    title: "USDM",
    description:
      "The Matrix synthetic dollar — a protocol token designed to trade near a $1 target through protocol-owned liquidity and automated peg monitoring. Used in public staking flows; target APY and variable rewards are not guaranteed.",
    animatedIcon: AnimatedCoins,
  },
  {
    title: "Utilization Rate",
    description:
      "The percentage of total supplied assets that are currently borrowed. Affects interest rates in dynamic rate models.",
    animatedIcon: AnimatedTrendUp,
  },
  {
    title: "Wallet",
    description:
      "Software that stores private keys and allows users to interact with blockchain networks. Can be hot (online) or cold (offline) storage.",
    animatedIcon: AnimatedWallet,
  },
  {
    title: "Web3",
    description:
      "The next generation of the internet built on blockchain technology. Emphasizes decentralization, user ownership, and trustless interactions.",
    animatedIcon: AnimatedGlobe,
  },
  {
    title: "Yield",
    description:
      "The return generated by a protocol activity. In Matrix public materials, yield refers to variable outcomes tied to arbitrage and liquidity operations rather than guaranteed returns.",
    animatedIcon: AnimatedTrendUp,
  },
].sort((a, b) => a.title.localeCompare(b.title))

const glossaryCategories = glossaryItems.reduce((acc, item) => {
  item.iconClassName =
    "text-neutral-400 transition-colors duration-300 group-hover/card:text-neutral-900"

  const firstLetter = item.title?.[0]?.toUpperCase() ?? ""
  if (!acc[firstLetter]) {
    acc[firstLetter] = []
  }
  acc[firstLetter].push(item)
  return acc
}, {} as Record<string, CardData[]>)

export const glossary = Object.entries(glossaryCategories).map(
  ([letter, items]) => ({
    letter,
    items,
  })
)

export const abbreviations: CardData[] = [
  {
    title: "API",
    description: "Application Programming Interface",
    icon: FileCode,
  },
  {
    title: "BSC",
    description: "Binance Smart Chain",
    icon: BinanceIcon,
  },
  {
    title: "DEX",
    description: "Decentralized Exchange",
    icon: DexIcon,
  },
  {
    title: "DeFi",
    description: "Decentralized Finance",
    icon: DeFiIcon,
  },
  {
    title: "ERC",
    description: "Ethereum Request for Comment",
    icon: EthereumOutlineIcon,
  },
  {
    title: "ETH",
    description: "Ethereum",
    icon: EthereumIcon,
  },
  {
    title: "LTV",
    description: "Loan-to-Value",
    icon: DiamondPercent,
  },
  {
    title: "NFT",
    description: "Non-Fungible Token",
    icon: TokenCubeIcon,
  },
  {
    title: "TVL",
    description: "Total Value Locked",
    animatedIcon: AnimatedLock,
  },
  {
    title: "USDC",
    description: "USD Coin",
    animatedIcon: AnimatedCoins,
  },
  {
    title: "USDT",
    description: "Tether",
    animatedIcon: AnimatedCoins,
  },
  {
    title: "USDM",
    description:
      "USDM synthetic dollar — Matrix protocol token for public staking at /app",
    animatedIcon: AnimatedCoins,
  },
]
  .map(item => ({
    ...item,
    iconClassName:
      "text-neutral-400 transition-colors duration-300 group-hover/card:text-neutral-900",
  }))
  .sort((a, b) => a.title?.localeCompare(b.title ?? "") ?? 0)
