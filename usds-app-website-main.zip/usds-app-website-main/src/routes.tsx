import { AppKitRouteGate } from "@/components/layout/AppKitRouteGate"
import { docsRoutesConfig } from "@/constants/docsConfig"
import HowItWorks from "@/components/pages/howItWorks/howItWorks"
import { lazyAfterAppKit } from "@/lib/lazyAfterAppKit"
import { lazy } from "react"
import { Navigate, Route, Routes } from "react-router-dom"

const Transparency = lazy(() => import("@/components/pages/transparency/transparency"))
const Risks = lazy(() => import("@/components/pages/risks/risks"))
const Faq = lazy(() => import("@/components/pages/faq/faq"))
const Privacy = lazy(() => import("@/components/pages/privacy/privacy"))
const Terms = lazy(() => import("@/components/pages/terms/terms"))
const StakingApp = lazyAfterAppKit(() =>
  import("@/components/pages/staking/StakingApp")
)
const Docs = lazy(() => import("@/components/pages/docs/docs"))
const NotFound = lazy(() => import("@/components/pages/notFound/notFound"))

function AppRoutes() {
  return (
    <Routes>
      <Route path='/' element={<HowItWorks />} />
      <Route path='/transparency' element={<Transparency />} />
      <Route path='/risks' element={<Risks />} />
      <Route path='/faq' element={<Faq />} />
      <Route
        path='/app'
        element={
          <AppKitRouteGate>
            <StakingApp />
          </AppKitRouteGate>
        }
      />
      <Route path='/privacy' element={<Privacy />} />
      <Route path='/terms' element={<Terms />} />

      <Route path='/docs' element={<Docs />}>
        {docsRoutesConfig.map(docPage => (
          <Route key={docPage.path} path={docPage.path} element={docPage.element} />
        ))}
      </Route>

      <Route path='/how-it-works' element={<Navigate to='/' replace />} />
      <Route path='/staking/app' element={<Navigate to='/app' replace />} />
      <Route path='/staking' element={<Navigate to='/' replace />} />
      <Route path='/staking/terms' element={<Navigate to='/terms' replace />} />
      <Route path='/security' element={<Navigate to='/transparency' replace />} />
      <Route path='/help/*' element={<Navigate to='/faq' replace />} />
      <Route path='/help' element={<Navigate to='/faq' replace />} />
      <Route path='/mtx' element={<Navigate to='/' replace />} />

      <Route path='*' element={<NotFound />} />
    </Routes>
  )
}

export default AppRoutes
