/** Explicit opt-in for `[network]` dev console diagnostics (never hot-path console spam). */
export const DEBUG_NETWORK =
  import.meta.env.DEV &&
  String(import.meta.env.VITE_DEBUG_NETWORK ?? "")
    .trim()
    .toLowerCase() === "true"

export function isNetworkDebugLoggingEnabled(): boolean {
  return import.meta.env.DEV && DEBUG_NETWORK
}
