# Matrix USDM Staking Privacy Policy

**Last Updated: 31 May 2026**

---

## Introduction

This Privacy Policy explains how Matrix ("we," "us," or "our") handles information when you visit the public Matrix website, use the USDM staking interface at `/app`, or interact with related documentation and support channels.

The Interface is **non-custodial**. We do not custody your digital assets or control your private keys. Blockchain transactions you sign are **public by design**.

## Scope

This policy applies to:

- The public Matrix website and marketing pages
- The USDM staking interface (`/app`)
- Documentation, FAQ, transparency, and risks pages
- Support or contact communications you initiate with us

This policy does **not** describe third-party wallet apps, RPC providers, block explorers, or other services you choose to connect. Those providers have their own privacy policies.

## Information We Collect

We aim to collect only what is needed to operate, secure, and improve the Interface.

### Information you provide

- **Support or contact messages** — if you email us or submit a request, we may receive your email address, message content, and any information you choose to include.
- **Optional referral or affiliate fields** — if you enter a referral address in the Interface, that value may be processed according to protocol and Interface rules.

### Information collected automatically

When you use the website or Interface, we or our service providers may process:

- **Device and browser data** — browser type, operating system, language, and general device characteristics
- **Usage data** — pages viewed, features used, approximate interaction patterns, and error or performance logs
- **Network data** — IP address and request metadata used for security, abuse prevention, and service delivery
- **Cookies and local storage** — preferences, session continuity, consent flags (such as accepted staking terms), and similar technical storage on your device

### Wallet and on-chain data

When you connect a wallet:

- Your **wallet address** and **network** may be read by the Interface to display balances, history, and transaction flows.
- **Transaction data** you submit is recorded on public blockchains and may be indexed by explorers or analytics tools we use to display history.
- We do **not** receive your private keys or seed phrases through the Interface.

## How We Use Information

We use collected information to:

- Operate and maintain the website and staking Interface
- Display wallet-connected balances, estimates, and transaction status
- Secure the Interface, detect abuse, and troubleshoot errors
- Improve performance, usability, and documentation
- Respond to support requests you send us
- Comply with applicable legal obligations when required

We do not use the Interface to build a custodial profile of your on-chain holdings for unrelated marketing purposes.

## Cookies and Local Storage

We may use cookies, local storage, and similar technologies for:

- Essential site functionality and security
- Remembering Interface preferences or consent state
- Analytics and performance monitoring, where enabled

You can control cookies through your browser settings. Disabling certain storage may limit Interface functionality.

## Third-Party Services

The Interface relies on third parties that may process limited data, including:

- **Wallet providers** (e.g., WalletConnect-compatible wallets) — connection and signing flows
- **RPC and indexing providers** — blockchain reads and transaction broadcast
- **Hosting and CDN providers** — content delivery and availability
- **Analytics and error monitoring** — aggregated usage and crash diagnostics, where configured
- **Block explorers** — links to public on-chain records

Each third party processes data under its own terms and privacy policy. We encourage you to review those policies for services you use.

## Blockchain Transparency

Transactions, wallet addresses, and smart contract interactions are generally **public** and **permanent** on supported networks. We cannot delete or alter on-chain records.

## Information Sharing

We do not sell your personal information.

We may share limited information:

- With **service providers** who assist in hosting, security, analytics, or support, under contractual confidentiality obligations
- When **required by law**, regulation, court order, or valid legal process
- To **protect rights and safety** — investigating abuse, fraud, or threats to the Interface or users
- With your **direction or consent**, when you explicitly request it

## Data Retention

We retain information only as long as reasonably necessary for the purposes described above, including security logs, support correspondence, and legal compliance. Retention periods vary by data type and legal requirements.

## Security

We implement technical and organizational measures designed to protect the Interface and associated systems. No method of transmission or storage is completely secure. You are responsible for securing your wallet and devices.

## Your Choices and Rights

Depending on your jurisdiction, you may have rights to:

- Access or request a copy of personal information we hold about you
- Request correction or deletion of certain information
- Object to or restrict certain processing
- Withdraw consent where processing is consent-based

To exercise these rights, contact us at [contact@matrix.app](mailto:contact@matrix.app). We may need to verify your request. Some rights may not apply to public blockchain data we do not control.

## International Users

If you access the Interface from outside our primary operating region, your information may be processed in countries with different data protection laws.

## Children's Privacy

The Interface is not directed to individuals under 18. We do not knowingly collect personal information from children.

## Changes to This Policy

We may update this Privacy Policy from time to time. The "Last Updated" date will change when we do. Continued use of the Interface after changes constitutes acceptance of the revised policy.

## Contact

Privacy questions or requests: [contact@matrix.app](mailto:contact@matrix.app)

---

**Summary:** The USDM staking Interface is non-custodial. We process limited website, device, and wallet-connection data to operate the service. On-chain activity is public. We do not sell personal information. Contact us with privacy questions at contact@matrix.app.
