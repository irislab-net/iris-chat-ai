# Matrix USDM Staking Terms of Use

**Last Updated: 31 May 2026**

---

## Introduction

These Terms of Use ("Terms") govern your access to and use of the Matrix public website, documentation, and the USDM staking interface at `/app` (collectively, the "Interface"). The Interface connects your self-custodial wallet to Matrix protocol smart contracts. Matrix provides protocol software and an informational interface; it does not take custody of your assets.

**IMPORTANT: The Interface is non-custodial. You control your wallet, private keys, and every transaction you sign. Matrix does not hold, recover, or insure your funds.**

By accessing or using the Interface, you agree to these Terms and our [Privacy Policy](/privacy). If you do not agree, do not use the Interface.

## Agreement to Terms

You represent that you have read, understood, and agree to be bound by these Terms. If you use the Interface on behalf of an organization, you represent that you have authority to bind that organization.

## Description of the Interface

The Interface allows you to:

- Connect a supported self-custodial wallet
- Deposit supported stablecoins (such as USDT, where enabled) into Matrix protocol vault contracts
- Receive and view a **USDM position** and estimated rewards in the Interface
- Withdraw or unstake subject to network and contract rules
- Review public contract addresses, disclosures, and risk materials

**USDM** is a **synthetic dollar** designed to trade near a **$1 target** through **protocol-owned liquidity** and **automated peg monitoring**. USDM is **not fiat USD**. It is not a bank deposit, savings product, insured account, or capital-protected instrument.

## Rewards and Target APY

- **Target APY** and reward estimates shown in the Interface are **informational**, **variable**, and **not guaranteed**.
- Rewards depend on **realized protocol revenue**, **reserve policy**, arbitrage and liquidity operations, and broader market conditions.
- Displayed figures may change, lag, or differ from on-chain outcomes.
- Past or displayed performance is not a promise of future results.

## Non-Custodial Nature

- **You sign every transaction** in your own wallet.
- Matrix does not store your private keys, seed phrases, or signing authority.
- Matrix cannot reverse, cancel, or recover transactions you approve.
- You are solely responsible for wallet security, backups, and verifying recipient addresses and contract interactions.

## Eligibility

You must be at least 18 years old (or the age of majority in your jurisdiction) and legally permitted to use blockchain and staking services where you reside. You may not use the Interface if doing so would violate applicable law or sanctions rules.

## Your Responsibilities

You are responsible for:

- **Wallet security** — safeguarding keys, seed phrases, and device access
- **Transaction review** — verifying amounts, assets, networks, fees, and contract addresses before signing
- **Network fees** — paying gas or native network fees required by the blockchain
- **Contract verification** — reviewing official addresses on `/docs/resources/addresses` and block explorers
- **Risk review** — reading `/risks`, `/transparency`, and `/faq` before participating
- **Tax and compliance** — determining your own tax, reporting, and legal obligations

## Protocol Parameters and Availability

Matrix may update, suspend, or modify protocol parameters, fees, supported assets, networks, reserve policy, Interface features, or availability at any time. On-chain rules and third-party infrastructure (RPC providers, wallets, explorers) may also change without notice.

## Risks

USDM staking involves material risks, including without limitation:

- **Smart contract risk** — bugs or vulnerabilities may cause loss of funds
- **Market and peg risk** — USDM may trade away from its $1 target
- **Liquidity and withdrawal risk** — timing, amounts, and settlement may vary
- **Reward variability** — realized protocol revenue may fall; target APY is not guaranteed
- **Operational risk** — outages, execution errors, or configuration issues
- **Regulatory risk** — rules may change and affect access or outcomes
- **Third-party risk** — wallets, RPC endpoints, bridges, and explorers are outside Matrix control

You may lose some or all of the value you deposit. Never deposit more than you can afford to lose.

## Prohibited Use

You may not use the Interface to:

- Violate applicable laws or sanctions
- Interfere with or attack the Interface, networks, or contracts
- Misrepresent your identity or authority
- Attempt unauthorized access to systems or data
- Use the Interface for money laundering, fraud, or other unlawful activity

## No Advice

Nothing in the Interface or these Terms is financial, investment, legal, or tax advice. Matrix does not recommend that you deposit, withdraw, or hold any asset. Consult qualified professionals before making financial decisions.

## Disclaimers

THE INTERFACE AND PROTOCOL ARE PROVIDED **"AS IS"** AND **"AS AVAILABLE"** WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, UNINTERRUPTED AVAILABILITY, ACCURACY OF DISPLAYED DATA, PEG STABILITY, OR ANY LEVEL OF REWARD.

## Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY LAW, MATRIX AND ITS CONTRIBUTORS, AFFILIATES, AND SERVICE PROVIDERS WILL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF FUNDS, PROFITS, DATA, OR GOODWILL, ARISING FROM YOUR USE OF THE INTERFACE OR PROTOCOL, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

## Indemnification

You agree to indemnify and hold harmless Matrix and its contributors from claims arising out of your use of the Interface, your violation of these Terms, or your violation of applicable law.

## Changes to These Terms

We may update these Terms from time to time. The "Last Updated" date will change when we do. Continued use of the Interface after changes constitutes acceptance of the revised Terms.

## Governing Law and Disputes

These Terms are governed by the laws applicable to Matrix's operating entity, without regard to conflict-of-law principles. Disputes will be resolved in the courts or forums specified by applicable law, unless mandatory consumer protections require otherwise.

## Contact

Questions about these Terms: [contact@matrix.app](mailto:contact@matrix.app)

---

**By using the Interface, you acknowledge that USDM is a synthetic dollar with a design target near $1, that target APY and variable rewards are not guaranteed, and that you participate at your own risk.**
