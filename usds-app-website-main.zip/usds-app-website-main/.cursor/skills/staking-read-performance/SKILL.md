---
name: staking-read-performance
description: Protects staking read performance and provider architecture when editing RPC logic, provider architecture, polling, balances, staking reads, history fetching, stats, Firestore subscriptions, cache handling, rerender optimization, and refresh orchestration. Use when working on provider, rpc, polling, balance, history, firestore, reads, stats, rerender, performance, cache, refresh, block, subscription, or query changes.
---

# Staking Read Performance

Use this skill when editing:
- RPC logic
- provider architecture
- polling
- balances
- staking reads
- history fetching
- stats
- Firestore subscriptions
- cache handling
- rerender optimization
- refresh orchestration

Trigger terms:
provider, rpc, polling, balance, history, firestore, reads, stats, rerender, performance, cache, refresh, block, subscription, query

# Provider Rules

- Prefer singleton read providers.
- Keep reads independent from signer logic where possible.
- Do not couple reads to wallet providers unnecessarily.
- Preserve provider separation architecture.

# Refresh Rules

- Avoid full refreshes on every block.
- Prefer centralized refresh orchestration.
- Preserve hidden-tab backoff behavior.
- Preserve deduped/single-flight reads.

# Performance Rules

- Avoid unnecessary rerenders.
- Preserve cache-aware behavior.
- Avoid duplicated network requests.
- Prefer shared read state where possible.

# Firestore Rules

- Preserve Firestore subscription behavior.
- Preserve fallback field handling.
- Preserve affiliate stats behavior.
