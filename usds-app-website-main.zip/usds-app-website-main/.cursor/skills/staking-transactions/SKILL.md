---
name: staking-transactions
description: Preserves staking transaction flow invariants across deposit, withdraw, approve, allowance, gas estimation, transaction modal logic, status state machines, claim or reward transactions, and wallet confirmation UX. Use when editing deposit, withdraw, approve, allowance, gas, transaction, modal, signature, confirming, submitted, claim, staking, or vault logic.
---

# Staking Transactions

Use this skill when editing:
- deposit flow
- withdraw flow
- approve flow
- allowance handling
- gas estimation
- transaction modal logic
- transaction status state machines
- claim/reward transactions
- wallet confirmation UX

Trigger terms:
deposit, withdraw, approve, allowance, gas, transaction, modal, signature, confirming, submitted, claim, staking, vault

# Core Rules

- Preserve transaction phases:
  - preview
  - awaiting_signature
  - submitted
  - confirming
  - confirmed
  - failed
  - cancelled

- Do not skip awaiting_signature.
- Do not collapse submitted/confirming states.
- Preserve modal ownership of transaction state.
- Do not duplicate success/error toasts.
- Preserve detached post-broadcast transaction behavior.
- Preserve transaction recovery behavior.

# Approval Rules

- Preserve approval execution helper behavior.
- Preserve USDT-style approval reset behavior.
- Do not duplicate approval decision logic.
- Keep approval orchestration centralized.

# Gas Estimation Rules

- Preserve partial gas estimate behavior.
- Do not assume wallet fee previews equal local estimates.
- Preserve split approval/deposit gas logic.
- Do not block valid transactions because of incomplete estimates.

# UX Rules

- Keep CTA states stable.
- Avoid layout shift.
- Preserve existing transaction messaging tone.
- Keep loading/confirming states calm and concise.
