---
name: audit-before-implementation
description: Audit directly relevant files before implementation to map current behavior, isolate likely root cause, and choose the safest minimal fix. Use before refactors, before debugging production issues, or before changing transaction/provider/session flows.
---

# Audit Relevant Files Before Implementation

Use this skill before editing code when the task needs a focused audit of the current implementation.

## When to use

- Before refactors
- Before debugging production issues
- Before changing transaction/provider/session flows

## Instructions

- Inspect only directly relevant files.
- Do not edit code.
- Identify:
  - relevant files
  - current flow
  - likely root cause
  - safest minimal fix
  - regression risks

## Response format

Keep findings concise and actionable. Prefer this order:

1. Relevant files
2. Current flow
3. Likely root cause
4. Safest minimal fix
5. Regression risks

## Rules

- Avoid unnecessary architecture commentary.
- Avoid broad refactor suggestions.
- Prefer concise actionable findings.
- Focus on low-risk production-safe changes.

## Boundaries

- Stop after the audit unless the user explicitly asks for code changes.
- If the scope is too broad, narrow to the smallest set of files needed to explain the behavior.
- If multiple fixes are possible, recommend the least invasive production-safe option first.
