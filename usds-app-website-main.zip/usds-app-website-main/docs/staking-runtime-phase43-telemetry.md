# Phase 43 telemetry anchor

This path is retained because runtime env documentation references it. The telemetry and Sentry taxonomy has been consolidated into `docs/staking-sentry-event-taxonomy.md`. Treat this file as a compatibility anchor plus historical telemetry rollout summary.

## Canonical replacement

Use `docs/staking-sentry-event-taxonomy.md` for:

- Runtime telemetry stages and rollout semantics.
- Aggregate runtime health event names.
- Sentry event namespaces, tags, contexts, breadcrumbs, severity, and dedupe rules.
- Privacy constraints and production alert guidance.

## Preserved Phase 43 rules

- `VITE_RUNTIME_TELEMETRY_STAGE` is independent of runtime-switch rollout.
- Telemetry is non-blocking and must never drive render churn or runtime state changes.
- Production volume is bounded by rollout stage, sampling, cooldowns, and burst limits.
- Payloads must remain operational and privacy-safe: no wallet addresses, values, raw RPC payloads, balances, or secrets.
