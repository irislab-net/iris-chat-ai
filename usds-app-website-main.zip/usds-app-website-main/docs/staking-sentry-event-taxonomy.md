# Staking Sentry and runtime telemetry taxonomy

Canonical observability taxonomy for staking runtime, wallet, tx, hydration, refresh, and mobile lifecycle signals. Runtime telemetry describes aggregate health; Sentry events are the production issue surface. Both must remain non-blocking, rate-limited, and privacy-safe.

Source of truth for Sentry names: `src/lib/stakingSentry/taxonomy.ts` (`STAKING_SENTRY_EVENT`). Runtime aggregate emitters live under `src/lib/runtimeTelemetry/`.

## Runtime telemetry contract

- `emitRuntimeTelemetry` accepts typed aggregate events and dispatches asynchronously.
- `VITE_RUNTIME_TELEMETRY_STAGE` gates rollout: off, DEV-only, internal beta, sampled production, and externally monitored production. Stage 4 does not add new client ownership by itself; alerts/dashboards depend on downstream Sentry/OTel configuration.
- Sampling and cooldowns bound production volume; error/critical signals may sample at a higher rate.
- Telemetry must never block UI, drive render churn, mutate runtime state, or leak wallet/user data.

Allowed telemetry fields are coarse operational tokens: runtime key, deployment id, chain family, lifecycle, sequence stage, UI phase, generation, chain id, and short reason tokens. Never emit wallet addresses, balances, raw RPC payloads, tx values, or secrets.

## Namespaces

| Namespace | Purpose |
| --- | --- |
| `staking.runtime.*` | Connect readiness, vault tx loading, runtime swap stalls |
| `staking.wallet.*` | Reserved structured namespace for wallet failures; current wallet signals are mostly breadcrumbs plus `staking.runtime.*` / `staking.hydration.*` events |
| `staking.tx.*` | Tx lifecycle, signature stalls, orphaned flows |
| `staking.hydration.*` | Persisted restore, reconcile, signer hydration |
| `staking.refresh.*` | Refresh deadlocks and orchestrator starvation |
| `staking.network.*` | Wrong network and RPC degradation |
| `staking.runtime_selection.*` | Selection/coordinator desync |
| `staking.provider.*` | Provider hierarchy and reconnect loops |
| `staking.mobile.*` | BFCache, deep-link, visibility resume |
| `staking.async.*` | Stale commits and abandoned leases |
| `staking.invariant.*` | Impossible runtime states |
| `staking.performance.*` | Modal stalls and gas estimate depth |

Not every namespace in `taxonomy.ts` has active emitters. Some names are reserved for compatibility or planned wiring; check the table below and source emitters before treating a namespace as operationally live.

## Representative implemented Sentry events

| Event | Level | Main emitter / source |
| --- | --- | --- |
| `staking.runtime.connect_stalled` | warning | Connect stall watchdog |
| `staking.runtime.vault_tx_loading_stalled` | warning | Vault tx loading stall watchdog |
| `staking.tx.awaiting_signature_stalled` | warning | Signature stall watchdog |
| `staking.hydration.signer_hydration_stalled` | error | Signer hydration failure path |
| `staking.hydration.reconcile_failure` | warning/error | Runtime telemetry bridge |
| `staking.refresh.orchestrator_starvation` | warning | Runtime telemetry bridge |
| `staking.refresh.balance_wall_stall` | warning | Runtime telemetry bridge |
| `staking.async.commit_denied` | warning | Runtime telemetry bridge |
| `staking.async.stale_operation` | warning | Tx execution abandon reason |
| `staking.invariant.disabled_family_participating` | error | Runtime family participation check |
| `staking.invariant.runtime_swap_final_failed` | error/fatal | Runtime swap non-policy failure; fatal only for final invariant failure |
| `staking.mobile.bfcache_restore_failed` | error | Wallet resume hardening |

## Runtime aggregate events

| Event | Meaning |
| --- | --- |
| `repeated_async_commit_denied` | Async coordinator commit gate rejected work repeatedly |
| `runtime_selection_desync` | Passive selection identity disagrees with coordinator snapshot |
| `runtime_transition_stuck` | Lifecycle/sequence stayed non-terminal beyond threshold |
| `orchestrator_starvation` | Balance orchestrator commit skips starved updates |
| `rpc_degradation_detected` / `rpc_degradation_recovered` | Read path degraded or recovered |
| `hydrate_reconcile_failure` | Persisted tx reconcile rejected or threw before safe commit |
| `modal_non_terminal_timeout` / `modal_phase_stall` | Tx modal remained non-terminal beyond thresholds |
| `tx_retry_loop_excessive` | Terminal-flow retry count exceeded threshold |
| `excessive_gas_estimate_depth` | Concurrent gas estimate depth unexpectedly high |
| `registry_growth_abnormal` | Provider registry map growth exceeded expected bounds |
| `provider_reconnect_loop` | WS/provider reconnect backoff repeated |

## Network error classification (`src/lib/networkErrors/`)

Central normalizer: `normalizeNetworkError(error, hint)` → plain `NormalizedNetworkError` (never thrown). Original errors are preserved; optional `WeakMap` metadata via `attachNetworkErrorMetadata`.

**Sentry path:** `captureStakingNetworkError(normalized)` — structured messages only (`captureStakingStructuredEvent`), deterministic titles like `[RPC_TIMEOUT] RPC request timeout`, fingerprint `[network_error_type, endpoint_type, rpc_host]`, dedupe key `network:{type}:{endpoint_type}:{host}`.

**Volume rules:** no per-`eth_call` Sentry; aggregate alerts only (`rpc_degradation_detected` ≥3 orchestrator tick failures, WS reconnect loop ≥4 attempts in 60s rolling window, indexer/API hard failures, gas estimate exhaustion). URLs sanitized before tags/context; messages truncated (~1500 chars).

**New taxonomy events:** `staking.network.rpc_failure`, `indexer_failure`, `api_failure`, `websocket_failure`, `wallet_session_failure`.

**DEV:** set `VITE_DEBUG_NETWORK=true` for `[network]` console logs (never on hot paths by default).

## Tags, contexts, and breadcrumbs

Canonical tags include wallet vendor, chain family, deployment id, runtime key, blocking gate, tx phase, UI phase, mobile/browser/visibility state, signer state, hydration state, execution network state, AppKit connection, provider type, session type, release, environment, and network-specific: `rpc_host`, `rpc_transport`, `rpc_chain_id`, `endpoint_type`, `network_error_type`.

Contexts group runtime, wallet, tx, hydration, visibility, network, provider, async, and mobile details. Breadcrumbs stay sparse: connect clicked, modal open, wallet connected, signer hydration, runtime reconcile/swap/ready, tx started/signature/hash/confirming/confirmed/failed, visibility, page show/hide, and runtime deadlock detection.

## Dedupe and severity

- Info: expected recoverable transitions and breadcrumbs.
- Warning: stalls, retries, abandoned leases, orchestrator starvation.
- Error: hydration failures, non-fatal invariants, receipt errors.
- Fatal: final invariant failures and provider tree corruption.

Dedupe is per session/cooldown key. Runtime telemetry also enforces a global burst cap. Watchdogs must use timers and gate keys, not render-loop reporting.

## Operational alerts

Page or alert on invariant failures, runtime transition stuck, sustained RPC degradation, and repeated hydration reconcile failures. Dashboard rates for orchestrator starvation, modal phase stalls, provider reconnect loops, registry growth, and connect stalls by deployment id / chain family.
