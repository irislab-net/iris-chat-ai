# Deploy/runtime observability

Canonical operational note for production deploys, static asset behavior, build metadata, Sentry release correlation, and build scripts.

## Static asset rules

1. `/assets/*` must never rewrite to `/index.html`. Missing hashed chunks should return 404, not HTML with status 200.
2. Hashed JS/CSS assets should use long-lived immutable caching.
3. `index.html` must use no long-lived cache so clients fetch a fresh asset graph after deploy.
4. Stale-chunk recovery exists for Safari/mobile tabs that keep an old module graph across deploy or BFCache restore. The app performs a single guarded reload on dynamic import, MIME, or chunk-load failures.

## Post-deploy asset verification

Use the production origin and a real hashed file from `dist/assets/` or `index.html`.

```bash
curl -sI "https://<origin>/assets/<hashed>.js"
curl -sI "https://<origin>/index.html"
curl -sI "https://<origin>/assets/nonexistent-deadbeef.js"
```

Expect:

- Real JS chunks return 200 with JavaScript content type.
- `index.html` returns no-cache / must-revalidate or equivalent.
- Missing assets return 404 and never SPA fallback HTML.
- `/assets/*` headers include immutable caching for hashed files.

## Release correlation

Production builds inject deploy metadata into `import.meta.env` through `vite.config.ts` and `scripts/resolveBuildRelease.mjs`.

| Field | Purpose |
| --- | --- |
| `VITE_SENTRY_RELEASE` | Sentry release name used by client and sourcemap upload |
| `VITE_APP_BUILD_ID` | App build identifier, usually env-provided or git short SHA |
| `VITE_BUILD_HASH` | Build hash for deploy correlation |
| `VITE_DEPLOYMENT_ID` | Hosting/deployment id, including Cloudflare Pages when available |
| `VITE_RUNTIME_ASSET_VERSION` | Runtime asset version tag for stale-tab correlation |
| `VITE_RUNTIME_TELEMETRY_STAGE` | `0`–`4` — gates `emitRuntimeTelemetry` aggregates (`1`+). Required for orchestrator/RPC degradation signals that map to `staking.network.*` / refresh stalls via the Sentry bridge. Recommended **`2`** on Cloudflare Pages production when Sentry is enabled. Independent of `VITE_RUNTIME_TELEMETRY_SAMPLE_RATE` (stage ≥ `3` only). |
| `VITE_RUNTIME_TELEMETRY_SAMPLE_RATE` | Optional `0`–`1` sample rate when stage ≥ `3` (default `0.12`). Do not change for noise fixes. |

Runtime Sentry scope applies these as tags so stale chunks, WalletConnect failures, connect stalls, and wallet breadcrumbs can be separated by deploy.

The runtime-telemetry → Sentry bridge registers whenever `VITE_SENTRY_DSN` is set (see `main.tsx`). Telemetry **emission** still requires `VITE_RUNTIME_TELEMETRY_STAGE >= 1`; without it, only direct `captureStaking*` paths (stall watchdogs, gas network alerts, etc.) reach Sentry.

## Sentry sourcemap flow

Primary path: `@sentry/vite-plugin` runs during production Vite builds when DSN/auth/org/project configuration is present. It uploads hidden sourcemaps using the same release name and deletes maps after upload. The plugin reads `SENTRY_AUTH_TOKEN` from `process.env`.

Fallback path: `pnpm build:sentry` runs `scripts/sentry-upload-sourcemaps.mjs`, which invokes `@sentry/cli` with the release resolved by `scripts/resolveBuildRelease.mjs`. Keep this path for CI or hosts that prefer a separate upload step. This fallback does not run `scripts/strip-dist-sourcemaps.mjs`; map deletion must come from the Vite plugin delete-after-upload path or external release policy.

Default `pnpm build` runs `scripts/strip-dist-sourcemaps.mjs` after Vite build. That script removes built sourcemaps when `SENTRY_AUTH_TOKEN` is absent, preventing accidental public map exposure in the default non-upload path.

## Build scripts

| Script file | Operational purpose |
| --- | --- |
| `scripts/resolveBuildRelease.mjs` | Shared release and deploy-correlation resolver for Vite and Sentry CLI |
| `scripts/resolveBuildRelease.d.mts` | Type declarations for TS build tooling importing the `.mjs` resolver |
| `scripts/strip-dist-sourcemaps.mjs` | Default production build cleanup for sourcemaps |
| `scripts/sentry-upload-sourcemaps.mjs` | CI/release fallback sourcemap upload path |

Do not delete these scripts without checking external deployment configuration.

## Production rollout checklist

1. Deploy normally with injected build ids and Sentry release.
2. Purge edge/cache state if the host can serve stale `index.html`.
3. Run asset verification checks.
4. Smoke test fresh tab, stale tab, background return, connected wallet, and orphaned WalletConnect session.
5. Monitor Sentry for MIME/chunk errors, `stale_chunk_recovery`, WalletConnect stale-session errors, connect stalls, and release-specific spikes.

Expected stale-tab errors may appear around deploy time, but they should self-recover and correlate to the older build id or runtime asset version.
