# Phase 42 stabilization anchor

This path is retained because runtime source comments reference it. The detailed phase report has been consolidated into the active canonical docs and should no longer be treated as a standalone source of truth. Treat this file as a compatibility anchor plus historical stabilization summary.

## Canonical replacements

| Topic | Canonical doc |
| --- | --- |
| Runtime ownership, hook order, async commit gates | `docs/staking-runtime-contracts.md` |
| Architecture boundaries and frozen package ownership | `docs/staking-domain-boundaries.md` |
| Retry, BFCache, mobile return, and lifecycle edge cases | `docs/staking-runtime-edgecases.md` |
| Operational change rules | `docs/staking-maintenance-rules.md` |
| Historical phase context | `docs/archive/migration-phase-reports/README.md` |

## Preserved Phase 42 invariants

- Runtime core is production-frozen unless a bug or regression requires a surgical change.
- Active runtime selection and coordinator generation gate async commits.
- Runtime swaps go through policy and engine layers; direct state mutation is unsupported.
- Provider registry keys are deployment/runtime-key scoped and must not grow unbounded.
- DEV stress, torture, and chaos tooling observes runtime health only; it must not ship as production behavior.

For current implementation guidance, update the canonical docs above instead of expanding this phase anchor.
