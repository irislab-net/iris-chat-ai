# Staking final state report (ARCH-FREEZE metrics)

**Captured:** 2026-05-16 (workspace snapshot).  
**Method:** automated counts from `src/staking` and `src/config/env.ts`; qualitative debt from static review.

---

## Totals

| Metric | Value | Notes |
| --- | ---: | --- |
| Top-level staking **packages** (folders under `src/staking/`) | **21** | `affiliate` … `vault` |
| Staking tree `.ts` / `.tsx` files | **184** | `Get-ChildItem -Recurse` under `src/staking` |
| `src/lib/staking*` `.ts` / `.tsx` files | **20** | Legacy / product helpers **outside** canonical tree |
| **Production-required** `VITE_*` keys (app-wide) | **12** | `src/config/envRequiredKeys.ts` |
| Staking-related `VITE_*` keys in `env.ts` (core + multi-row + rollout) | **~24–26** | See breakdown below — not all required |

### Staking env surface (approximate)

**Always wired / legacy primary**

- `VITE_STAKING_CHAIN_ID`, `VITE_STAKING_RPC_URL`, `VITE_STAKING_VAULT_ADDRESS`, `VITE_STAKING_EXPLORER_BASE_URL`, `VITE_STAKING_TERMS_URL`
- Optional: `VITE_STAKING_WS_URL`, `VITE_STAKING_TX_HISTORY_ORIGIN`, `VITE_STAKING_TOKEN_ADDRESS`, `VITE_STAKING_DEPLOYMENTS_JSON`, `VITE_STAKING_HIGH_NETWORK_FEE_WEI`

**Family rollout**

- `VITE_ENABLE_ETHEREUM`, `VITE_ENABLE_TRON`

**Explicit env deployment blocks**

- `VITE_STAKING_ETH_*` (vault, chain id, RPC, WS, explorer, CAIP-2)
- `VITE_STAKING_TRON_*` (vault, RPC, explorer, CAIP-2, token, tx grid API)

**Adjacent**

- `VITE_APPKIT_TRON_IDENTITY`, Reown / metadata keys (shared with non-staking)

Exact counts drift as `env.ts` evolves — treat the **source file** as authoritative.

---

## Deleted shim / dead-file counts

| Metric | Value |
| --- | --- |
| Deleted shim count (this report) | **Not machine-generated** |
| Deleted dead-file count | **Not machine-generated** |

Historical removals are recorded in migration reports (e.g. G4 / bridge / canonicalization docs under `docs/`). **Do not** invent numbers — use `git log --diff-filter=D --summary` when an audit trail is required.

---

## Remaining transitional modules

| Area | Examples |
| --- | --- |
| Core **boundary shims** | `src/staking/core/runtimeCoreLayerBoundaryDev.ts` (points diagnostics consumers to `@/staking/diagnostics`) |
| Network **deprecated const aliases** | `STAKING_VAULT_EVM_SWITCH_VERIFY_*` in `stakingNetworkContracts.ts` |
| Receipt **deprecation notes** | `createTronReceiptResolver` — registry-bound path preferred |
| `src/lib/staking*` | Product-facing helpers (gas display, deposit approval, etc.) still consumed by **pages** and some `staking/*` modules — **not** deleted in freeze |

---

## Remaining technical debt

- **Dual surface:** canonical `src/staking/*` vs **twenty** `src/lib/staking*` files — boundary rules limit **imports into** staking, not all outbound usage from UI.
- **EVM AppKit switch** still maps `eip155` to `STAKING_APPKIT_NETWORK` in `openUnifiedWallet.ts` for CAIP-only resolution (default network is deployment-aware in `reownKit` / `appKitStakingNetworks`).
- **Deprecated UI phases** in tx types (`transactionStatusUiPhase.ts`) — legacy enum values called out inline.
- **Telemetry / soak** complexity in diagnostics — high signal for regressions but non-trivial to onboard.

---

## Frozen boundaries

- **Composer hook order** (`stakingVaultComposerContracts`)
- **Network registration order** (`stakingNetworkContracts`)
- **Refresh phase registration** (`stakingInvariantAssertionsDev` + refresh plane)
- **CFG6 sentinel + hydration** (`stakingRuntimeDisabledSentinel`, `stakingRuntimeHydration`)
- **Provider registry keys** (`deriveProviderRuntimeKey`)
- **Family rollout gating** (`stakingRuntimeFamilyRollout` + registry filter)

---

## Architecture risk level

**Medium–high.**

- Hook-order regressions are **silent** until subtle reconnect / refresh bugs appear.
- Multi-family (EVM + passive Tron) increases **state-space** for wrong-network and identity.
- Registry + sentinel path must stay **fail-closed** to avoid hydrating fake RPC.

---

## Future **safe** work categories

- Copy, a11y, theming on staking pages
- Additional **DEV** assertions and docs
- Performance **measurement** (no reorder) — profiling, memoization inside owners
- New **deployment rows** via env/JSON **without** changing composer order

---

## Future **unsafe** work categories (without review)

- “Small” hook reorder in composer or refresh plane
- New abstraction layer over vault/refresh/history
- Restoring **retired** composer network shim
- Changing orchestration **lifecycle** or wallet hook ordering
- Splitting provider registry or sentinel semantics ad hoc

---

## DEV freeze tooling (reference)

| Export / global | Role |
| --- | --- |
| `STAKING_ARCHITECTURE_FREEZE_TOKEN` | Static freeze token |
| `STAKING_HOOK_ORDER_FREEZE_MARK` | Hook-order marker string |
| `runStakingArchitectureFreezeChecksDev` | Async checks + optional source scan |
| `window.__STAKING_ARCH_FREEZE__` | DEV console entry (after vault diagnostics mount) |
| `runStakingArchitectureSmokeDev` | Existing smoke (`window.__STAKING_ARCHITECTURE_SMOKE__`) |
| `devAssertRefreshPlaneRegistrationOrder` | Per-phase refresh order |

---

## Sign-off

This report is a **metrics snapshot**, not a performance benchmark or security audit. For invariant truth, rely on **CI**, **smoke/freeze runs in DEV**, and the contracts referenced in `docs/archive/migration-phase-reports/staking-final-architecture.md`.
