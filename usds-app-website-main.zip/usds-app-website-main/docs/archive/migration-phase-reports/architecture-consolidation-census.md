# Architecture consolidation census — Phase A (inventory only)

**Status:** Read-only census. No refactors, moves, renames, or deletions performed.

**Scope:** Staking runtime, wallet orchestration, AppKit, coordinator, tx lifecycle, navbar wallet, passive Tron, runtime identity, execution plane, DEV diagnostics, soak tooling, bridges, and compatibility layers.

**Date:** 2026-05-15

---

## 1. Executive summary

The staking/wallet system is a **multi-runtime product** (EVM + passive/unified Tron) with a deliberately **frozen production core** (`src/staking/core`, Phases 34–42) and a **composition layer** that grew around it (`useStakingVault`, large form/tx UI modules, external identity publish for navbar).

| Layer | Role | Primary location |
| ----- | ---- | ---------------- |
| **Runtime kernel** | Registry, selection, transitions, swap policy/engine, coordinator gates | `src/staking/core/` |
| **Vault composition** | Reads, balances, history, affiliate, tx APIs, plane split | `src/hooks/useStakingVault.ts` |
| **Wallet planes** | Runtime UI identity vs EVM execution (`eip155`) | Vault + `stakingRuntimeWalletIdentity*` + Tron libs |
| **Tx lifecycle** | Modal state, persistence, on-chain recovery | `TransactionStatusProvider` + `lib/staking/stakingTx*` |
| **External identity bus** | Navbar outside vault provider | `stakingRuntimeWalletIdentityBridge.ts` |
| **DEV / soak** | Stress, chaos, soak monitor, deprecated-bridge warnings | `src/staking/dev/`, `lib/staking/*Soak*`, `*Dev.ts` |

**Entropy hotspots (by line count and coupling):**

1. `useStakingVault.ts` (~2293) — god hook; owns reads, refresh, history, planes, publish, soak tick
2. `StakingAppDepositForm.tsx` (~1730), `StakingAppWithdrawForm.tsx` (~1631), `StakingAppTransactionHistory.tsx` (~1631)
3. `TransactionStatusProvider.tsx` (~1467), `TransactionStatusSurface.tsx` (~1253)
4. `stakingRuntimeSoakMonitor.ts` (~757)
5. `useStakingGasEstimate.ts` (~749)

**Architectural smells:**

- `staking/core` imports **UI tx model types** (`transactionStatusModel`) — core → UI dependency
- `lib/staking` imports **hooks** (`useStakingCtaState`) and **UI models** — lib → UI/hooks inversion
- **Dual wallet state paths:** vault context vs published identity bridge vs raw `useWallet()` on marketing routes
- **Deprecated vault bridges** still exported with DEV getters — migration incomplete
- **Oversized modules** (>500 lines): 15 files in scope (see §4)

---

## 2. Domain map (current structure)

```
src/
├── staking/
│   ├── core/          # Runtime kernel (registry, selection, transition, swap, providers)
│   └── dev/           # Stress, chaos, torture, readiness gate (DEV-only env flags)
├── lib/
│   ├── staking/       # Reads, refresh, identity, tx persistence, soak, CTA helpers
│   ├── tron/          # Passive Tron identity, reads, history, unified resolver
│   ├── wallet/        # openUnifiedWallet (AppKit namespace helpers)
│   ├── runtimeTelemetry/
│   └── stakingProduct/  # Product catalog / routing (Phase 45–46)
├── hooks/             # Vault, gas, CTA, AppKit isolation, orchestration, lifecycle
├── components/
│   ├── pages/staking/ # App UI, forms, tx modal, vault provider
│   ├── layout/        # NavbarWalletSection (uses identity bridge, not vault)
│   └── dev/           # RuntimePickerDevPanel
├── reownKit.ts        # createAppKit (EVM, Solana, Tron)
└── lib/appKitBootstrap.ts, walletConnectAppMetadata.ts
```

**Adjacent (not fully inventoried row-by-row, but runtime-critical):**

| Path | Role |
| ---- | ---- |
| `src/constants/stakingVaultConfig.ts`, `stakingCta*.ts`, `stakingNotificationSpec.ts` | Env-backed staking config and UX contracts |
| `src/lib/stakingEtherscanHistory.ts`, `stakingAffiliateTxHistory.ts` | History aggregation |
| `src/lib/stakingAmountInput.ts`, `stakingDepositApprovalExecution.ts` | Amount parsing, approval execution |
| `src/services/gasEstimator.ts` | Gas estimation (uses `runtimeKey`) |
| `src/abis/stakingVault.ts` | Contract ABIs |
| `src/config/env.ts` | `VITE_*` gates for runtime stress, Tron identity, telemetry |
| `src/providers/BootstrapOrchestrationProvider.tsx` | App bootstrap + vault hydration reporting |

---

## 3. File census and classification

Legend:

| Tag | Meaning |
| --- | ------- |
| **PC** | Production critical |
| **DEV** | DEV-only or env-gated |
| **BR** | Bridge / temporary migration |
| **DEP** | Deprecated API surface |
| **INT** | Internal-only (no stable public API) |
| **PUB** | Intended public/stable API |
| **MIX** | Mixed concerns |
| **>500** | Oversized module |
| **DUP** | Duplicate / overlapping responsibility |
| **DEAD?** | Dead candidate (needs usage proof before removal) |

### 3.1 Runtime kernel — `src/staking/core/` (44 files)

| File | Lines | Domain | Responsibility | API | Tags |
| ---- | ----:| ------ | -------------- | --- | ---- |
| `types.ts` | 72 | runtime | Deployment registry types, CAIP-2 | PUB | PC |
| `getStakingDeploymentRegistry.ts` | 161 | runtime | Single registry source | PUB | PC |
| `buildDeploymentRegistryFromJson.ts` | 181 | runtime | JSON env deployments ingest | INT | PC |
| `buildExplicitEnvDeploymentRows.ts` | 134 | runtime | Phase 46 explicit ETH/TRON rows | INT | PC |
| `buildLegacyDeploymentFromEnv.ts` | 46 | runtime | Legacy single deployment | INT | PC, legacy |
| `normalizeDeployment.ts` | 51 | runtime | Row normalization | INT | PC |
| `validateDeployment.ts` | 134 | runtime | Structural validation | INT | PC |
| `validateTronDeployment.ts` | 119 | runtime | Tron-specific validation | INT | PC |
| `registryValidation.ts` | 177 | runtime | Full-registry soft validation | INT | PC |
| `deploymentFamily.ts` | 31 | runtime | Chain family constants | PUB | PC |
| `getDefaultDeploymentId.ts` | 6 | runtime | Default deployment id | PUB | PC |
| `providerRegistry.ts` | 246 | runtime | Cached EVM/Tron providers + receipts | PUB | PC |
| `providerRuntime.ts` | 78 | runtime | Provider runtime key derivation | INT | PC |
| `createStakingJsonRpcProvider.ts` | 54 | runtime | EVM JSON-RPC factory | INT | PC |
| `createTronHttpProvider.ts` | 32 | runtime | Tron HTTP client | INT | PC |
| `createEvmReceiptResolver.ts` | 27 | runtime | EVM receipt resolver factory | INT | PC |
| `createTronReceiptResolverRuntime.ts` | 55 | runtime | Deployment-bound Tron receipts | PUB | PC |
| `createTronReceiptResolver.ts` | 11 | runtime | Deprecated shim | DEP | BR, legacy |
| `createExplorerResolver.ts` | 49 | runtime | Explorer URLs | DEP alias | BR |
| `runtimeFamilyDispatch.ts` | 83 | runtime | EVM vs Tron read routing | PUB | PC |
| `runtimeCacheKey.ts` | 35 | runtime | Cache key materialization | PUB | PC |
| `runtimeCapabilities.ts` | 125 | runtime | Per-deployment capability flags | PUB | PC |
| `runtimeReadContext.ts` | 39 | runtime | Read identity from selection | INT | PC |
| `runtimeOperationContext.ts` | 27 | runtime | Active runtime bundle for services | PUB | PC |
| `runtimeGeneration.ts` | 20 | runtime | Generation counter helpers | INT | PC |
| `runtimeExecutionTarget.ts` | 62 | runtime | Immutable execution target (Phase 30 frozen) | PUB | PC |
| `runtimeExecutionGuard.ts` | 41 | runtime | Block execution during transitions | PUB | PC |
| `runtimeSelection.ts` | 85 | runtime | ActiveRuntimeSelection types | PUB | PC |
| `runtimeSelectionDefaults.ts` | 32 | runtime | Default selection when omitted | INT | PC |
| `runtimeSelectionContext.tsx` | 264 | runtime | React provider + transition controller | PUB | PC, MIX |
| `runtimeSelectionHooks.ts` | 99 | runtime | Transition snapshot hooks | PUB | PC |
| `runtimeTransition.ts` | 58 | runtime | Transition state types | PUB | PC |
| `runtimeTransitionController.ts` | 199 | runtime | Transition state machine | PUB | PC |
| `runtimeTransitionCoordinator.ts` | 220 | runtime | Commit/refresh gates | PUB | PC |
| `runtimeTransitionSequence.ts` | 85 | runtime | Ordered transition actions | INT | PC |
| `runtimeSwapPolicy.ts` | 180 | runtime | Swap admission during tx/refresh | PUB | PC, **imports UI tx phase type** |
| `runtimeSwapEngine.ts` | 236 | runtime | Production-frozen swap protocol | PUB | PC |
| `runtimeTransitionTelemetry.ts` | 494 | runtime | DEV transition breadcrumbs | DEV | >500, MIX |
| `persistenceTypes.ts` | 73 | runtime | Persisted tx session types | PUB | PC |
| `defaultPersistedTxReconcileContext.ts` | 18 | runtime | Reconcile context from snapshot | INT | PC |
| `tronProviderTypes.ts` | 18 | runtime | Tron provider typing | INT | PC |
| `address/*` | 16–51 | runtime | EVM/Tron address codecs | PUB | PC |

**Naming inconsistency:** `createExplorerResolver` vs `createDeploymentExplorerResolver`; `Etherium` typo in `useEtheriumWallet.tsx` (hook, not in this folder).

### 3.2 Runtime DEV — `src/staking/dev/` (7 files)

| File | Lines | Domain | Responsibility | Tags |
| ---- | ----:| ------ | -------------- | ---- |
| `runtimeSwapStressHarness.ts` | 325 | dev | Swap stress driver | DEV, PC-adjacent |
| `runtimeReadinessGate.ts` | 311 | dev | Pre-swap readiness gate | DEV |
| `runtimeChaosSuite.ts` | 191 | dev | RPC/visibility chaos | DEV |
| `runtimeTortureSuite.ts` | 185 | dev | Long-lived torture loops | DEV |
| `runtimeSwapScenarios.ts` | 165 | dev | Scenario builders | DEV |
| `runtimeLifecycleAssertions.ts` | 150 | dev | Registry/tx invariants | DEV, imports UI model |

All gated by `VITE_RUNTIME_*` in `src/config/env.ts` (never true in production builds).

### 3.3 Lib staking — `src/lib/staking/` (36 TS + 3 MD)

| File | Lines | Domain | Responsibility | API | Tags |
| ---- | ----:| ------ | -------------- | --- | ---- |
| `stakingRuntimeWalletIdentity.ts` | 79 | identity | Resolve/format runtime wallet identity | PUB | PC |
| `stakingRuntimeWalletIdentityBridge.ts` | 144 | identity | Publish/subscribe for navbar | PUB | BR, PC |
| `stakingNavbarVisualHold.ts` | 81 | identity/ui | Navbar disconnect vs transient hold | INT | PC |
| `stakingPassiveRuntimeUx.ts` | 21 | identity/ui | Passive Tron copy | PUB | PC |
| `stakingReadFactory.ts` | 236 | execution/reads | Contract read factory | PUB | PC |
| `stakingReadProviders.ts` | 286 | execution/reads | HTTP/WS provider lifecycle | PUB | PC |
| `stakingRefreshOrchestrator.ts` | 574 | orchestration | Balance refresh single-flight | PUB | PC, >500 |
| `stakingRefreshMetrics.ts` | 63 | orchestration | Refresh timing metrics | INT | DEV-leaning |
| `stakingTxSessionPersistence.ts` | 316 | tx | Persisted tx session V1 | PUB | PC, MIX |
| `stakingTxOnChainRecovery.ts` | 96 | tx | On-chain recovery | PUB | PC, imports UI model |
| `stakingTxExplorerFromDeployment.ts` | 33 | tx | Explorer URLs from deployment | PUB | PC |
| `stakingSnapshotCtaPhase.ts` | 62 | tx/cta | CTA phase from snapshot | INT | PC |
| `stakingRuntimeExecutionPlaneTelemetry.ts` | 65 | diagnostics | Runtime vs execution plane logs | DEV | PC-observability |
| `stakingRuntimeSoakMonitor.ts` | 757 | diagnostics | Soak instability detectors | DEV | >500 |
| `stakingRuntimeSoakAnalysis.ts` | 175 | diagnostics | Timeline analyzer | DEV | PC-gate |
| `stakingRuntimeSoakTypes.ts` | 35 | diagnostics | Soak types | PUB | DEV |
| `stakingVaultDeprecatedFieldDev.ts` | 52 | bridges | Deprecated field trace types | DEV | BR |
| `stakingVaultDeprecatedBridgeDev.ts` | 34 | bridges | DEV getters on vault bridges | DEV | BR |
| `stakingVaultSemanticAssertionsDev.ts` | 63 | diagnostics | Plane separation asserts | DEV | PC-gate |
| `stakingCtaDiagnostics.ts` | 52 | diagnostics | CTA debug logging | DEV | |
| `stakingFormInlineReasonResolver.ts` | 104 | ui/cta | Inline disable reasons | INT | imports hook |
| `stakingFeeCanonical.ts` | 68 | ui | Fee formatting | PUB | |
| `buildNetworkFeePresentation.ts` | 95 | ui | Network fee presentation | PUB | |
| `ethUsdPriceCache.ts` | 174 | reads | ETH/USD cache | PUB | |
| `profitManagerStatusSingleton.ts` | 149 | reads | Firestore status cache | PUB | |
| `stakingToast.ts` | 147 | ui | Deduped toasts | PUB | |
| `stakingPassiveNotificationPolicy.ts` | 28 | ui | Passive Tron Sonner dedupe | PUB | |
| `stakingMobileResumeCoordinator.ts` | 121 | orchestration | Mobile resume refresh | PUB | |
| `stakingLifecycleInstrumentation.ts` | 31 | diagnostics | Mobile/tx lifecycle trace | DEV | |
| `stakingTxIntegrityDev.ts` | 28 | diagnostics | Tx integrity checks | DEV | |
| `stakingAmountSliderVisual.ts` | 50 | ui | Slider styles | PUB | |
| `stakingInputStyles.ts` | 54 | ui | Input style bundles | PUB | |
| `stakingCtaEllipsisPolicy.ts` | 78 | ui | CTA ellipsis policy | PUB | |
| `stakingCtaInlineReasonPolicy.ts` | 51 | ui | Inline reason policy | PUB | |
| `receipt*SonnerPolicy.ts` | 16–19 | ui | Receipt toast policy | PUB | |
| `originalTelegramUrl.ts` | 98 | ui | Telegram deep links | PUB | |
| `*.md` (3) | — | docs | In-tree architecture notes | — | |

### 3.4 Tron — `src/lib/tron/` (4 files)

| File | Lines | Domain | Responsibility | Tags |
| ---- | ----:| ------ | -------------- | ---- |
| `tronWalletIdentity.ts` | 386 | wallet/passive | TronLink passive account + network hooks | PUB, PC |
| `resolveUnifiedTronIdentity.ts` | 104 | identity | AppKit-first Tron resolver | PUB, PC |
| `tronPassiveReads.ts` | 294 | execution/reads | Passive contract reads | PUB, PC |
| `tronTransactionHistory.ts` | 316 | tx/history | Tron history rows | PUB, PC |

### 3.5 Wallet / AppKit — hooks + bootstrap

| File | Lines | Domain | Responsibility | Tags |
| ---- | ----:| ------ | -------------- | ---- |
| `hooks/useStakingVault.ts` | 2293 | vault | **Central composition** — all vault state | PUB | PC, >500, MIX |
| `hooks/useUnifiedWalletOrchestration.ts` | 85 | orchestration | AppKit open/account/network per namespace | PUB | PC |
| `hooks/useAppKitEvmIsolationOnPassiveTron.ts` | 155 | wallet | EIP-155 isolation on passive Tron | PUB | PC |
| `hooks/useEtheriumWallet.tsx` | 71 | execution | EVM provider/signer (gated off Tron) | PUB | PC, naming |
| `hooks/useWallet.tsx` | 59 | wallet | Global AppKit entry (marketing) | PUB | DUP surface |
| `hooks/useAppKitTronAccount.ts` | 41 | wallet | Tron namespace account | INT | diagnostics |
| `hooks/useAppKitTronIdentityDiagnostics.ts` | 50 | diagnostics | Tron identity mismatch | DEV | |
| `hooks/useAppKitReady.ts` | 5 | wallet | Bootstrap ready flag | PUB | |
| `hooks/useStakingCtaState.ts` | 647 | ui/cta | Primary CTA state machine | PUB | PC, >500 |
| `hooks/useStakingGasEstimate.ts` | 749 | execution | Gas/fee estimates | PUB | PC, >500 |
| `hooks/useStakingFormLifecycle.ts` | 180 | tx/ui | Form reset on disconnect (debounced) | PUB | PC, not visual |
| `hooks/useStakingFeeDisplaySmoothing.ts` | 280 | ui | Fee display smoothing | PUB | |
| `hooks/useStakingEthUsdPresentation.ts` | 34 | ui | ETH/USD presentation | PUB | |
| `hooks/useStakingGasToastDedupe.ts` | 83 | ui | Gas toast dedupe | PUB | |
| `hooks/useStakingReferral.ts` | 115 | ui | Referral validation | PUB | |
| `hooks/useRollingStakedDisplay.ts` | 332 | ui | Rolling balance animation | PUB | |
| `hooks/useWithdrawalProtocolFee.ts` | 212 | ui | Protocol fee hook | PUB | |
| `lib/wallet/openUnifiedWallet.ts` | 92 | orchestration | AppKit open/switch by namespace | PUB | PC |
| `reownKit.ts` | 88 | wallet | createAppKit wiring | PUB | PC |
| `lib/appKitBootstrap.ts` | 9 | wallet | Dynamic import reownKit | PUB | PC |
| `lib/walletConnectAppMetadata.ts` | 41 | wallet | WC metadata | PUB | PC |

**Vault deprecated bridges (on `useStakingVault` return):** `isConnected`, `address`, `chainId` → **DEP / BR**; replace with `runtimeWallet*` / `execution*`.

### 3.6 Staking UI — `src/components/pages/staking/` (44 files)

| File | Lines | Domain | Responsibility | Tags |
| ---- | ----:| ------ | -------------- | ---- |
| `StakingVaultProvider.tsx` | 37 | runtime/ui | RuntimeSelection + vault + tx providers | PUB | PC |
| `stakingVaultContext.ts` | 15 | vault | `useStakingVault` accessor | PUB | PC |
| `StakingApp.tsx` | 80 | ui | App shell | PUB | |
| `StakingAppDepositForm.tsx` | 1730 | ui/tx | Deposit flow | PUB | PC, >500, MIX |
| `StakingAppWithdrawForm.tsx` | 1631 | ui/tx | Withdraw flow | PUB | PC, >500, MIX |
| `StakingAppTransactionHistory.tsx` | 1631 | ui | History UI + hold rows | PUB | PC, >500, MIX |
| `TransactionStatusProvider.tsx` | 1467 | tx | Tx modal state + persistence | PUB | PC, >500, MIX |
| `TransactionStatusSurface.tsx` | 1253 | tx | Tx modal UI | PUB | PC, >500 |
| `transactionStatusModel.ts` | 280 | tx | Tx snapshot model + phases | PUB | PC, DEP phases |
| `TransactionStatusContext.tsx` | 27 | tx | Context export | PUB | |
| `StakingAppBalance.tsx` | 506 | ui | Balance panel | PUB | PC, >500 |
| `StakingAppReferral.tsx` | 683 | ui | Referral UI | PUB | >500 |
| `StakingAppNetworkChip.tsx` | 219 | ui/runtime | Network/runtime chip | PUB | PC |
| `StakingAssetSelectSubtree.tsx` | 307 | ui | Asset selector | PUB | |
| `StakingFormActionSummary.tsx` | 248 | ui | Pre-submit summary | PUB | |
| `NavbarWalletSection.tsx` | 474 | ui/wallet | **Outside vault** — identity bridge | PUB | PC, MIX |
| `AppKitTronIdentityDiagnosticsMount.tsx` | 11 | diagnostics | DEV diagnostics gate | DEV | |
| Marketing sections (`staking*.tsx`, etc.) | 15–379 | ui | Landing page | PUB | lower risk |
| Other form rows, terms, skeletons | 37–192 | ui | Supporting UI | PUB | |

### 3.7 Layout + DEV + telemetry + product

| File | Lines | Domain | Responsibility | Tags |
| ---- | ----:| ------ | -------------- | ---- |
| `components/layout/navbar.tsx` | 347 | ui | Site navbar; gates AppKit ready | PUB | |
| `components/layout/NavbarWalletSection.tsx` | 474 | wallet/ui | Staking app wallet chip | PUB | PC |
| `components/dev/RuntimePickerDevPanel.tsx` | — | dev | Runtime picker + torture APIs | DEV | |
| `lib/runtimeTelemetry/runtimeTelemetry.ts` | 200 | diagnostics | Phase 43 breadcrumbs | PUB | env-gated |
| `lib/runtimeTelemetry/runtimeTelemetryTypes.ts` | 46 | diagnostics | Telemetry types | PUB | |
| `lib/stakingProduct/*` (4) | — | product | Catalog, routing, messages | PUB | Phase 45–46 |

### 3.8 Existing docs (reference)

| Doc | Topic |
| --- | ----- |
| `docs/staking-runtime-wallet-migration-status.md` | Runtime vs execution migration, bridge removal gates |
| `docs/staking-runtime-phase42–46-*.md` | Phase freeze, telemetry, rollout, UX, multi-vault |
| `docs/archive/migration-phase-reports/staking-balance-rolling-ui.md` | Rolling balance UI |

---

## 4. Oversized modules (>500 lines)

| File | Lines | Mixed concerns |
| ---- | ----:| ---------------- |
| `hooks/useStakingVault.ts` | 2293 | Registry, wallet planes, reads, refresh, history, affiliate, tx, soak, publish |
| `StakingAppDepositForm.tsx` | 1730 | Form, gas, CTA, tx, vault reads |
| `StakingAppTransactionHistory.tsx` | 1631 | History, filters, export, vault |
| `StakingAppWithdrawForm.tsx` | 1631 | Same family as deposit |
| `TransactionStatusProvider.tsx` | 1467 | Reducer, persistence, runtime freeze, vault |
| `TransactionStatusSurface.tsx` | 1253 | Modal UI only (still huge) |
| `stakingRuntimeSoakMonitor.ts` | 757 | DEV-only but large |
| `useStakingGasEstimate.ts` | 749 | Estimation + presentation coupling |
| `StakingAppReferral.tsx` | 683 | Referral + vault |
| `useStakingCtaState.ts` | 647 | CTA state machine |
| `stakingRefreshOrchestrator.ts` | 574 | Orchestration + DEV hooks |
| `StakingAppBalance.tsx` | 506 | Balance + PnL hold |
| `runtimeTransitionTelemetry.ts` | 494 | Telemetry + counters |
| `NavbarWalletSection.tsx` | 474 | Visual identity + orchestration + DEV trace |
| `RollingTokenAmount.tsx` | 440 | Animation (lower consolidation priority) |

---

## 5. Dependency graph

### 5.1 Runtime-critical path (happy path)

```mermaid
flowchart TB
  subgraph bootstrap [Bootstrap]
    reownKit[reownKit.ts]
    appKitBootstrap[appKitBootstrap.ts]
    env[config/env.ts]
  end

  subgraph runtime_kernel [Runtime kernel]
    registry[getStakingDeploymentRegistry]
    selection[RuntimeSelectionProvider]
    coordinator[runtimeTransitionCoordinator]
    swap[runtimeSwapEngine]
  end

  subgraph vault_layer [Vault composition]
    vault[useStakingVaultState]
    refresh[stakingRefreshOrchestrator]
    readFactory[stakingReadFactory]
  end

  subgraph wallet_planes [Wallet planes]
    runtimeId[stakingRuntimeWalletIdentity]
    bridge[stakingRuntimeWalletIdentityBridge]
    tronPassive[tronWalletIdentity]
    evmIso[useAppKitEvmIsolationOnPassiveTron]
  end

  subgraph ui [Staking UI]
    provider[StakingVaultProvider]
    forms[Deposit/Withdraw forms]
    tx[TransactionStatusProvider]
    navbar[NavbarWalletSection]
  end

  env --> registry
  reownKit --> vault
  registry --> selection
  selection --> vault
  coordinator --> vault
  swap --> selection
  vault --> refresh
  vault --> readFactory
  vault --> runtimeId
  runtimeId --> bridge
  bridge --> navbar
  vault --> provider
  provider --> forms
  provider --> tx
  evmIso --> vault
  tronPassive --> vault
```

### 5.2 Import directions (summary)

| From | To (major) |
| ---- | ----------- |
| `components/pages/staking/*` | `hooks/useStakingVault`, `staking/core/*`, `lib/staking/*`, `lib/tron/*` |
| `hooks/useStakingVault` | `staking/core/*`, `lib/staking/*`, `lib/tron/*`, AppKit, ethers |
| `components/layout/NavbarWalletSection` | `stakingRuntimeWalletIdentityBridge`, `useUnifiedWalletOrchestration`, `useWallet` |
| `staking/core/runtimeSwapPolicy` | **`components/.../transactionStatusModel`** (type only) |
| `lib/staking/stakingTx*` | **`transactionStatusModel`**, `staking/core/persistenceTypes` |
| `lib/staking/stakingFormInlineReasonResolver` | **`hooks/useStakingCtaState`** |
| `staking/core` | Does **not** import hooks or vault (good) except UI tx phase type |

### 5.3 Reverse importers (who depends on X)

| Module | Depended on by |
| ------ | -------------- |
| `useStakingVault` / context | All staking app panels, tx provider, dev runtime picker |
| `stakingRuntimeWalletIdentityBridge` | Navbar only (+ vault publisher) |
| `runtimeTransitionCoordinator` | Vault, refresh orchestrator, swap engine |
| `transactionStatusModel` | Tx provider/surface, lib/staking tx*, swap policy, dev assertions |
| `getStakingDeploymentRegistry` | Registry builders, vault, network chip, navbar (Tron CAIP2) |

### 5.4 Cyclic / inversion risks

| Pattern | Severity | Notes |
| ------- | -------- | ----- |
| `staking/core` → `transactionStatusModel` | **High** | Core depends on UI layer for `TransactionStatusUiPhase`; extract shared type to `staking/core` or `lib/staking/txTypes` |
| `lib/staking` → `transactionStatusModel` | **Medium** | Acceptable short-term if model moves to neutral package |
| `lib/staking` → `useStakingCtaState` | **Medium** | `stakingFormInlineReasonResolver` should depend on types only |
| `transactionStatusModel` → `staking/core/persistenceTypes` | **Low** | Correct direction (model uses core types) |
| Vault publish bridge ↔ Navbar | **Low** | Intentional; not a cycle (one-way publish) |

No **full** import cycle detected among TS modules; risk is **layer inversion** and **type leakage** from UI into core policy.

---

## 6. Duplicate abstractions and state ownership

### 6.1 Duplicate / overlapping responsibilities

| Concern | Owners | Issue |
| ------- | ------ | ----- |
| Wallet “connected” semantics | `runtimeWallet.connected`, `executionConnected`, deprecated `isConnected`, `ctaIdentityConnected`, navbar `showAsConnected` | Four visual/semantic definitions; document single source per surface |
| Short address formatting | `formatStakingRuntimeWalletShort`, AppKit `useWallet().shortAddress`, vault `runtimeWalletShortAddress` | Overlap; navbar uses bridge + hold |
| AppKit open / network | `useWallet`, `useUnifiedWalletOrchestration`, `openUnifiedWallet` | Three entry points; marketing vs staking namespaces |
| Explorer URLs | `createExplorerResolver`, `stakingTxExplorerFromDeployment`, inline deployment resolver in vault | Consolidation candidate |
| Refresh / balance | `stakingRefreshOrchestrator`, vault internal refresh, `useRollingStakedDisplay` | Orchestrator is SoT; UI hooks must not start parallel polling |
| Tx phase / CTA phase | `transactionStatusModel`, `stakingSnapshotCtaPhase`, `useStakingCtaState` | Related but separate; keep boundaries explicit |

### 6.2 State ownership (authoritative)

| State | Owner | Consumers |
| ----- | ----- | ----------- |
| Active runtime (`runtimeKey`, `generation`, deployment) | `RuntimeSelectionProvider` / `useRuntimeTransitionSnapshot` | Vault, forms, tx freeze, gas, registry |
| Runtime wallet identity | `resolveStakingRuntimeWalletIdentity` in vault → **publish** → bridge | Navbar, any non-vault subscriber |
| EVM execution plane | AppKit `eip155` + `useEtheriumWallet` inside vault | Sign, gas, affiliate, EVM history |
| Passive Tron account | `tronWalletIdentity` hooks | Vault Tron reads, unified resolver input |
| Vault balances / protocol reads | `useStakingVault` + refresh orchestrator | Balance, forms, history |
| Tx modal snapshot | `TransactionStatusProvider` | Surface, persistence, CTA derivation |
| Navbar visual hold | `useStakingNavbarVisualIdentity` | Navbar only (not vault) |
| Persisted tx rows | `stakingTxSessionPersistence` + history caches | Tx provider, history (hold rows on load — intentional) |

### 6.3 AppKit semantic leaks (known)

| Location | Leak | Mitigation status |
| -------- | ---- | ----------------- |
| `useWallet()` on marketing routes | Global account, no namespace | OK outside `/staking/app` |
| `useAppKitAccount()` without namespace in vault | Used only for `eip155` / `tron` namespaced slices | Documented in migration doc |
| Deprecated vault `address` / `isConnected` | Reads global-like semantics | DEV warnings; removal gated |
| `NavbarWalletSection` | Uses published runtime, not vault | By design; must clear on disconnect (fixed) |

### 6.4 Bridge and temporary migration layers

| Layer | File(s) | Removal gate |
| ----- | ------- | ------------ |
| Vault deprecated fields | `useStakingVault` return | 5 min stable soak, zero DEV bridge reads (see migration doc) |
| Identity publish bridge | `stakingRuntimeWalletIdentityBridge` | After vault splits or navbar moves inside provider |
| DEV deprecated getters | `stakingVaultDeprecatedBridgeDev` | With bridge field removal |
| `createTronReceiptResolver` shim | `staking/core` | When all callers use registry resolver |
| Tx model legacy phases | `transactionStatusModel` | Persistence migration |

### 6.5 Dead / weak candidates (verify before removal)

| Candidate | Reason |
| --------- | ------ |
| `createTronReceiptResolver.ts` | Marked `@deprecated`; grep callers |
| `createExplorerResolver` deprecated export | Alias only |
| `useAppKitTronAccount` | Diagnostics-only usage |
| `useSolanaWallet` | Non-staking navbar paths |
| Legacy env helpers in `stakingVaultConfig` | `@deprecated` Firestore path |

---

## 7. Entropy hotspots (ranked)

1. **`useStakingVault.ts`** — single file coupling runtime, wallet, reads, tx, telemetry, soak
2. **Deposit/withdraw forms** — duplicate structure; prime for shared hooks module (later)
3. **Transaction status stack** — provider + surface + model + persistence cross imports
4. **Core → UI type import** in `runtimeSwapPolicy` — blocks clean `staking/runtime` package extraction
5. **Navbar outside provider tree** — requires external publish bus; disconnect/visual rules separate from vault
6. **DEV surface area** — soak monitor + telemetry + torture + chaos spread across `lib/staking` and `staking/dev`

---

## 8. Proposed target architecture

Recommended **logical** layout (physical migration in later phases). Prefer **neutral types** under runtime/tx before moving UI.

```
src/staking/
  runtime/              # ← staking/core (registry, selection, transition, swap, providers)
    address/
    providers/
    transition/
    swap/
  wallet/               # AppKit wiring, isolation, openUnifiedWallet, useWallet (staking-scoped)
  identity/             # runtimeWalletIdentity, bridge, tron unified resolver, navbar visual hold
  execution/            # execution target, read factory, gas estimator adapters, ethers signer path
  orchestration/        # refresh orchestrator, mobile resume, coordinator integration
  tx/                   # persistenceTypes, session persistence, on-chain recovery, tx phase types (extracted)
  ui/                   # ← components/pages/staking (forms, balance, history, tx surface)
  diagnostics/          # soak monitor, execution plane telemetry, semantic assertions
  dev/                  # torture, chaos, stress harness, readiness gate
  bridges/              # deprecated vault fields, identity publish (until removed)
  legacy/               # deprecated shims (tron receipt, explorer alias)
  product/              # ← lib/stakingProduct
```

**Alternative:** Keep `components/pages/staking` in place long-term; only move **non-React** modules into `src/staking/*` to reduce risk.

### 8.1 Mapping current → target

| Current | Target |
| ------- | ------ |
| `src/staking/core/*` | `src/staking/runtime/*` |
| `src/staking/dev/*` | `src/staking/dev/*` (unchanged) |
| `src/lib/staking/stakingRuntimeWallet*` + `tron/resolve*` | `src/staking/identity/*` |
| `src/lib/tron/*` | `src/staking/wallet/tron/*` or `identity/tron/*` |
| `src/lib/wallet/openUnifiedWallet.ts` + isolation hooks | `src/staking/wallet/*` |
| `src/hooks/useStakingVault.ts` | Split: `execution/`, `orchestration/`, thin `useStakingVault` composer |
| `src/lib/staking/stakingRefresh*` | `src/staking/orchestration/*` |
| `src/lib/staking/stakingTx*` + `transactionStatusModel` types | `src/staking/tx/*` |
| `src/components/pages/staking/*` | `src/staking/ui/*` (optional move) |
| `src/lib/staking/*Soak*`, `*Dev.ts` | `src/staking/diagnostics/*` |

---

## 9. Migration risk matrix

| Risk | Level | Rationale |
| ---- | ----- | ---------- |
| Move `staking/core` files | **High** | Production-frozen; wide import fan-in |
| Split `useStakingVault` | **High** | All panels; behavior regressions on reads/tx |
| Extract tx types from UI model | **Medium** | Unblocks core policy; needs re-exports |
| Move `lib/staking` read/refresh | **Medium** | Singletons and orchestrator timers |
| Move navbar / bridge | **Medium** | Disconnect visual rules; publish timing |
| Rename `Etherium` → `Ethereum` | **Low** | Mechanical; many imports |
| Remove deprecated vault bridges | **Medium** | Gated on soak + zero DEV reads |
| Move marketing staking pages | **Low** | No runtime coupling |
| Consolidate DEV tooling | **Low** | Env-gated only |

---

## 10. Safe vs unsafe file moves (Phase A guidance)

### 10.1 Safer to move first (low runtime blast radius)

- `stakingNavbarVisualHold.ts`, `stakingPassiveRuntimeUx.ts`
- `stakingCtaDiagnostics.ts`, `stakingCtaEllipsisPolicy.ts`, `stakingCtaInlineReasonPolicy.ts`
- `stakingAmountSliderVisual.ts`, `stakingInputStyles.ts`
- `receipt*SonnerPolicy.ts`, `originalTelegramUrl.ts`
- `lib/stakingProduct/*`
- `staking/dev/*` (already isolated)
- In-tree `lib/staking/*.md`

### 10.2 Unsafe without soak / coordinator sign-off (runtime-critical)

- `staking/core/runtimeSwapEngine.ts`, `runtimeTransitionCoordinator.ts`, `runtimeSelectionContext.tsx`
- `hooks/useStakingVault.ts`
- `stakingRefreshOrchestrator.ts`
- `stakingTxSessionPersistence.ts`
- `TransactionStatusProvider.tsx`
- `stakingRuntimeWalletIdentityBridge.ts` (navbar timing)
- `useAppKitEvmIsolationOnPassiveTron.ts`
- `reownKit.ts`, `providerRegistry.ts`

### 10.3 Temporary compatibility — do not delete until gated

- Vault `isConnected`, `address`, `chainId`
- `stakingVaultDeprecatedBridgeDev.ts`, `stakingVaultDeprecatedFieldDev.ts`
- `stakingRuntimeWalletIdentityBridge.ts` (until navbar in tree or alternate bus)
- `createTronReceiptResolver.ts`, deprecated explorer export
- Legacy tx phases in `transactionStatusModel`

### 10.4 Bridge removal candidates (after gates)

See `docs/staking-runtime-wallet-migration-status.md` § Bridge removal gate:

1. Deprecated vault fields (highest value)
2. DEV bridge getters (with fields)
3. Identity bridge — **not** until navbar subscribes via context or equivalent
4. Deprecated receipt/explorer shims — after caller grep clean

---

## 11. Recommended migration order (high level)

1. **Extract neutral tx/runtime types** — break `runtimeSwapPolicy` → UI import
2. **Document and freeze public APIs** — explicit exports from `staking/runtime`, `staking/identity`
3. **Split vault hook internally** (same file → folders, no behavior change)
4. **Consolidate lib/staking** into `src/staking/{orchestration,execution,diagnostics}`
5. **Form factor extraction** — shared deposit/withdraw hooks (behavior-preserving)
6. **Navbar / identity** — optional move inside provider OR keep bridge with hardened contract
7. **Remove deprecated vault bridges** — soak-gated
8. **Physical UI move** — optional last

---

## 12. File count summary

| Domain | TS/TSX files (approx.) |
| ------ | ----------------------: |
| `src/staking` | 52 |
| `src/lib/staking` | 36 (+ 3 md) |
| `src/lib/tron` | 4 |
| `src/lib/wallet` | 1 |
| `src/lib/runtimeTelemetry` | 2 |
| `src/lib/stakingProduct` | 4 |
| Staking hooks (primary) | 16 |
| `components/pages/staking` | 44 |
| Layout wallet | 2 |
| AppKit bootstrap | 3 |
| **Total in scope** | **~170** |

---

## 13. Related artifacts

- **Migration plan:** `docs/architecture-consolidation-plan.md`
- **Wallet migration tracker:** `docs/staking-runtime-wallet-migration-status.md`
- **Phase freeze:** `docs/staking-runtime-phase42-stabilization.md`

---

*End of Phase A census. No code changes.*
