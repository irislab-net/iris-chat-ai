# Staking production QA report — Phase P3

**Phase:** P3 — production QA & resilience (documentation + verification pass).  
**Environment note:** This report is generated from **code review** and project constraints. **Device/browser results** must be filled by human QA on staging/production builds.

**Verification (CI):** `pnpm typecheck` ✅ · `pnpm build` ✅ (run at report time).

**Architecture:** No topology, hook-order, or plane ownership changes in P3.

---

## 1. Runtime resilience — checklist & code alignment

| Scenario | Code alignment | Manual status |
|----------|----------------|---------------|
| Wallet disconnect/reconnect loops | Orchestrator stop on gates; notify on wallet change; Tron fetch gen invalidate | ☐ |
| Network flaps / wrong chain | Network glue + `numericChainIdRef`; toast dedupe (`stakingPassiveWrongNetworkDedupeId`) | ☐ |
| RPC latency / slow reads | Single-flight orchestrator; abort on invalidation | ☐ |
| Delayed confirmations | Tx provider + on-chain recovery (`stakingTxOnChainRecovery`) | ☐ |
| Background → foreground | Orchestrator visibility listeners; history 8s debounced resume | ☐ |
| bfcache `pageshow` | Same visibility semantic notify; history `persisted` path | ☐ |
| Wallet switch during pending tx | **High risk** — coordinator + modal; explicit manual case | ☐ |
| Slow chain hydration | `null` chain normalized without throw; orchestrator waits gates | ☐ |
| Stale balance continuity | `balanceSnapshotRef` / `lastDisplayBalancesRef`; commit gated | ☐ |
| Rapid history refresh clicks | Button disabled while `stakingHistoryLoading` | ☐ |
| Rapid runtime swaps | Transition sequence + commit deny — soak/torture in DEV | ☐ |
| MetaMask rejected request | Expect error surface / idle snapshot — per flow QA | ☐ |
| TronLink delayed injection | Passive reads gated on address codec / identity | ☐ |

---

## 2. Mobile QA — manual matrix

Run on **real devices** (simulators miss wallet deep links).

| Check | iOS Safari | Android Chrome | Notes |
|-------|----------|----------------|-------|
| Viewport resize / rotation | ☐ | ☐ | Forms + history search shell |
| Keyboard overlap (deposit/withdraw) | ☐ | ☐ | `visualViewport` not custom — rely on layout |
| Wallet deep-link return | ☐ | ☐ | After `wallet_switch` / connect |
| Modal reopen after background | ☐ | ☐ | `TransactionStatusSurface` |
| Scroll locking (dialog) | ☐ | ☐ | Radix dialog defaults |
| Focus restoration | ☐ | ☐ | Inputs + search |
| Animation smoothness / reduce-motion | ☐ | ☐ | `motion-reduce:` on spinners |

---

## 3. Async interruption — verified invariants (static)

| Risk | Verdict |
|------|---------|
| Stale orchestrator commits | **Mitigated** — `invalidationGen` + `canRuntimeOperationCommit`. |
| Duplicate orchestrator sessions | **Mitigated** — stop-before-start. |
| History superseded run applying state | **Mitigated** — `runId` vs `stakingHistoryFetchGenRef`. |
| Reconnect incorrect reset | **Partially** — continuity effects depend on identity keys; QA identity drift. |
| Reconciliation vs `loadMeta` race | **Mitigated** — frozen hook order (glue before loadMeta mount). |

---

## 4. UX resilience — spot checks

| Item | Expected behavior | QA |
|------|-------------------|-----|
| Loading continuity | Skeletons / blur PnL until `stakingPnlBasisReady` where applicable | ☐ |
| Button spam | CTAs disabled during `loading`; gas debounce on amounts | ☐ |
| Wrong-network messaging | Single-owner toast path for passive wrong network | ☐ |
| Toast duplication | `createStakingToastDedupeKey` / gas toast dedupe hook | ☐ |
| Retry | History manual refresh; balance via reconnect + orchestrator | ☐ |

---

## 5. Performance spot-check (evidence-based only)

| Area | Method | Threshold |
|------|--------|-----------|
| Tx render spikes | React Profiler, one deposit | Note max commit duration |
| Navbar | Profiler during reconnect | Note |
| History refresh | Performance panel during shallow fetch | Note payload size |
| Balance refresh | Same during `onCommit` | Note |
| Mobile layout thrash | Lighthouse / manual | No code change without trace |

**Rule:** No optimization in P3 without Profiler/Lighthouse evidence (per phase charter).

---

## 6. Findings classification

*To be updated after manual QA runs.*

| ID | Finding | Severity | Owner |
|----|---------|----------|-------|
| F-0 | `normalizeStakingVaultChainId(null)` throw — **fixed** prior to P3 doc (null guard) | ~~Critical~~ Resolved | runtime |
| — | *(add rows after device passes)* | | |

**Severity legend**

- **Critical:** Data loss, wrong chain tx, or crash loop.
- **Should-fix:** Incorrect balances, stuck loading, duplicate toasts with user impact.
- **Cosmetic:** Copy, minor animation timing.
- **Intentional:** Documented UX (e.g. ROI hidden for residual dust).
- **Architecture-safe future:** Profiler-proven memo/virtualization (not P3).

---

## 7. Sign-off

| Role | Date | Notes |
|------|------|-------|
| Engineering | | typecheck/build |
| QA (device) | | Fill §1–2 checkboxes |

---

*Phase P3 — resilience documentation; pair with `docs/staking-runtime-edgecases.md`.*
