# Phase 45 — Unified staking product UX

This phase adds a **thin product layer** (types + catalog + user messages) and **product-facing copy** in existing UI — without changing runtime architecture, transitions, providers, telemetry, or orchestrators.

## 1. Unified staking asset model (implemented)

**Code:** `src/lib/stakingProduct/`

| Module | Role |
| --- | --- |
| `stakingProductModel.ts` | `StakingProductAssetEntry`, `StakingProductRuntimeSurface` — logical asset + per-network surfaces (labels only). |
| `buildStakingProductCatalog.ts` | `buildStakingProductCatalog()` — merges registry deployments under one stablecoin symbol (`STAKING_STABLECOIN_LABEL`). |

**UX principle:** the UI reasons about **asset**, **network label**, **balances**, **fees**, and **rewards** — not `runtimeKey` / `deploymentId` / coordinator internals in default copy.

## 2. Unified asset selector UX (incremental)

- **`StakingAssetSelectSubtree`** accepts optional **`poolNetworkLabel`** (defaults to legacy `STAKING_NETWORK_LABEL`).
- **Deposit / withdraw** forms pass **`activeRuntimeSelection.deployment.labels.network`** so the row reads as one product pool with a clear network hint.
- A **multi-network picker** (only when multiple executable pools exist) can consume `buildStakingProductCatalog()` later without new runtime types.

## 3. Unified balance + history surfaces (incremental)

| Surface | Change |
| --- | --- |
| **Balance** (`StakingAppBalance`) | Subtitle **`{STABLE} on {networkLabel}`**; wrong-network CTA shows **“Wrong network”** + aria text in plain language. |
| **Activity** (`StakingAppTransactionHistory`) | Title **“Activity”**; tabs **“Staking moves”** / **“Referral rewards”**; friendlier empty states. |

**Merge strategy (full vision):** keep one card stack with tabs or segments; optional filters (network / family) keyed off `StakingProductRuntimeSurface.routingKey` **only inside filter UI**, not primary headings. Default tab = all staking moves.

## 4. Runtime-hidden UX safeguards (implemented)

- **`RUNTIME_SWAP_POLICY_DENIAL_MESSAGES`** in `runtimeSwapPolicy.ts` rewritten in **product language** (no “quiescent”, “sequence”, “refresh paused” jargon).
- **`stakingProductRuntimeSwitchBlockedMessage`** in `stakingProductUserMessages.ts` maps non-policy swap failures (e.g. rollout disabled) to safe strings.
- **`RuntimePickerDevPanel`** uses the unified message helper for swap outcomes.

## 5. Wallet / network UX polish (partial)

- Wrong-network balance CTA clarified (label + `aria-label`).
- Further polish (WalletConnect / TronLink / MetaMask mobile): track in QA using the checklist below — no connector redesign in this phase.

## 6. Product consistency checklist (manual)

- [ ] Loading skeletons: balance, forms, activity table.
- [ ] Modal copy: `TransactionStatusSurface` / toasts — no internal tokens.
- [ ] Primary CTA disabled states: wrong network, terms, gas, modal open.
- [ ] Fee rows: same pattern deposit vs withdraw; Tron passive paths show honest limits.
- [ ] Reward / PnL formatting: locale + stablecoin decimals.
- [ ] Transaction labels: “Staking moves” column headers still clear vs explorer.

## 7. Deliverables (this document)

| Deliverable | Where |
| --- | --- |
| **Unified UX model** | §1–3 |
| **Asset abstraction structure** | `stakingProductModel.ts` + `buildStakingProductCatalog.ts` |
| **History/balance merge strategy** | §3 |
| **Runtime-hidden copy audit** | §4 + policy table in code |
| **Mobile wallet UX findings** | To be filled after device matrix (see Phase 44 doc) |
| **Consistency checklist** | §6 |
| **“Feels like one product?”** | §8 |

## 8. “Feels like one product?” conclusion

**Directionally yes for copy and primary surfaces** (balance subtitle, activity naming, swap denial language). **Not complete** until multi-network selection and combined “position + rewards” layout ship behind the same product catalog. The invariant is satisfied when **users never need** deployment/runtime vocabulary for happy-path staking.

## 9. Critical invariant

Users should experience **one staking product** — not a visible multi-runtime infrastructure system. Internal keys (`routingKey`) exist only for **filters and engineering**, not default user-facing strings.
