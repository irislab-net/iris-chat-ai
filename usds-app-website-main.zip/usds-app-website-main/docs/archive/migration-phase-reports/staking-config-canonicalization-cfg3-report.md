# Staking config canonicalization — CFG3 report

**Phase:** CFG3 — consumption canonicalization (controlled migration; **no env key deletion**).

**Goal:** Staking code reads deployment and tuning configuration through `@/staking/config/*` (`stakingEthConfig`, `stakingTronConfig`, `stakingUiConfig`, `stakingFeatureFlags`, `stakingConfigRuntime`) instead of scattered `@/config/env` imports, duplicated literals where a canonical constant exists, and ad-hoc `import.meta.env` reads (except `DEV` gates and the intentional ETH/USD helpers).

**Verification:** `pnpm typecheck` and `pnpm build` succeeded after this change set.

---

## Consumer migration table

| Consumer | Old source | New canonical source | Runtime risk | Deleted? |
| -------- | ---------- | -------------------- | ------------ | -------- |
| `src/staking/core/buildExplicitEnvDeploymentRows.ts` | `@/config/env` (explicit ETH/TRon deployment env block) | `@/staking/config` (re-exports via `stakingConfigRuntime`) | **Low** — same `env.ts` symbols, different import path | No |
| `src/staking/core/getStakingDeploymentRegistry.ts` | `@/config/env` (legacy staking row env block) | `@/staking/config` | **Low** | No |
| `src/staking/reads/useStakingVaultTokenReads.ts` | `@/config/env` | `@/staking/config` | **Low** | No |
| `src/staking/history/tron/tronTransactionHistory.ts` | `@/config/env` | `@/staking/config` | **Low** — Grid API URL still env-backed | No |
| `src/staking/tx/stakingTxSessionPersistence.ts` | `@/config/env` | `@/staking/config` | **Low** | No |
| `src/staking/runtime/network/useStakingVaultNetworkGlue.ts` | `@/config/env` | `@/staking/config` | **Low** | No |
| `src/staking/execution/stakingGasEstimator.ts` | `@/config/env` | `@/staking/config` | **Low** | No |
| `src/staking/refresh/useStakingVaultBalanceRefresh.ts` | `@/config/env`; literal `"tron"` in telemetry payload | `@/staking/config` (`STAKING_TRON_TOKEN_ADDRESS`, `STAKING_TRON_CHAIN_FAMILY`) | **Low** — label value unchanged (`"tron"`) | No |
| `src/staking/core/runtimeTransitionTelemetry.ts` | Local `VITE_RUNTIME_SWAP_STRESS` via `import.meta.env` | `isRuntimeSwapStressHarnessEnabled` from `@/staking/config` (`stakingFeatureFlags` → `env.ts`) | **Low** — aligns with `readBool` + `optionalEnv` in `env.ts` (same truth set as prior inline parser for normal env values) | No (removed inline helper only) |
| `src/components/pages/staking/StakingTermsConsentProvider.tsx` | `@/config/env` | `@/staking/config` (`readViteStakingTermsUrl`) | **Low** | No |
| `src/components/pages/staking/TransactionStatusProvider.tsx` | `@/config/env` | `@/staking/config` | **Low** | No |
| `src/components/pages/staking/StakingAppDepositForm.tsx` | `@/config/env` (`DEBUG_LOGS`) | `@/staking/config` | **Low** | No |
| `src/components/pages/staking/StakingAppWithdrawForm.tsx` | `@/config/env` | `@/staking/config` | **Low** | No |
| `src/components/pages/staking/StakingApp.tsx` | `@/config/env` (`isRuntimePickerDevPanelVisible`) | `@/staking/config` | **Low** | No |
| `src/components/pages/staking/AppKitTronIdentityDiagnosticsMount.tsx` | `@/config/env` | `@/staking/config` | **Low** | No |
| `src/hooks/useStakingCtaState.ts` | `@/config/env` | `@/staking/config` | **Low** | No |
| `src/hooks/useStakingGasEstimate.ts` | `@/config/env` | `@/staking/config` | **Low** | No |
| `src/hooks/useAppKitTronIdentityDiagnostics.ts` | `@/config/env` | `@/staking/config` | **Low** | No |

---

## Remaining raw `import.meta.env` usage under `src/staking/**`

| Location | Kind | Notes |
| -------- | ---- | ----- |
| Many modules | `import.meta.env.DEV` | Intentional compile-time / dev guards; **not** migrated (no Vite `DEV` indirection in canonical config). |
| `src/staking/config/stakingEthConfig.ts` | `VITE_ETH_USD_CACHE_TTL_MS`, `VITE_ETH_USD_FEED_STALE_AFTER_SEC` | Canonical ETH/USD tuning surface; logic preserved from pre-CFG2 behavior. |
| Comments / docs | Mention of `import.meta.env` | No runtime read. |

**Grep (`import.meta.env.VITE_`) in `src/staking/**`:** only `stakingEthConfig.ts` (above).

---

## Remaining dangerous / deployment-sensitive env-backed values

These remain **defined in** `src/config/env.ts` and are re-exported through `stakingConfigRuntime` or `stakingFeatureFlags` where applicable. CFG3 does **not** remove keys or inline values.

- **RPC / WS:** `VITE_STAKING_RPC_URL`, `VITE_STAKING_WS_URL`, `VITE_STAKING_ETH_*` HTTP/WS, `VITE_STAKING_TRON_RPC_URL`, etc.
- **Contracts:** vault addresses, token addresses, optional overrides.
- **Explorers / labels:** base URLs and display labels for legacy and explicit rows.
- **History / APIs:** `STAKING_TRON_TX_HISTORY_GRID_API_URL`, terms URL reader, Etherscan-related helpers not expanded in this pass.
- **Wallet / provider:** Reown project id and metadata remain in global `env.ts`; staking pages use feature flags re-exported from `@/staking/config`.
- **Stress / dev flags:** runtime torture, chaos, swap stress harness, picker dev — still read in `env.ts`, exposed via `stakingFeatureFlags`.

---

## Deleted aliases / wrappers

**None** in CFG3. No staking-only env helper files were removed; grep-based dead-code deletion was out of scope for this controlled pass.

---

## Blast radius

- **Staking package:** deployment registry construction, explicit env deployment rows, Tron transaction history URL, vault token reads, session persistence chain id, network glue, gas high-fee threshold, balance refresh Tron token address, runtime DEV observability for swap stress.
- **Staking UI / hooks:** terms URL, transaction status provider chain id and torture/chaos flags, debug logs on deposit/withdraw, runtime picker dev panel visibility, AppKit Tron diagnostics gate, CTA and gas estimate debug logging.

No Vite, Cloudflare, CI, or non-staking routes were modified.

---

## Rollback strategy

1. Revert the CFG3 commit(s) or restore prior imports: swap `@/staking/config` back to `@/config/env` for the touched files and restore `runtimeTransitionTelemetry`’s local `VITE_RUNTIME_SWAP_STRESS` read if needed.
2. Remove additions from `stakingConfigRuntime.ts` if rolling back that file alone.
3. Re-run `pnpm typecheck` / `pnpm build`.

---

## Env reduction estimate after CFG4

CFG3 **does not** reduce env surface area. After CFG4 (explicit env deprecation / consolidation), a reasonable target is:

- **Duplicative staking-prefixed keys** that exist only for parallel “explicit row” vs “legacy row” legacy support may be candidates **if** product confirms a single schema.
- **Feature flags** already centralized in `env.ts`; CFG4 might collapse naming or remove superseded toggles once telemetry proves unused.
- Order-of-magnitude: **~0 keys removed in CFG3**; CFG4 might retire **a small handful to a dozen** keys only after ownership review and production bake time — not estimated precisely here.

---

## Canonical surface (reference)

- `src/staking/config/stakingConfigRuntime.ts` — env-backed staking deployment getters + `getExpectedChainId`, `readViteStakingHighNetworkFeeWei`, `readViteStakingTermsUrl`, plus non-secret metadata from ETH/Tron/UI submodules.
- `src/staking/config/stakingFeatureFlags.ts` — re-exports runtime/feature toggles from `env.ts`.
- `src/staking/config/stakingEthConfig.ts` — chain family, CAIP prefix, legacy native currency metadata, ETH/USD cache TTL helpers.
- `src/staking/config/stakingTronConfig.ts` — Tron chain family, explicit-row CAIP fallback.
- `src/staking/config/stakingUiConfig.ts` — default stablecoin label.
- `src/staking/config/index.ts` — barrel; consumers should import from `@/staking/config` rather than adding new wrapper modules.
