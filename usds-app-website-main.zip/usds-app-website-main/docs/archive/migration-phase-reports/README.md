# Staking historical archive

Historical reports, phase notes, audits, and migration records live here. They preserve operational memory but are **not** the source of truth for current runtime behavior.

## Active canonical docs

| Topic | Canonical doc |
| --- | --- |
| Architecture boundaries | `../../staking-domain-boundaries.md` |
| Runtime ownership and tx continuity | `../../staking-runtime-contracts.md` |
| Runtime edge cases and lifecycle behavior | `../../staking-runtime-edgecases.md` |
| Operational maintenance rules | `../../staking-maintenance-rules.md` |
| Deploy/runtime observability | `../../deploy-runtime-assets.md` |
| Sentry/runtime telemetry taxonomy | `../../staking-sentry-event-taxonomy.md` |

Compatibility anchors retained at `docs/` root because code comments or env docs reference them:

- `../../staking-runtime-phase42-stabilization.md`
- `../../staking-runtime-phase43-telemetry.md`
- `../../staking-runtime-phase44-operational-rollout.md`

## Archive chronology

| Era / phase | Files |
| --- | --- |
| Architecture census and planning | `architecture-consolidation-census.md`, `architecture-consolidation-plan.md`, `phase-b-boundary-report.md` |
| Vault and refresh topology | `vault-anatomy-report.md`, `vault-refresh-topology-report.md`, `vault-balance-refresh-topology-report.md`, `staking-network-topology.md` |
| Bridge, Tron, and shim retirement | `bridge-removal-readiness-report.md`, `g4a-shim-deletion-report.md`, `g4b-tron-retirement-report.md`, `g4c-bridge-retirement-report.md`, `g4d-architecture-freeze-report.md` |
| Canonicalization | `staking-canonicalization-report.md`, `staking-import-canonicalization-report.md`, `staking-final-canonicalization-report.md`, `staking-final-architecture.md` |
| Config and env consolidation | `staking-config-canonicalization-report.md`, `staking-config-canonicalization-cfg2-report.md`, `staking-config-canonicalization-cfg3-report.md`, `staking-config-canonicalization-cfg4-report.md`, `staking-config-architecture-refinement.md`, `staking-env-reduction-plan.md` |
| Runtime/product rollout history | `staking-runtime-wallet-migration-status.md`, `staking-runtime-phase45-unified-product-ux.md`, `staking-runtime-phase46-multi-vault-runtime.md`, `staking-network-rollout-semantics.md`, `staking-hard-disable-plan.md` |
| QA, UX, performance, and resilience audits | `staking-production-qa-report.md`, `staking-performance-audit.md`, `staking-ux-consistency-report.md`, `staking-form-structure-audit.md`, `staking-balance-rolling-ui.md`, `staking-sentry-observability-audit.md` |
| Cleanup and final-state snapshots | `staking-cleanup-report.md`, `staking-dev-cleanup-candidates.md`, `staking-destructive-cleanup-report.md`, `staking-stabilization-report.md`, `staking-final-state-report.md` |

## Archive rules

- Preserve historical reports unless they are fully duplicated and the duplicate is already represented here.
- Do not use archived reports to justify runtime changes without checking active canonical docs first.
- If an archived report contains unique QA evidence or incident context, keep it even when its plan is superseded.
- When new phase reports are created, add them to this chronology and link the active canonical replacement.
