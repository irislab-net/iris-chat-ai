# G4b Tron retirement report

Relocated Tron implementations from `src/lib/tron/` into canonical `@/staking/*` namespaces and removed all Tron compatibility bridges/shims. **No runtime behavior changes. No public vault bridge removal.**

Verification: `pnpm typecheck` ✅ · `pnpm build` ✅

---

## 1. Summary

| Metric | Value |
|--------|------:|
| **Implementations moved** | **2** |
| **Files deleted** | **5** |
| **`src/lib/tron/` remaining** | **0** (directory removed) |
| **Remaining Tron re-export shims** | **0** |
| **Surviving non-Tron shims** | **2** |
| **Public bridge surfaces (unchanged)** | **2** |

---

## 2. Moved implementations (2)

| From (deleted) | To (canonical owner) |
|----------------|----------------------|
| `src/lib/tron/tronWalletIdentity.ts` | `src/staking/identity/tron/tronWalletIdentity.ts` |
| `src/lib/tron/tronTransactionHistory.ts` | `src/staking/history/tron/tronTransactionHistory.ts` |

### Import path updates

| File | Change |
|------|--------|
| `src/staking/history/index.ts` | Export from `@/staking/history/tron/tronTransactionHistory` |
| `src/staking/history/useStakingVaultHistory.ts` | Import from `@/staking/history/tron/tronTransactionHistory` |

All other consumers already targeted canonical paths:

- `@/staking/identity/tron/tronWalletIdentity` — runtime planes, openUnifiedWallet, diagnostics
- `@/staking/identity/tron/resolveUnifiedTronIdentity` — identity resolution (was never in `lib/tron` impl)
- `@/staking/execution/tronPassiveReads` — passive balance/meta reads (always canonical)

---

## 3. Deleted files (5)

### `src/lib/tron/` (entire directory — 4 files)

1. `tronWalletIdentity.ts` (implementation → moved)
2. `tronTransactionHistory.ts` (implementation → moved)
3. `tronPassiveReads.ts` (re-export shim → redundant; canonical `@/staking/execution/tronPassiveReads`)
4. `resolveUnifiedTronIdentity.ts` (re-export shim → redundant; canonical `@/staking/identity/tron/resolveUnifiedTronIdentity`)

### Temporary bridge (1 file)

5. `src/staking/history/tronTransactionHistory.ts` (re-export wrapper at history root)

---

## 4. Runtime ownership confirmation

Tron runtime is fully owned under `@/staking/*`:

```
src/staking/
├── identity/tron/
│   ├── tronWalletIdentity.ts      # Passive TronLink identity, polling, network switch
│   └── resolveUnifiedTronIdentity.ts
├── history/tron/
│   └── tronTransactionHistory.ts  # TronGrid TRC-20 activity history
└── execution/
    └── tronPassiveReads.ts        # Passive TRC-20 balance/meta reads
```

**Preserved behavior (unchanged code paths):**

- Passive Tron runtime + session cache
- Visibility / focus / `pageshow` polling (`subscribePassiveTronWalletIdentity`)
- Tron history loading (`loadTronStakingTransactionHistoryRows`)
- Runtime swap EVM ↔ Tron (orchestration + identity)
- Refresh orchestration + wrong-network handling
- AppKit Tron integration + unified identity resolution
- EVM paths unaffected (separate execution/history modules)

---

## 5. Grep evidence

### `@/lib/tron/` and `src/lib/tron` in `src/**/*.{ts,tsx}`

**0 matches**

### Runtime consumers of legacy Tron paths

**0** — no `from "@/lib/tron/*"` imports remain.

---

## 6. Remaining compatibility surfaces

### Public vault bridge (`useStakingVault()` — G4c)

| Field | Replacement |
|-------|-------------|
| `address` | `executionAddress` |
| `isConnected` | `executionConnected` / `runtimeWallet` |
| `chainId` | `executionChainId` |
| `activeRuntimeSelection` | `useActiveRuntimeSelection()` |

DEV: `withDeprecatedVaultBridgeDevInstrumentation`

### Runtime planes deprecated aliases

`useStakingVaultRuntimePlanes` still exports deprecated `isConnected`, `address`, `chainId` with JSDoc.

### Surviving shims (non-Tron, 2)

| File | Notes |
|------|-------|
| `src/staking/core/runtimeCoreLayerBoundaryDev.ts` | Diagnostics re-export → `@/staking/diagnostics` |
| `src/staking/vault/composer/useStakingVaultEvmNetworkGlue.ts` | Delegates to `@/staking/runtime/network` (G4d) |

---

## 7. G4c blast radius update

After G4b, **no import-path blockers** remain for G4c. Remaining work is **API surface** only:

| Risk | Level |
|------|-------|
| In-repo staking UI | **Low** — already on canonical fields |
| External `useStakingVault()` consumers of deprecated fields | **High** |
| Tron-specific flows | **None from this phase** — behavior unchanged |

Recommended G4c steps:

1. Remove deprecated fields from `assembleStakingVaultPublicValue`
2. Update `stakingVaultPublicTopology.ts` / types
3. Remove DEV bridge instrumentation
4. Release note for integrators

---

## 8. Blockers before G4c

| Blocker | Status after G4b |
|---------|------------------|
| `lib/tron` implementation ownership | **Resolved** |
| Tron bridge files | **Resolved** |
| `lib/staking` shims | **Resolved** (G4a) |
| Public vault bridge fields | **Still present** — G4c scope |
| `useStakingVaultEvmNetworkGlue` composer shim | **Still present** — G4d optional |

**Exact blockers before destructive G4c:** public vault bridge removal only (+ optional external compatibility audit).

---

## 9. Manual QA checklist

1. Tron passive runtime  
2. Tron history  
3. Runtime swap EVM ↔ Tron  
4. Navbar wallet  
5. Wrong network  
6. Refresh polling  
7. Soak monitor  
8. Tx modal unaffected  
9. EVM runtime unaffected  

---

## 10. Next recommended phase

**G4c — public vault bridge field removal** (`address`, `isConnected`, `chainId`, `activeRuntimeSelection`).

Optional follow-up: **G4d** — delete `useStakingVaultEvmNetworkGlue` after refresh plane uses `@/staking/runtime/network` directly.

---

*Generated: Phase G4b — Tron canonical relocation complete; `lib/tron` retired.*
