# Staking configuration canonicalization — Phase CFG1 audit

**Date:** 2026-05-16  
**Scope:** Analysis only. **No code, env, or import changes.**  
**Inputs read:** `.env.development`, `.env.production`, `src/config/env.ts`, `src/config/envRequiredKeys.ts`, `src/vite-env.d.ts`, plus `grep` / TypeScript usage tracing.

**Security:** This document names **keys only**. It does **not** reproduce secret values (API keys, RPC URLs with embedded keys, etc.) from your env files.

---

## 1. Executive summary

- **Legacy vs explicit ETH/TRON:** Production config sets **both** `VITE_STAKING_*` (legacy-primary row) and **`VITE_STAKING_ETH_*` / `VITE_STAKING_TRON_*`** (Phase 46 explicit sibling rows). Runtime merges rows via `getStakingDeploymentRegistry.ts` + `buildExplicitEnvDeploymentRows.ts`; duplicates can be **skipped by runtime key**.
- **High duplication in `.env`:** Many **`VITE_STAKING_ETH_*`** fields **mirror** **`VITE_STAKING_*`** (comments in `.env` already say legacy must match ETH vault). Only the **legacy** keys are **required** for production build (`envRequiredKeys.ts`).
- **Documented-but-unread env keys:** A large set of per-chain keys in `.env` are **not** referenced in `src/` (no `env.ts` reader, no `import.meta.env`, not in `vite-env.d.ts`). They are **operational documentation / future hooks** today, not app configuration.
- **Bypass of canonical `env.ts`:** `src/lib/affiliateFirestoreStats.ts` reads **`import.meta.env.VITE_STAKING_VAULT_ADDRESS`** directly for the Firestore collection segment, instead of `STAKING_VAULT_ADDRESS` from `env.ts` — an **alias / coupling** risk if bridges move.
- **Typed-but-unused exports:** `NATIVE_USD_RATE` and `STAKING_HIGH_NETWORK_FEE_WEI` are parsed in `env.ts` but have **no consumers** in `src/` (vestigial / dead wiring).
- **Recommended future homes:** `src/staking/config/*.ts` as typed facades that **read** `import.meta.env` once (or accept injection for tests), preserving CFG1+ compatibility layers until env keys are retired in a later phase.

---

## 2. Methodology

| Step | Action |
|------|--------|
| Inventory | Enumerate keys from `.env.development` and `.env.production` (active and commented). |
| Augment | Add keys declared in `vite-env.d.ts` / read in `env.ts` that are missing from committed `.env`. |
| Usage | `grep` for `VITE_<KEY>` and `import.meta.env`; trace re-exports via `@/config/env` and `stakingVaultConfig`. |
| Classification | Assign one primary category (§0 glossary) + notes for duplicates / danger. |
| Verification | `pnpm typecheck` **pass**; `vite build --mode production` **pass** (CFG1 gate). |

---

## 3. Category glossary (CFG1)

| # | Category | Meaning |
|---|----------|---------|
| 1 | **Runtime invariant** | Must match compiled bundle expectations for correctness (e.g. chain id shape); usually still **supplied** by deployment. |
| 2 | **Deployment-specific** | Differs per environment (dev/stage/prod); must remain overrideable. |
| 3 | **Infra-specific** | Third-party project IDs, Firebase, indexer bases — secrets or tenant boundaries. |
| 4 | **Product/business config** | Legal URLs, copy-adjacent URLs, business rules surfaced to users. |
| 5 | **Static UI metadata** | Labels, symbols, decimals **when not authoritative** for chain execution (display hints). |
| 6 | **Duplicate/alias** | Same semantic as another key or another config path (legacy vs `ETH_*`, or direct `import.meta.env` vs `env.ts`). |
| 7 | **Dead/unused** | Set in `.env` but **no** `src` reader found in CFG1 audit (may still be human ops docs). |
| 8 | **Transitional compatibility** | Explicit bridge period (legacy `VITE_STAKING_*` alongside Phase 46 rows). |
| 9 | **Feature flag** | Toggles dev tooling, telemetry stages, rollout layers. |
| 10 | **Dangerous-to-inline** | Wrong value changes routing, execution, history, Firebase isolation, or wallet surface — high blast radius. |

---

## 4. Detected problems

### 4.1 ETH / TRon duplication (legacy vs explicit)

- **Legacy row:** `VITE_STAKING_CHAIN_ID`, `VITE_STAKING_RPC_URL`, `VITE_STAKING_WS_URL`, `VITE_STAKING_VAULT_ADDRESS`, explorer + network labels, `VITE_STAKING_TOKEN_ADDRESS`, `VITE_STAKING_TX_HISTORY_ORIGIN`.
- **Explicit ETH block:** `VITE_STAKING_ETH_*` consumed only when **complete** per `buildExplicitEnvDeploymentRows.ts` (vault, chain id, RPC, explorer base/label, network label).
- **Explicit Tron block:** `VITE_STAKING_TRON_*` (partial set + `VITE_STAKING_TRON_TOKEN_ADDRESS` elsewhere) — Tron explicit row uses **`ws: null`** even if `VITE_STAKING_TRON_WS_URL` is set in `.env` (env var currently **ignored** for Tron WS).

### 4.2 Alias chains

- **Legacy `VITE_STAKING_*` ↔ `VITE_STAKING_ETH_*`:** `.env` comments require manual parity (vault address, chain id, RPC). Drift risks **duplicate or skipped** registry rows.
- **`STAKING_TOKEN_ADDRESS`** (optional ERC-20 for legacy row) vs on-chain **`vault.asset()`** — comments in `.env` say executable token is vault-driven; env token is override/hint.
- **Affiliate Firestore collection key:** `VITE_STAKING_VAULT_ADDRESS` via **`import.meta.env`** in `affiliateFirestoreStats.ts` vs `STAKING_VAULT_ADDRESS` from `env.ts` — **should converge** under `src/staking/config` in a later phase to one source of truth.

### 4.3 Static metadata in env (candidates to move to typed constants)

Examples **present in `.env` but not read by code** today: `VITE_STAKING_ETH_TOKEN_SYMBOL`, `VITE_STAKING_ETH_TOKEN_DECIMALS`, `VITE_STAKING_ETH_PRODUCT_LABEL`, Tron counterparts, `VITE_STAKING_ETH_ENABLED` / `VITE_STAKING_TRON_ENABLED`, `VITE_STAKING_*_CHAIN_FAMILY`. These are **documentation or future product hints**, not runtime sources in CFG1.

**Also:** `STAKING_STABLECOIN_LABEL = "USDC"` is **hardcoded** in `stakingVaultConfig.ts` while `.env` hints may say USDT — a **product/metadata** consistency issue to resolve in a canonical layer (not in CFG1).

### 4.4 Dead env keys (verified by grep / env.ts)

Keys **in `.env` files** with **no** `src` reference to that `VITE_*` name (and not passed through `env.ts`):

`VITE_STAKING_ETH_ENABLED`, `VITE_STAKING_ETH_CHAIN_FAMILY`, `VITE_STAKING_ETH_TOKEN_SYMBOL`, `VITE_STAKING_ETH_TOKEN_DECIMALS`, `VITE_STAKING_ETH_PRODUCT_LABEL`, `VITE_STAKING_ETH_TX_HISTORY_ORIGIN`, `VITE_STAKING_ETH_TOKEN_ADDRESS` (present in production `.env`; **not** in `vite-env.d.ts` / `env.ts`),

`VITE_STAKING_TRON_ENABLED`, `VITE_STAKING_TRON_CHAIN_FAMILY`, `VITE_STAKING_TRON_CHAIN_ID`, `VITE_STAKING_TRON_TOKEN_SYMBOL`, `VITE_STAKING_TRON_TOKEN_DECIMALS`, `VITE_STAKING_TRON_PRODUCT_LABEL`, `VITE_STAKING_TRON_TX_HISTORY_ORIGIN`, `VITE_STAKING_TRON_WS_URL`.

**Vestigial (parsed in `env.ts`, zero consumers in `src/`):** `VITE_NATIVE_USD_RATE`, `VITE_STAKING_HIGH_NETWORK_FEE_WEI`.

**Optional never used in `.env` samples:** `VITE_STAKING_PROFIT_MANAGER_STATUS_URL` (optional in `env.ts`; no callers of `stakingProfitManagerStatusUrl()`).

### 4.5 Should become typed modules under `src/staking/config/`

**Candidates for first-class typed exports (after CFG2):**

- Legacy-primary staking row (today: `stakingVaultConfig` + `env.ts` constants).
- Explicit ETH / Tron env blocks (today: scattered `STAKING_ETH_*` / `STAKING_TRON_*` exports from `env.ts`).
- Feature-flag and telemetry bundle (`getRuntimeSwitchRolloutLayer`, telemetry stage/rate).
- UI-adjacent metadata currently split between env and hardcoded constants (e.g. stablecoin label).

---

## 5. Master registry — every environment key

**Legend — Keep env?**

- **Y** — Must remain overridable per deployment for the foreseeable future.
- **Y (opt)** — Optional; product may omit.
- **Bridge** — Keep during compatibility window; eligible for deprecation after migration.
- **N (future)** — Safe to drop **only after** a coded migration removes last reader (not CFG1).

**Risk:** Low / Med / High (blast radius if wrong).

| Key | Current usage | Used by | Category | Canonical home (future) | Keep env? | Risk |
|-----|----------------|---------|----------|-------------------------|-----------|------|
| `VITE_REOWN_PROJECT_ID` | WalletConnect / AppKit project id | `env.ts` → `reownKit.ts`, wallet flows | 3 | `stakingWalletProviders.ts` or `stakingConfig.ts` facade | Y | High |
| `VITE_APP_METADATA_URL` | Wallet metadata | `env.ts`, Reown init | 4 / 5 | `stakingUiConfig.ts` (URLs shown to wallet) | Y | Med |
| `VITE_APP_METADATA_NAME` | Wallet metadata | `env.ts` | 5 | `stakingUiConfig.ts` | Y | Low |
| `VITE_APP_METADATA_DESCRIPTION` | Wallet metadata | `env.ts` | 5 | `stakingUiConfig.ts` | Y | Low |
| `VITE_APP_METADATA_ICON_URL` | Wallet metadata | `env.ts` | 5 | `stakingUiConfig.ts` | Y | Low |
| `VITE_STAKING_ETH_ENABLED` | Not read in `src` | — | 7 / 9 | `stakingFeatureFlags.ts` **if** product needs it | N (future) | Low |
| `VITE_STAKING_ETH_CHAIN_FAMILY` | Not read | — | 5 / 7 | `stakingEthConfig.ts` constant (`"evm"`) | N (future) | Low |
| `VITE_STAKING_ETH_CHAIN_ID` | Explicit ETH row | `env.ts` → `buildExplicitEnvDeploymentRows.ts` | 2 | `stakingEthConfig.ts` | Y | High |
| `VITE_STAKING_ETH_NETWORK_LABEL` | Explicit ETH row | `env.ts` → explicit ETH deployment | 5 | `stakingEthConfig.ts` | Y (opt) | Med |
| `VITE_STAKING_ETH_EXPLORER_LABEL` | Explicit ETH row | `env.ts` → explicit ETH deployment | 5 | `stakingEthConfig.ts` | Y (opt) | Med |
| `VITE_STAKING_ETH_EXPLORER_BASE_URL` | Explicit ETH row | `env.ts` → explicit ETH deployment | 2 | `stakingEthConfig.ts` | Y | High |
| `VITE_STAKING_ETH_VAULT_ADDRESS` | Explicit ETH row | `env.ts` → explicit ETH deployment | 2 | `stakingEthConfig.ts` | Y (opt) | High |
| `VITE_STAKING_ETH_RPC_URL` | Explicit ETH row | `env.ts` → explicit ETH deployment | 2 | `stakingEthConfig.ts` | Y (opt) | High |
| `VITE_STAKING_ETH_WS_URL` | Explicit ETH row WS | `env.ts` → explicit ETH deployment | 2 | `stakingEthConfig.ts` | Y (opt) | Med |
| `VITE_STAKING_ETH_CAIP2` | Optional CAIP override | `env.ts` → explicit ETH row | 2 | `stakingEthConfig.ts` | Y (opt) | High |
| `VITE_STAKING_ETH_TOKEN_SYMBOL` | Not read | — | 5 / 7 | `stakingEthConfig.ts` typed default | N (future) | Low |
| `VITE_STAKING_ETH_TOKEN_DECIMALS` | Not read | — | 5 / 7 | `stakingEthConfig.ts` typed default | N (future) | Low |
| `VITE_STAKING_ETH_PRODUCT_LABEL` | Not read | — | 5 / 7 | `stakingUiConfig.ts` | N (future) | Low |
| `VITE_STAKING_ETH_TX_HISTORY_ORIGIN` | Not read (only legacy origin wired) | — | 7 | Align with indexer config in `stakingConfig.ts` or drop | N (future) | Med |
| `VITE_STAKING_ETH_TOKEN_ADDRESS` | Not in `env.ts` / `vite-env` | — | 7 | Use `VITE_STAKING_TOKEN_ADDRESS` or registry | N (future) | Med |
| `VITE_STAKING_TRON_ENABLED` | Not read | — | 7 / 9 | `stakingFeatureFlags.ts` | N (future) | Low |
| `VITE_STAKING_TRON_CHAIN_FAMILY` | Not read | — | 5 / 7 | Constant in `stakingTronConfig.ts` | N (future) | Low |
| `VITE_STAKING_TRON_CHAIN_ID` | Not read (CAIP2 used) | — | 7 | Derive from CAIP2 if ever needed | N (future) | Low |
| `VITE_STAKING_TRON_CAIP2` | Tron row CAIP | `env.ts` → explicit Tron deployment | 2 | `stakingTronConfig.ts` | Y (opt) | High |
| `VITE_STAKING_TRON_NETWORK_LABEL` | Tron row | `env.ts` → explicit Tron deployment | 5 | `stakingTronConfig.ts` | Y (opt) | Med |
| `VITE_STAKING_TRON_EXPLORER_LABEL` | Tron row | `env.ts` → explicit Tron deployment | 5 | `stakingTronConfig.ts` | Y (opt) | Med |
| `VITE_STAKING_TRON_EXPLORER_BASE_URL` | Tron row | `env.ts` → explicit Tron deployment | 2 | `stakingTronConfig.ts` | Y (opt) | High |
| `VITE_STAKING_TRON_VAULT_ADDRESS` | Tron row | `env.ts` → explicit Tron deployment | 2 | `stakingTronConfig.ts` | Y (opt) | High |
| `VITE_STAKING_TRON_RPC_URL` | Tron row | `env.ts` → explicit Tron deployment | 2 | `stakingTronConfig.ts` | Y (opt) | High |
| `VITE_STAKING_TRON_WS_URL` | Set in `.env` | **Not consumed** (Tron explicit `ws: null`) | 7 | `stakingTronConfig.ts` if WS added | N (future) | Low |
| `VITE_STAKING_TRON_TOKEN_SYMBOL` | Not read | — | 5 / 7 | From `loadTronTokenMeta` / constants | N (future) | Low |
| `VITE_STAKING_TRON_TOKEN_DECIMALS` | Not read | — | 5 / 7 | From chain reads | N (future) | Low |
| `VITE_STAKING_TRON_PRODUCT_LABEL` | Not read | — | 5 / 7 | `stakingUiConfig.ts` | N (future) | Low |
| `VITE_STAKING_TRON_TX_HISTORY_ORIGIN` | Not read | — | 7 | Same as legacy history origin strategy | N (future) | Med |
| `VITE_STAKING_TRON_TOKEN_ADDRESS` | Passive Tron reads | `env.ts` → `useStakingVaultTokenReads`, balance refresh | 2 | `stakingTronConfig.ts` | Y (opt) | High |
| `VITE_STAKING_TRON_TX_HISTORY_GRID_API_URL` | TronGrid base override | `env.ts` → `tronTransactionHistory.ts` | 2 | `stakingTronConfig.ts` | Y (opt) | High |
| `VITE_STAKING_CHAIN_ID` | Legacy-primary EVM chain id | `env.ts` → `STAKING_CHAIN_ID`, registry legacy row, **required** | 2 / 6 / 8 | `stakingConfig.ts` (`legacyPrimary`) | Bridge | High |
| `VITE_STAKING_NETWORK_LABEL` | Legacy network label | `env.ts` → legacy row + `STAKING_APPKIT_NETWORK` | 5 / 8 | `stakingConfig.ts` | Bridge | Med |
| `VITE_STAKING_EXPLORER_LABEL` | Legacy explorer label | `env.ts` → legacy row | 5 / 8 | `stakingConfig.ts` | Bridge | Med |
| `VITE_STAKING_EXPLORER_BASE_URL` | Legacy explorer base | `env.ts` → legacy row, explorer URLs | 2 / 8 | `stakingConfig.ts` | Bridge | High |
| `VITE_STAKING_VAULT_ADDRESS` | Legacy vault | `env.ts` + **direct** `import.meta.env` in `affiliateFirestoreStats.ts` | 2 / 6 / 8 | `stakingConfig.ts` (single accessor) | Bridge | High |
| `VITE_STAKING_TOKEN_ADDRESS` | Optional ERC-20 override | `env.ts` → staking vault config | 2 / 5 | `stakingConfig.ts` | Y (opt) | High |
| `VITE_STAKING_RPC_URL` | Legacy HTTP RPC | `env.ts` → legacy row | 2 / 8 | `stakingConfig.ts` | Bridge | High |
| `VITE_STAKING_WS_URL` | Legacy WS | `env.ts` → legacy row | 2 / 8 | `stakingConfig.ts` | Y (opt) | Med |
| `VITE_STAKING_TX_HISTORY_ORIGIN` | Indexer/history API origin | `env.ts` → `stakingVaultConfig.stakingTxHistoryUrl`, history errors | 2 | `stakingConfig.ts` | Y (opt) | High |
| `VITE_STAKING_TERMS_URL` | Terms of use link | `env.ts` → UI / consent | 4 | `stakingUiConfig.ts` | Y | Med |
| `VITE_DEBUG_LOGS` | Logger verbosity | `env.ts` → `DEBUG_LOGS` | 9 | `stakingFeatureFlags.ts` | Y (opt) | Low |
| `VITE_FIREBASE_API_KEY` | Firebase | `env.ts` → affiliate Firebase init | 3 | `stakingInfraConfig.ts` | Y | High |
| `VITE_FIREBASE_AUTH_DOMAIN` | Firebase | `env.ts` | 3 | `stakingInfraConfig.ts` | Y | High |
| `VITE_FIREBASE_PROJECT_ID` | Firebase | `env.ts` | 3 | `stakingInfraConfig.ts` | Y | High |
| `VITE_FIREBASE_STORAGE_BUCKET` | Firebase | `env.ts` (optional) | 3 | `stakingInfraConfig.ts` | Y (opt) | Med |
| `VITE_FIREBASE_MESSAGING_SENDER_ID` | Firebase | `env.ts` (optional) | 3 | `stakingInfraConfig.ts` | Y (opt) | Low |
| `VITE_FIREBASE_APP_ID` | Firebase | `env.ts` | 3 | `stakingInfraConfig.ts` | Y | High |
| `VITE_FIREBASE_MEASUREMENT_ID` | Analytics | `env.ts` (optional) | 3 | `stakingInfraConfig.ts` | Y (opt) | Low |
| `VITE_AFFILIATE_FIRESTORE_DATABASE_ID` | DB id | `env.ts` → affiliate config | 3 | `stakingInfraConfig.ts` | Y (opt) | High |
| `VITE_AFFILIATE_FIRESTORE_ADDRESS_FORMAT` | Doc id normalization | `env.ts` → affiliate | 3 | `stakingInfraConfig.ts` | Y (opt) | High |
| `VITE_RUNTIME_SWITCH_ROLLOUT` | Internal swap / picker rollout | `env.ts` → swap policy / picker | 9 | `stakingFeatureFlags.ts` | Y | High |
| `VITE_RUNTIME_TELEMETRY_STAGE` | Telemetry stage | `env.ts` + `runtimeTelemetry.ts` | 9 | `stakingFeatureFlags.ts` | Y (opt) | Med |
| `VITE_RUNTIME_TELEMETRY_SAMPLE_RATE` | Sampling | `env.ts` + `runtimeTelemetry.ts` | 9 | `stakingFeatureFlags.ts` | Y (opt) | Low |
| `VITE_RUNTIME_PICKER_DEV` | Dev panel | `env.ts` (DEV gated) | 9 | `stakingFeatureFlags.ts` | Y (opt) | Med |
| `VITE_RUNTIME_TORTURE` | Torture suite | `env.ts` (DEV gated) | 9 | `stakingFeatureFlags.ts` | Y (opt) | Med |
| `VITE_RUNTIME_SWAP_STRESS` | Stress harness | `env.ts`, `runtimeTransitionTelemetry.ts` | 9 | `stakingFeatureFlags.ts` | Y (opt) | Med |
| `VITE_RUNTIME_CHAOS` | Chaos suite | `env.ts` (DEV gated) | 9 | `stakingFeatureFlags.ts` | Y (opt) | Med |
| `VITE_APPKIT_TRON_IDENTITY` | AppKit Tron diagnostics | `env.ts` → identity bridge | 9 | `stakingFeatureFlags.ts` | Y (opt) | High |
| `VITE_STAKING_DEPLOYMENTS_JSON` | Optional registry JSON | `env.ts` → `getStakingDeploymentRegistry` | 2 | `stakingConfig.ts` | Y (opt) | High |
| `VITE_ETHERSCAN_API_KEY` | Etherscan API | `env.ts` → history / explorer helpers | 3 | `stakingInfraConfig.ts` | Y (opt) | Med |
| `VITE_CHAINLINK_ETH_USD_FEED` | Feed address override | `ethUsdChainlinkFeeds.ts` | 2 | `stakingEthConfig.ts` | Y (opt) | High |
| `VITE_ETH_USD_CACHE_TTL_MS` | ETH/USD poll TTL | `ethUsdPriceCache.ts` | 2 | `stakingEthConfig.ts` | Y (opt) | Med |
| `VITE_ETH_USD_FEED_STALE_AFTER_SEC` | Stale threshold | `ethUsdPriceCache.ts` | 2 | `stakingEthConfig.ts` | Y (opt) | Med |
| `VITE_NATIVE_USD_RATE` | Parsed, unused | `env.ts` only | 7 | Remove or wire | Y (opt) | Low |
| `VITE_STAKING_HIGH_NETWORK_FEE_WEI` | Parsed, unused | `env.ts` only | 7 | Remove or wire | Y (opt) | Low |
| `VITE_STAKING_PROFIT_MANAGER_STATUS_URL` | Optional, no callers | `env.ts`, `stakingVaultConfig` | 7 | Deprecate | Y (opt) | Low |

**Commented in `.env` (all environments):** same classification as their active counterparts — **`VITE_RUNTIME_PICKER_DEV`**, **`VITE_RUNTIME_TORTURE`**, **`VITE_RUNTIME_SWAP_STRESS`**, **`VITE_RUNTIME_CHAOS`** → category **9**, keep as env toggles when enabled.

---

## 6. Safety analysis — what may move vs must stay in env

### 6.1 SAFE to eventually inline (into typed constants)

**Only after** confirming **one** deployment truth and product sign-off:

- Human **labels** that are not authoritative (`*_PRODUCT_LABEL`, `*_TOKEN_SYMBOL` hints, `*_CHAIN_FAMILY` strings) **if** they stay identical across prod/stage — otherwise keep in env or per-build config.
- Default **telemetry** numeric defaults (already have code defaults for sample rate).
- **Dead** keys (§4.4) — removal is “safe” only after validation they are not consumed by external tooling.

### 6.2 MUST stay deployment-specific (env or CI-injected)

- **Chain identifiers, RPC/WS URLs, vault addresses, token addresses** for each deployment row.
- **`VITE_STAKING_TX_HISTORY_ORIGIN`** and Tron grid override — indexer routing.
- **Firebase / Reown / Etherscan** credentials and project binding.
- **`VITE_STAKING_TERMS_URL`**, **`VITE_APP_METADATA_*`** — environment-appropriate URLs.

### 6.3 DANGEROUS — wrong value changes core behavior

| Area | Keys (representative) |
|------|---------------------|
| Runtime selection / registry | `VITE_STAKING_*`, `VITE_STAKING_ETH_*`, `VITE_STAKING_TRON_*`, `VITE_STAKING_DEPLOYMENTS_JSON` |
| Chain routing / AppKit | `VITE_STAKING_CHAIN_ID`, `STAKING_APPKIT_NETWORK` inputs, CAIP2 |
| Tx execution | Vault + RPC + token address family |
| History / indexer | `VITE_STAKING_TX_HISTORY_ORIGIN`, `VITE_STAKING_TRON_TX_HISTORY_GRID_API_URL`, `VITE_ETHERSCAN_API_KEY` |
| Firebase isolation | `VITE_FIREBASE_*`, `VITE_AFFILIATE_FIRESTORE_*` |
| Wallet providers | `VITE_REOWN_PROJECT_ID`, app metadata |
| Internal orchestration toggles **`VITE_RUNTIME_SWITCH_ROLLOUT`**, **`VITE_RUNTIME_*` stress** | Affect swap execution and dev tooling |

---

## 7. Target future layout (recommendation only — **not implemented**)

```
src/staking/config/
  stakingConfig.ts          # registry-facing legacy + merged view accessors (read-only)
  stakingEthConfig.ts       # explicit ETH block + Chainlink + eth/usd cache knobs
  stakingTronConfig.ts      # explicit Tron block + token + grid API
  stakingUiConfig.ts        # terms, wallet-facing metadata, display labels policy
  stakingFeatureFlags.ts   # runtime switch, telemetry, dev suites, AppKit Tron diag
  stakingInfraConfig.ts     # Firebase, affiliate DB, Etherscan (optional split from staking)
```

Typed modules would **call** existing `env.ts` **or** wrap `import.meta.env` in one place to eliminate ** scattered access** (`affiliateFirestoreStats`).

---

## 8. Phased migration plan (CFG2–CFG4)

| Phase | Goal | Typical work | Env deletion? |
|-------|------|--------------|-------------|
| **CFG2** | Introduce `src/staking/config/*` **facades** re-exporting today’s `env.ts` / small derivations | Add modules; switch **non-staking** call sites only if zero-risk; fix **one** direct `import.meta.env` straggler **via facade** | **No** env removal |
| **CFG3** | Collapse duplication **in code** | Single “resolved legacy vs explicit” reader; document required parity rules; optional codegen from one JSON manifest | **Optional**: drop **proven-dead** keys from `.env.example` / docs first |
| **CFG4** | Env minimization | Remove legacy `VITE_STAKING_*` **only after** all readers use canonical staking config and production validation | **Yes**, coordinated |

### 8.1 Estimated env reduction count (order-of-magnitude)

- **Immediately identifiable as unread in `src` today:** ~**18–22** keys in committed `.env` templates (ETH/TRON “hint” block + Tron WS + vestigial parsers).
- **After bridge removal (legacy `VITE_STAKING_*`):** up to **~12** additional keys **if** explicit ETH+Tron blocks become the only source (high coordination; not scheduled in CFG1).

### 8.2 Safe-first migration order

1. **Facilities** — CFG2 facades + unit tests mirroring current values.  
2. **Strangler** — Move **affiliate** vault string to facade (eliminate raw `import.meta.env`).  
3. **Dedupe docs** — Machine-check env parity (CI script comparing legacy vs `ETH_*`).  
4. **Optional JSON** — `VITE_STAKING_DEPLOYMENTS_JSON` as eventual single manifest; env files shrink.  
5. **Remove dead** — `NATIVE_USD_RATE` / `HIGH_NETWORK_FEE_WEI` or implement features.

### 8.3 Rollback strategy

- **CFG2–3:** Revert commits; facades are additive.  
- **CFG4:** Keep previous `.env` in secrets manager; one-click redeploy prior bundle; feature-flag registry merge if needed.

### 8.4 Blast-radius assessment

| Change type | Radius |
|-------------|--------|
| Facade-only (CFG2) | **Low** if no behavioral change and tests pass |
| Legacy env removal (CFG4) | **High** — affects build-time validation, registry, AppKit, history |
| Firebase / Reown key moves | **High** — cross-feature |

---

## 9. CFG1 verification

- **`pnpm typecheck`** — pass  
- **`pnpm build`** — pass (script runs `tsc` then `vite build --mode production`)  
- **Code changes for CFG1** — none (report-only)

---

## 10. Open questions for CFG2 kickoff

1. Should **per-row** `*_TX_HISTORY_ORIGIN` replace a single global origin for multi-deployment history?  
2. Is **`VITE_STAKING_ETH_TOKEN_ADDRESS`** intentional for production, or should it be removed in favor of **`VITE_STAKING_TOKEN_ADDRESS`** only?  
3. Should **Tron WS** be wired in registry or deleted from `.env` to reduce confusion?

---

*End of CFG1 — analysis and report only.*
