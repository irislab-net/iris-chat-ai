# Staking final architecture (ARCH-FREEZE snapshot)

> Archived historical snapshot. Current architecture boundaries, runtime contracts, and maintenance rules are in `../../staking-domain-boundaries.md`, `../../staking-runtime-contracts.md`, and `../../staking-maintenance-rules.md`. Use this file for phase history only.

**Purpose.** Single reference for the **post-consolidation, post-freeze** staking system.  
**Non-goals.** This document does **not** authorize refactors; it describes **what exists today**.

**Related:** `docs/staking-maintenance-rules.md`, `docs/archive/migration-phase-reports/staking-final-state-report.md`, canonical hook contracts in `src/staking/vault/composer/stakingVaultComposerContracts.ts` and `src/staking/runtime/network/stakingNetworkContracts.ts`.

---

## Runtime topology

- **Composer (vault assembly)** — `src/staking/vault/composer/*` orchestrates planes in a **fixed hook order** (see below). Public surface is assembled for `StakingApp` consumers without leaking internal planes.
- **Runtime planes** — `src/staking/runtime/useStakingVaultRuntimePlanes.ts`: EVM execution chain/account, passive Tron wallet identity, wrong-network inputs. **Not** the refresh/history engines.
- **Network plane** — `src/staking/runtime/network/*` (`useStakingVaultNetworkGlue`, chain mirrors, contracts in `stakingNetworkContracts.ts`). **Only** this package owns switch UX + EVM reconciliation wiring into the refresh bundle (G4d: no composer-local network shim).
- **Reads plane** — `src/staking/reads/*` (`useStakingVaultTokenReads*`, mount/`loadMeta`).
- **Refresh plane** — `src/staking/refresh/*` + `useStakingVaultRefreshPlane`: balance orchestration, Tron polling/refetch wiring, tx-notify, reset/continuity. **Order-sensitive.**
- **History plane** — `src/staking/history/*` + `useStakingVaultHistoryPlane`: merged history, Tron rehydrate glue, effects **after** core history registration.
- **Tx plane** — `src/staking/tx/*` (types, session persistence, on-chain recovery) + `src/staking/tx/execution/useStakingVaultTxExecution.ts`. **Modal / status UX** lives under `src/components/pages/staking/TransactionStatus*` — composed **outside** the vault composer core but part of product tx story.
- **Execution / gas / explorers** — `src/staking/execution/*` (read factories, gas, Tron passive reads, explorer helpers).
- **Orchestration** — `src/staking/orchestration/*` (wallet open/switch policy, runtime transitions, mobile resume store). **Does not** own refresh tick implementation.
- **Core** — `src/staking/core/*`: deployment registry accessors, provider registry, CAIP-2 math, normalization, validation, receipt/provider construction contracts.
- **Diagnostics** — `src/staking/diagnostics/*`: DEV-only invariants, smoke, soak, boundary rules, **ARCH-FREEZE** checks (`stakingArchFreezeDev.ts`).
- **Capabilities & rollout** — `src/staking/runtime/capabilities/*`: family rollout (`stakingRuntimeFamilyRollout`), hydration gate (`stakingRuntimeHydration`), CFG6 sentinel (`stakingRuntimeDisabledSentinel`).

---

## Ownership map (who owns what)

| Concern | Owner module / plane |
| --- | --- |
| Deployment rows, default id, sentinel | `getStakingDeploymentRegistry`, `resolveStakingDeploymentForReconcile`, `stakingRuntimeDisabledSentinel` |
| Provider / receipt maps | `providerRegistry.ts` (keys: `deriveProviderRuntimeKey`) |
| Active deployment for selection | `resolveStakingDeploymentForActiveSelection` (+ runtime selection stack) |
| Wrong-network truth | Selectors + `stakingNetworkContracts` (Tron: passive identity; EVM: execution chain vs expected) |
| Switch / reconcile UX | `useStakingVaultNetworkGlue` + `openUnifiedWallet` / `requestUnifiedNetworkSwitch` |
| Token meta + loadMeta | Reads plane |
| Balance refresh orchestration | Refresh plane (`stakingRefresh*`, orchestrator session) |
| History merge + Tron grid | History plane |
| CTA / inline reasons | `src/staking/cta/*` |
| Affiliate PnL / Firestore | `src/staking/affiliate/*`, profit singleton |
| AppKit instance / default network | `src/reownKit.ts` + `src/lib/wallet/appKitStakingNetworks.ts` (deployment-aligned default) |

---

## Plane boundaries

- **Core** must not import React or UI routes.
- **Execution** must not own composer hook ordering.
- **Composer** wires planes; it must not reimplement network glue or refresh orchestration internals.
- **Diagnostics** never changes product state; smoke/freeze/soak are **DEV** or **sampled telemetry** only.
- Boundary matrices: `src/staking/diagnostics/stakingBoundaryRules.ts` (`STAKING_BOUNDARY_RULES`, `devAssertStakingImportBoundary`).

---

## Refresh / history / tx ownership

- **Refresh:** `src/staking/refresh/*` — single orchestrator session semantics; `useStakingVaultRefreshPlane` registers hooks in **phase order** (`devAssertRefreshPlaneRegistrationOrder` in `stakingInvariantAssertionsDev.ts`).
- **History:** `src/staking/history/*` — keys, merge, Tron transaction history; plane must not call refresh internals except through published refresh APIs.
- **Tx:** `src/staking/tx/*` — session persistence, recovery, execution hooks; **status scenario** types under `src/staking/tx/types/*`. UI surfaces in `components/pages/staking` consume tx types; execution plane stays in `staking/tx/execution`.

---

## Runtime / network ownership

- **Runtime identity** (deployment, `runtimeKey`, generation) — `RuntimeOperationContext` + runtime selection.
- **Network** — `staking/runtime/network` only for glue + mirrors; see registration order in `stakingNetworkContracts.ts`.
- **Capabilities** — `runtimeCapabilities` / `runtimeFamilyDispatch`: executable vs passive paths; Tron execution remains policy-gated.

---

## Env / runtime capability semantics

- **Family rollout:** `VITE_ENABLE_ETHEREUM`, `VITE_ENABLE_TRON` — unset → **enabled**; explicit `false`/`0`/`off`/`disabled` → **off** (`readNetworkFamilyRolloutEnabled` in `env.ts`).
- **Registry filtering:** `getStakingDeploymentRegistry` drops rows whose `chainFamily` is disabled; recomputes default id.
- **Hydration:** `isStakingVaultRuntimeHydrationEnabled(deployment)` — false for CFG6 sentinel and when family disabled.

---

## Hard-disable semantics (CFG6)

When **no** deployments survive filtering:

- `resolveStakingDeploymentForActiveSelection` returns the **sentinel** row (`cfg6-runtime-disabled`), **not** in the registry list.
- Sentinel is minimal EVM-shaped; **must not hydrate** providers for real work (`isStakingVaultRuntimeHydrationEnabled` false).
- Capabilities map to non-operational / unknown family behavior downstream — **fail-closed** for staking execution.

---

## Orchestration lifecycle

- **Runtime transitions** — `runtimeTransitionCoordinator`, `runtimeTransitionSequence`, swap policy/engine (feature-gated / DEV stress).
- **Wallet** — `useUnifiedWalletOrchestration`, `openUnifiedWallet`, passive Tron switch fallback.
- **Mobile resume** — `stakingMobileResumeCoordinator`, `stakingMobileResumeStore`, bootstrap splash coordination via `BootstrapOrchestrationProvider`.

Orchestration **coordinates**; it does **not** replace refresh/history modules.

---

## AppKit bootstrap flow

1. `reownKit.ts` runs at module load: adapters depend on `isRuntimeFamilyEnabled`.
2. **Networks + default network** from `buildReownAppKitNetworksAndDefault()` (`appKitStakingNetworks.ts`) — default follows **actual staking deployment** (registry), not a hardcoded Tron mainnet fallback.
3. App readiness: `useAppKitReady` + bootstrap provider for splash vs `reportStakingVaultHydrated`.

---

## Deployment registry lifecycle

1. Base: legacy EVM row from env **if** Ethereum family enabled; else empty base.
2. Merge explicit env rows (`buildExplicitEnvDeploymentRows`), optional JSON (`VITE_STAKING_DEPLOYMENTS_JSON`).
3. Filter by family rollout.
4. Validate (`validateStakingDeploymentRegistryFull`); on hard errors, fallback to legacy-only or empty per `env.ts` policy.
5. **Active selection** uses sentinel when `deployments.length === 0`.

---

## Hook-order invariants

**Composer (high level)** — see numbered list in `stakingVaultComposerContracts.ts` (runtime plane → refs → reads → balance/tx → identity → refresh → history → presentation → tx execution → diagnostics → public assembly).

**Refresh bundle (forbidden reorder)** — asset lifecycle → balance callbacks → Tron ref wiring → reset/continuity → **network glue** → `loadMeta` mount → tx-notify → orchestrator → Tron polling.

**Network bundle** — `stakingNetworkContracts.ts`: mirrors before refresh glue, glue before `loadMeta`, etc.

**Phase markers (freeze)** — `STAKING_HOOK_ORDER_FREEZE_MARK` in `stakingArchitectureFreezeMark.ts`.

---

## Forbidden cross-imports (summary)

- `src/staking/*` must not import deleted `@/lib/staking/*` shims; prefer `@/staking/*` canonical paths.
- Layer rules in `stakingBoundaryRules.ts` (prefix denylists per package id).
- G4d: **never** reintroduce `useStakingVaultEvmNetworkGlue`; canonical `useStakingVaultNetworkGlue` only.

---

## Fail-closed behavior

- Invalid or rollout-inconsistent registry → filtered / legacy fallback / empty + sentinel (see `getStakingDeploymentRegistry`).
- Tron / EVM provider creation throws on wrong family (`getOrCreateEvmJsonRpcProviderForDeployment`, etc.).
- Hydration off → refresh/read paths must **not** assume live contract surfaces (callers gate on `isStakingVaultRuntimeHydrationEnabled`).

---

## Sentinel behavior

- **CFG6 sentinel id:** `cfg6-runtime-disabled` (`stakingRuntimeDisabledSentinel.ts`).
- Used **only** when registry has zero real rows after filtering.
- **Not** a wallet network; RPC is inert; explorers invalid — **operational no-op** for staking hydration.

---

## Canonical package map (`src/staking/`)

| Path | Role |
| --- | --- |
| `affiliate/` | Affiliate stats, PnL selectors |
| `config/` | Staking config, feature flags, ETH/Tron config surfaces |
| `core/` | Registry, providers, CAIP-2, validation, runtime context helpers |
| `cta/` | CTA phase, inline reasons, diagnostics |
| `dev/` | DEV suites (chaos, torture, stress, readiness gate) |
| `diagnostics/` | Invariants, smoke, soak, boundaries, **ARCH-FREEZE** |
| `execution/` | Gas, reads factory, Tron passive execution-adjacent helpers |
| `history/` | History merge, Tron/Evm history hooks |
| `identity/` | Tron identity, passive UX |
| `integrations/` | e.g. Telegram URL helpers |
| `notifications/` | Passive notification / receipt sonner policy |
| `orchestration/` | Wallet, transitions, mobile resume |
| `profit/` | Profit manager / Firestore bridge |
| `reads/` | Token reads, EVM/Tron loaders |
| `refresh/` | Balance orchestration, Tron refresh wiring |
| `runtime/` | Planes, network plane **subdir**, capabilities |
| `selectors/` | Derived flags, presentation memos |
| `tx/` | Tx types, persistence, recovery, execution |
| `ui/` | Staking UI tokens (non-page components) |
| `vault/composer/` | Vault hook composition + public assembly |

**Freeze token:** `STAKING_ARCHITECTURE_FREEZE_TOKEN` in `stakingArchitectureFreezeMark.ts`.
