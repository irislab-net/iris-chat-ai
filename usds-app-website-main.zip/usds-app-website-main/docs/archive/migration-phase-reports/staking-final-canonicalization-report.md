# Staking final canonicalization report (Phase G3.5)

Eliminates the last non-shim legacy imports before G4 destructive cleanup. **Extraction + import migration only** — no runtime behavior changes, no bridge removal, no shim deletion.

Verification: `pnpm typecheck` ✅ · `pnpm build` ✅

---

## 1. Executive summary

| Metric | Value |
|--------|------:|
| **Remaining real legacy `from` imports** | **0** |
| **Remaining non-shim `@/lib/staking/*` consumers** | **0** |
| **Total shim / re-export bridge files** | **51** |
| **G4 safe-delete candidates** (after tron move + bridge phase) | **51** |
| **Blocked deletions before G4** | Public vault bridge + `lib/tron` implementations |

---

## 2. G3.5 extractions

### Canonical homes created

| Module | Canonical path | Barrel |
|--------|----------------|--------|
| Profit manager Firestore singleton | `src/staking/profit/profitManagerStatusSingleton.ts` | `@/staking/profit` |
| Telegram URL capture (staking funnel) | `src/staking/integrations/originalTelegramUrl.ts` | `@/staking/integrations` |

### Backward-compatible shims (kept)

| Shim | Re-exports from |
|------|-----------------|
| `src/lib/staking/profitManagerStatusSingleton.ts` | `@/staking/profit` |
| `src/lib/staking/originalTelegramUrl.ts` | `@/staking/integrations` |

### Consumers migrated

| File | Before | After |
|------|--------|-------|
| `src/hooks/useProfitManagerStatus.ts` | `@/lib/staking/profitManagerStatusSingleton` | `@/staking/profit` |
| `src/providers/TelegramEscalationProvider.tsx` | `@/lib/staking/originalTelegramUrl` | `@/staking/integrations` |

---

## 3. Remaining legacy import count

### Non-shim `from` imports

```
@/lib/staking/*     → 0
@/lib/tron/*        → 0 (only G3 canonical bridges; see §5)
@/hooks/useUnifiedWalletOrchestration → 0
@/lib/wallet/openUnifiedWallet          → 0
@/services/gasEstimator                 → 0
@/hooks/useStakingGasToastDedupe        → 0
@/lib/stakingTxMobileLifecycleDebug     → 0
@/lib/stakingEtherscanHistory           → 0
@/staking/core/runtimeSwap* shims      → 0
```

**Real consumer legacy imports: 0**

---

## 4. Canonical ownership tree

```
src/staking/
├── core/              # Registry, runtime selection, persistence types, address codecs
├── runtime/           # Runtime planes, chain id, network glue package
│   └── network/
├── vault/composer/    # useStakingVault composition planes
├── reads/             # Token / pool reads
├── execution/         # RPC, gas, reads, etherscan history, fee presentation
├── tx/                # Tx session, recovery, fee canonical, execution guards
├── refresh/           # Balance refresh orchestrator + metrics
├── orchestration/     # Wallet open, runtime swap, transition coordinator
├── identity/          # Runtime wallet identity, navbar hold, passive UX
│   └── tron/          # tronWalletIdentity bridge → lib/tron (G4 move)
├── history/           # Vault history hooks + tron history bridge
├── notifications/     # Passive + receipt Sonner policies
├── ui/                # Toast, input styles, slider visual
├── cta/               # CTA ellipsis, phase, inline resolver
├── diagnostics/       # DEV assertions, soak, lifecycle, tx integrity
├── selectors/         # Presentation selectors
├── affiliate/         # Affiliate plane
├── profit/            # Profit manager status singleton (G3.5)
└── integrations/      # Telegram URL capture (G3.5)
```

**Authoritative outside `staking/` (intentional):**

- `src/staking/core/*` — deployment registry (not a shim)
- `src/lib/tron/*` — Tron implementation (G4: move under `staking/identity` + `staking/history`)
- `src/lib/stakingVaultFirestoreProfitStatus.ts` — Firestore schema (profit singleton depends on it)

---

## 5. Shim-only evidence

### `@/lib/staking/` — `from` imports

**None** outside `src/lib/staking/*.ts` shim files.

### `@/lib/tron/` — `from` imports

Only canonical re-export bridges:

- `src/staking/identity/tron/tronWalletIdentity.ts`
- `src/staking/history/tronTransactionHistory.ts`

### Hook / service / wallet shims — `from` imports

**None** in non-shim files. Shims exist at:

- `src/hooks/useUnifiedWalletOrchestration.ts`
- `src/hooks/useStakingGasToastDedupe.ts`
- `src/services/gasEstimator.ts`
- `src/lib/stakingTxMobileLifecycleDebug.ts`
- `src/lib/stakingEtherscanHistory.ts`
- `src/lib/wallet/openUnifiedWallet.ts`

### Core orchestration shims — `from` imports

**None** in non-shim files. Shims:

- `src/staking/core/runtimeTransitionCoordinator.ts`
- `src/staking/core/runtimeSwapPolicy.ts`
- `src/staking/core/runtimeSwapEngine.ts`
- `src/staking/core/createTronReceiptResolver.ts`

---

## 6. Remaining shim count (51)

| Category | Count |
|----------|------:|
| `src/lib/staking/*.ts` | 39 |
| Hook / service / lib root shims | 6 |
| `src/staking/core/*` orchestration shims | 4 |
| Composer network glue shim | 1 |
| Tron canonical bridges (re-export `lib/tron`) | 2 |

---

## 7. G4 safe-delete inventory (51 files)

Delete only after grep confirms zero imports and dependent phases complete.

### `src/lib/staking/*` (39)

All `@deprecated` re-export modules, including G3.5:

- `profitManagerStatusSingleton.ts`
- `originalTelegramUrl.ts`
- Plus 37 modules from G2 (toast, refresh, cta, identity, execution, tx, diagnostics, …)

### External shims (6)

1. `src/hooks/useUnifiedWalletOrchestration.ts`
2. `src/hooks/useStakingGasToastDedupe.ts`
3. `src/services/gasEstimator.ts`
4. `src/lib/stakingTxMobileLifecycleDebug.ts`
5. `src/lib/stakingEtherscanHistory.ts`
6. `src/lib/wallet/openUnifiedWallet.ts`

### Core + composer shims (5)

7. `src/staking/core/runtimeTransitionCoordinator.ts`
8. `src/staking/core/runtimeSwapPolicy.ts`
9. `src/staking/core/runtimeSwapEngine.ts`
10. `src/staking/core/createTronReceiptResolver.ts`
11. `src/staking/vault/composer/useStakingVaultEvmNetworkGlue.ts`

### Tron bridges — delete after moving `lib/tron` impl (2)

12. `src/staking/identity/tron/tronWalletIdentity.ts`
13. `src/staking/history/tronTransactionHistory.ts`

Then delete:

14. `src/lib/tron/tronWalletIdentity.ts`
15. `src/lib/tron/tronTransactionHistory.ts`

---

## 8. Blocked deletions (G4 prerequisites)

| Blocker | Why | G4 action |
|---------|-----|-----------|
| **Public vault bridge fields** | `address`, `isConnected`, `chainId` still on `assembleStakingVaultPublicValue` | Phase G: remove from public DTO + DEV getters |
| **`activeRuntimeSelection` on vault return** | External compatibility; UI uses `useActiveRuntimeSelection()` | Phase G: remove from public topology |
| **`withDeprecatedVaultBridgeDevInstrumentation`** | Wraps public vault return | Remove with bridge fields |
| **`lib/tron/*` implementations** | Passive identity + TronGrid history | Move into `staking/`; then delete bridges |
| **Unknown external integrators** | May import deprecated paths via package paths | Communicate breaking change before shim delete |

---

## 9. Public bridge inventory

Still exported on `useStakingVault()` public value (unchanged in G3.5):

| Field | Replacement | UI status |
|-------|-------------|-----------|
| `address` | `executionAddress` / `runtimeWalletAddress` | No component reads `vault.address` |
| `isConnected` | `executionConnected` / `runtimeWalletConnected` | No component reads `vault.isConnected` |
| `chainId` | `executionChainId` | No component reads `vault.chainId` |
| `activeRuntimeSelection` | `useActiveRuntimeSelection()` | No vault consumer; context hook only |

DEV: `withDeprecatedVaultBridgeDevInstrumentation` warns on deprecated field reads.

Runtime planes deprecated aliases (separate from vault bridge): instrumented via `withDeprecatedRuntimePlanesDevInstrumentation`.

---

## 10. G4 deletion candidates (ordered)

### Phase G4a — Shim deletion (low blast radius)

Delete all **51** shim/bridge files in §7 after CI grep gate passes.

**Estimated blast radius:** Low if grep clean — re-exports only; bundler already resolves canonical paths.

### Phase G4b — Tron implementation move

1. Move `lib/tron/tronWalletIdentity.ts` → `staking/identity/tron/` (implementation)
2. Move `lib/tron/tronTransactionHistory.ts` → `staking/history/` (implementation)
3. Delete tron bridges + old `lib/tron` files

**Estimated blast radius:** Medium — passive Tron identity + history loaders; test runtime swap + history tab.

### Phase G4c — Public bridge removal (high blast radius)

1. Remove `address`, `isConnected`, `chainId`, `activeRuntimeSelection` from `assembleStakingVaultPublicValue`
2. Update `stakingVaultPublicTopology.ts` / types
3. Remove DEV bridge instrumentation

**Estimated blast radius:** High for any external consumer of `useStakingVault()` — internal UI already migrated.

### Phase G4d — Composer glue cleanup

- Remove `useStakingVaultEvmNetworkGlue` shim; ensure all callers use `@/staking/runtime/network`

---

## 11. Exact remaining blockers before destructive cleanup

1. **None** for import canonicalization — all app/staking consumers use `@/staking/*`.
2. **G4a** blocked only by process: confirm no third-party imports of `@/lib/staking/*`.
3. **G4b** blocked by: `lib/tron` implementation not yet relocated.
4. **G4c** blocked by: explicit bridge removal phase + release notes.
5. **G4d** blocked by: composer shim audit (single deprecated export path).

---

## 12. Manual QA checklist

1. `/staking/app` loads  
2. Profit manager polling (`useProfitManagerStatus` → `@/staking/profit`)  
3. Telegram escalation flow (`TelegramEscalationProvider` → `@/staking/integrations`)  
4. Navbar wallet  
5. Runtime swap  
6. Deposit/withdraw  
7. Tx modal  
8. Refresh orchestration  
9. History  
10. Soak monitor  

---

*Generated: Phase G3.5 — final blocker extraction complete. Ready for G4 shim deletion planning.*
