# G4c Bridge retirement report

Destructive removal of deprecated public vault compatibility bridges after G4a/G4b canonicalization and Phase S1 stabilization. **No orchestration, refresh, history, or tx logic changes** — only deprecated surfaces and DEV wrappers.

Verification: `pnpm typecheck` ✅ · `pnpm build` ✅

---

## 1. Summary

| Metric | Value |
|--------|------:|
| **Deleted files** | **3** |
| **Removed public vault fields** | **4** |
| **Removed runtime plane aliases** | **3** |
| **Removed diagnostic exports** | **5** |
| **New DEV assertions** | **2** |
| **Topology keys (before → after)** | 65 → **61** |

---

## 2. Removed public vault fields (4)

Deleted from `assembleStakingVaultPublicValue`, `STAKING_VAULT_PUBLIC_TOPOLOGY_KEYS`, and `StakingVaultValue`:

| Removed | Canonical replacement |
|---------|----------------------|
| `address` | `executionAddress` |
| `isConnected` | `executionConnected` (EVM) / `runtimeWalletConnected` (Tron UI) |
| `chainId` | `executionChainId` |
| `activeRuntimeSelection` | `useActiveRuntimeSelection()` |

Consumers were already on canonical fields; no component imported the removed vault properties.

---

## 3. Removed runtime plane aliases (3)

Deleted from `StakingVaultRuntimePlanes` and `useStakingVaultRuntimePlanes` return:

| Removed | Canonical replacement |
|---------|----------------------|
| `address` | `executionAddress` |
| `isConnected` | `executionConnected` / `runtimeWallet.connected` |
| `chainId` | `executionChainId` / `numericChainId` |

Internal wiring updated in `useStakingVault`, refresh plane, selectors, affiliate principal, and network glue DTO builder.

---

## 4. Deleted DEV / compatibility layers

### Files deleted (3)

1. `src/staking/diagnostics/stakingVaultDeprecatedBridgeDev.ts`
2. `src/staking/diagnostics/stakingVaultDeprecatedFieldDev.ts`
3. `src/staking/runtime/stakingRuntimePlanesDeprecatedDev.ts`

### Removed exports (5)

- `withDeprecatedVaultBridgeDevInstrumentation`
- `DeprecatedVaultBridgeField`
- `devWarnDeprecatedVaultField` (internal)
- `devWarnDeprecatedRuntimePlanesField`
- `DeprecatedRuntimePlanesDevContext` / `DeprecatedRuntimePlanesField`

### Trimmed

- `stakingMigrationAssertionsDev.ts` — lib-shim import warnings only (runtime-planes field warnings removed)

---

## 5. Updated public contracts

| Artifact | Change |
|----------|--------|
| `stakingVaultPublicTopology.ts` | 4 keys removed; `STAKING_VAULT_DEPRECATED_BRIDGE_KEYS` catalog for DEV |
| `stakingVaultPublicAssembly.ts` | Direct return; no bridge fields |
| `useStakingVault.ts` | Returns assembly directly; selectors use `execution*` / `walletIdentityConnected` |
| `stakingVaultDerivedFlags.ts` | `executionConnected`, `executionAddress`, `walletIdentityConnected` |
| `stakingAffiliatePrincipal.ts` | `walletIdentityConnected` |
| `useStakingVaultTxExecution.ts` | `executionAddress` input |

---

## 6. New DEV verification (G4c)

| Assertion | When |
|-----------|------|
| `devAssertNoDeprecatedVaultBridgeFields` | Public topology / assembly check |
| `devAssertNoDeprecatedRuntimePlaneAliases` | End of `useStakingVaultRuntimePlanes` |
| Smoke `g4c-deprecated-vault-bridge-catalog` | `runStakingArchitectureSmokeDev` |
| Smoke `g4c-deprecated-runtime-planes-catalog` | Same |

Manual: `window.__STAKING_ARCHITECTURE_SMOKE__()` after loading staking app.

---

## 7. Required grep results

| Pattern | `src/` result |
|---------|----------------|
| `vault.address` | **0** (deployment contract `deployment.vault.address` only) |
| `vault.isConnected` | **0** |
| `vault.chainId` | **0** |
| `withDeprecatedVaultBridgeDevInstrumentation` | **0** |
| `activeRuntimeSelection` | **0** on vault; `useActiveRuntimeSelection()` in components ✅ |

---

## 8. Public API delta

**Removed from `StakingVaultValue`:**

```ts
// removed
isConnected: boolean
address: string | undefined
chainId: number | null
activeRuntimeSelection: RuntimeOperationContext
```

**Unchanged canonical surface (representative):**

```ts
executionAddress: string | null
executionConnected: boolean
executionChainId: number | null
runtimeWallet: StakingRuntimeWalletIdentity
runtimeWalletConnected: boolean
// … balances, history, tx, refresh, etc.
```

---

## 9. Remaining shims / debt

| Item | Count | Phase |
|------|------:|-------|
| `useStakingVaultEvmNetworkGlue` | 1 | **G4d** |
| `runtimeCoreLayerBoundaryDev` | 1 | G4d optional |
| `lib/staking/*` legacy modules (non-shim helpers) | several | optional extract |
| Historical docs mentioning bridge | docs only | doc sweep optional |

**Shim count toward zero:** public bridge shims **0**; composer network glue **1**.

---

## 10. Post-G4c canonical architecture snapshot

```mermaid
flowchart TB
  subgraph app [Staking app]
    CTX[useStakingVault / StakingVaultContext]
    RTS[useActiveRuntimeSelection]
  end
  subgraph vault [Vault composer]
    ASM[assembleStakingVaultPublicValue]
    PLN[useStakingVaultRuntimePlanes]
  end
  subgraph planes [Canonical planes]
    EXE[executionAddress / executionConnected / executionChainId]
    RW[runtimeWallet*]
    REF[refresh / history / tx]
  end
  CTX --> ASM
  RTS -.-> app
  ASM --> EXE
  ASM --> RW
  PLN --> EXE
  PLN --> RW
  ASM --> REF
```

---

## 11. Manual QA checklist

1. EVM runtime connect  
2. Tron passive runtime  
3. Runtime swap  
4. Deposit  
5. Withdraw  
6. Approval  
7. Wrong network  
8. Navbar wallet  
9. History (EVM + Tron)  
10. Refresh orchestration  
11. Tx modal  
12. Soak monitor  
13. Disconnect / reconnect  

---

## 12. Recommendation

**Proceed to G4d** (`useStakingVaultEvmNetworkGlue` → `useStakingVaultNetworkGlue` only) or **architecture freeze** if external integrators no longer depend on removed fields.

G4c completes the planned **public API** bridge retirement; remaining debt is internal composer glue and optional lib extractions, not consumer-facing vault aliases.

---

*Phase G4c — 3 files deleted, 4 public fields removed, 5 exports removed.*
