# Staking configuration architecture refinement

**Intent:** Keep `import.meta.env` / `.env` for **deployment**, **infrastructure**, and **runtime-variable** values only. Push **typed, runtime-invariant** product constants into `src/staking/config/*` and consume them from there (or thin re-exports like `stakingVaultConfig` for legacy import paths).

**Verification:** `pnpm typecheck` and `pnpm build` succeed after these changes.

---

## Static values migrated into typed config

| Symbol / concept | New home | Notes |
| ---------------- | -------- | ----- |
| Legacy-primary default explorer **name** | `STAKING_LEGACY_PRIMARY_EXPLORER_LABEL_DEFAULT` in `stakingUiConfig.ts` | Used when `VITE_STAKING_EXPLORER_LABEL` is unset (`Etherscan`) |
| Legacy-primary default **network** display name | `STAKING_LEGACY_PRIMARY_NETWORK_LABEL_DEFAULT` | Used when `VITE_STAKING_NETWORK_LABEL` is unset (`Ethereum`) |
| Referral storage key + query keys | `STAKING_REFERRAL_STORAGE_KEY`, `STAKING_REFERRAL_QUERY_KEYS` | Product invariants; `stakingVaultConfig` re-exports |
| Stablecoin fallback label | `STAKING_DEFAULT_STABLECOIN_LABEL` | `stakingVaultConfig` exposes `STAKING_STABLECOIN_LABEL` alias |
| PnL USD-per-token invariant | `STAKING_PNL_USD_PER_TOKEN` | Re-exported from `stakingVaultConfig` |
| Legacy EVM native currency (name/symbol/decimals) | `LEGACY_EVM_NATIVE_CURRENCY` in `stakingEthConfig.ts` | `STAKING_APPKIT_NETWORK` uses it (no duplicate literal) |
| ETH/USD poll TTL + feed stale threshold | `readEthUsdCachePollTtlMs`, `getEthUsdFeedStaleThresholdSec` in `env.ts` | **Still env-backed**; implementation centralized in `env.ts`; `stakingEthConfig` re-exports for the staking barrel |

**Chain family literals** (`evm` / `tron`) and Tron CAIP fallback remain in `stakingEthConfig` / `stakingTronConfig` as before.

---

## Network rollout flags (env-backed)

| Env | Default | Export |
| --- | ------- | ------ |
| `VITE_ENABLE_ETHEREUM` | **On** if unset / empty | `isStakingEthereumEnabled()` (`env.ts`, re-exported `stakingFeatureFlags` / `@/staking/config`) |
| `VITE_ENABLE_TRON` | **On** if unset / empty | `isStakingTronEnabled()` |

**Semantics:** Only `1` / `true` / `yes` / `on` count as enabled; any other explicit value (e.g. `0`, `false`) disables. This **does not yet** filter the deployment registry or swap routing (no orchestrator/history/tx semantic changes in this pass); consumers should adopt the getters when gating UI or optional rows.

**Note:** `.env` files may still contain `VITE_STAKING_ETH_ENABLED` / `VITE_STAKING_TRON_ENABLED`; those are **not** read by the app today. Prefer the canonical `VITE_ENABLE_*` names above when wiring rollout logic.

---

## Env keys **safe to remove** (when acceptable)

Removal is **safe** only if the resulting behavior matches your deployment expectations.

| Key | Condition |
| --- | --------- |
| `VITE_STAKING_EXPLORER_LABEL` | Accept default **Etherscan** for legacy-primary UI. **Do not** remove if you need a different label (e.g. **Sepolia Etherscan**) without changing defaults in `stakingUiConfig.ts`. |
| `VITE_STAKING_NETWORK_LABEL` | Accept default **Ethereum** for legacy-primary UI. |

**Cosmetic / documentation-only keys** in some `.env` samples (not read by `env.ts`): e.g. `VITE_STAKING_ETH_TOKEN_SYMBOL`, `VITE_STAKING_ETH_TOKEN_DECIMALS`, `VITE_STAKING_ETH_CHAIN_FAMILY`, `VITE_STAKING_TRON_*_SYMBOL`, product label duplicates — safe to drop from env files for **clarity**; they were never authoritative for runtime.

---

## Env keys **intentionally retained** (non-exhaustive)

**Required for production (`envRequiredKeys` / `requireEnv`):**

- Staking executable row: `VITE_STAKING_CHAIN_ID`, `VITE_STAKING_RPC_URL`, `VITE_STAKING_VAULT_ADDRESS`, `VITE_STAKING_EXPLORER_BASE_URL`, `VITE_STAKING_TERMS_URL`
- Reown / metadata: `VITE_REOWN_PROJECT_ID`, `VITE_APP_METADATA_*`
- Firebase core: `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`, `VITE_FIREBASE_APP_ID`

**Optional but deployment/runtime sensitive:** RPC/WS URLs for explicit ETH/TRon rows, vault/token addresses, explorer **base URLs** (not names), `VITE_STAKING_DEPLOYMENTS_JSON`, tx history origins, Etherscan API key, Chainlink override, ETH/USD tuning, high-fee wei, telemetry/switch/stress flags, `VITE_APPKIT_TRON_IDENTITY`, Firebase extras, affiliate Firestore options.

**Rollout (optional, default on):** `VITE_ENABLE_ETHEREUM`, `VITE_ENABLE_TRON`

---

## `ImportMetaEnv` `VITE_*` count

After this refinement: **46** optional/required `VITE_*` declarations in `src/vite-env.d.ts` (labels no longer required; two rollout keys added).

---

## Rollback

Restore `VITE_STAKING_EXPLORER_LABEL` / `VITE_STAKING_NETWORK_LABEL` to **required** in `envRequiredKeys.ts` and `env.ts`, revert `optionalEnv ?? default` wiring, and move ETH/USD helpers back into `stakingEthConfig.ts` if needed.
