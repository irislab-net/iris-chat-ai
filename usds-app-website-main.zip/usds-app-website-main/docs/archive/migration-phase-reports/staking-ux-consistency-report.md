# Staking UX consistency report — Phase P1

**Method:** Static review of primary surfaces (forms, history, network chip, modals, navbar). **No UX code changes** in P1.

---

## 1. Loading states

| Surface | Observation |
|---------|-------------|
| Vault / balances | `vaultDataReady`, `balancesFetched`, `stakingHistoryLoading`, `tokenMetaFetched` — **multiple** independent flags; UI should avoid “flash of empty” by preferring skeletons where implemented (`StakingVaultSkeletons.tsx` exists) |
| Transaction history | Separate `stakingHistoryLoading` vs `affiliateLoading`; refresh button uses `refreshBtnLoading` — **consistent** pattern |
| Gas / fees | `useStakingGasEstimate` + fee smoothing hooks — watch for **fee skeleton** vs “0” flash (product tweak, not architecture) |
| Navbar | Loader branch in `NavbarWalletSection` when resolving AppKit — **hold** logic reduces flicker |

**Gap risk:** Any screen that gates on **only one** of `tokenMetaFetched` / `balancesFetched` may show inconsistent CTA vs balance.

---

## 2. Disabled states

| Surface | Observation |
|---------|-------------|
| Deposit / withdraw | CTA reasons via CTA phase + inline reasons — ensure disabled + reason text stay aligned (existing `StakingCtaReason` paths) |
| History refresh | `disabled={!historyUiActive \|\| refreshBtnLoading}` — **good**; manual handler also checks identity |
| Network chip | Wrong-network paths should disable transact but may still show **switch** affordance — verify copy vs `requestNetworkSwitch` |

---

## 3. Fee skeletons

- Fee display smoothing (`useStakingFeeDisplaySmoothing`) aims to reduce jitter.
- **Consistency:** Deposit vs withdraw should use same **skeleton duration** and “—” vs shimmer semantics (visual QA).

---

## 4. Refresh affordances

| Feature | Observation |
|---------|-------------|
| Balance refresh | `refreshBalances` + orchestrator-driven updates — no single global “Refresh balances” in all views (by design) |
| Activity / history | Manual refresh + auto resume debounce **documented in code** — UX is **consistent** after `refreshStakingHistory` assembly fix |
| Network chip | Uses shallow history refresh on some paths — verify user-visible feedback (toast vs silent) |

---

## 5. Wallet chip (`NavbarWalletSection`, `StakingAppNetworkChip`)

- **Tron wrong network:** `passiveTronWrongNetworkNavbarLabel` and chip copy should match staking app expectations.
- **Visual hold:** Reduces bounce on transient disconnect — **consistent** premium behavior; document for support (“chip may lag up to hold MS”).

---

## 6. Wrong-network UX

- **Network glue** (`useStakingVaultNetworkGlue`): toast dedupe, auto-switch, `WRONG_NETWORK` token meta error — **single owner** (G4d).
- **Forms:** `isWrongNetwork` should gate max/amount and CTA — verify **all** entry points (deposit, withdraw, approve) use same selector source.

---

## 7. Transaction modal

- **`TransactionStatusProvider`** + **`TransactionStatusSurface`**: large but centralized — consistency depends on **scenario** + **wire phase** enums, not duplicates.
- **Mobile:** lifecycle debug tooling exists — align tap targets and scroll lock with dialog component (visual QA).

---

## 8. Transitions & motion

- `animate-spin` on refresh icons — uses `motion-reduce` in transaction history — **good** pattern; replicate on any new spinners.
- Rolling / blurred placeholders in history — verify **reduce motion** prefers static blur or opacity only.

---

## 9. Mobile interaction

- Large forms — keyboard / scroll overlap; IME normalization in `lib/stakingAmountInput.ts` — **keep** for consistency.
- Touch targets on chips and refresh — minimum 44px (design system check).

---

## 10. Gaps & recommendations

| Priority | Item |
|----------|------|
| Low | Document “when balance vs history loading” for support |
| Medium | Visual pass: fee skeleton parity deposit/withdraw |
| Medium | Long history lists — consider virtualized list **only** after Profiler proof (not P1) |
| Frozen | Do not move wrong-network or refresh semantics between planes |

---

*Phase P1 — report only.*
