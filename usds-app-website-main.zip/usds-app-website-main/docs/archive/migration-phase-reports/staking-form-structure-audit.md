# Staking form structure audit — Deposit & Withdraw

**Date:** 2026-05-16  
**Scope:** Visual/layout structure only (`StakingAppDepositForm`, `StakingAppWithdrawForm`, shared staking form chrome).  
**Out of scope:** Tx/runtime/history/orchestrator logic, refactors, UI changes.

**Validation:** `pnpm typecheck` ✅ · `pnpm build` ✅ (doc-only change; build re-run after write).

---

## 1. Top-level visual hierarchy

### 1.1 Shell above the forms

| Layer | Component | File | Notes |
|-------|-----------|------|-------|
| Page column | `StakingApp` → `Frame` + `STAKING_FORM_LIQUID_PANEL` | `StakingApp.tsx`, `stakingGlassPanel.ts` | Right column; glass shell only — no form slots inside |
| Tab host | `StakingAppForm` | `StakingAppForm.tsx` | `role="tablist"` Stake / Unstake; `mt-4` then **one** child form |
| Form root | `StakingFormLayout` | `StakingFormLayout.tsx` | `body` + `footer`; natural-height column (no flex-fill / scroll) |

**Tab behavior (mount/unmount):**

```tsx
{mode === "deposit" ? (
  <StakingAppDepositForm ... />
) : (
  <StakingAppWithdrawForm />
)}
```

- **Visibility:** conditional **mount** — switching tabs **unmounts** the inactive form entirely.
- **Height impact:** entire form subtree resets; no cross-tab height reservation.

### 1.2 Shared block order (both forms)

Both forms use the same vertical contract inside `StakingFormLayout.body`:

```
StakingFormSlotAsset          → token/network selector
StakingFormSlotMeta           → metrics / balance meta row
StakingFormSlotAmount         → amount input (+ optional Max)
StakingFormSlotSlider         → slider + Min/Max labels
<section>                     → fee/receive/(profit) + CTA reason
StakingFormLayout.footer      → primary GlowingButton CTA
```

ASCII map:

```
┌─ StakingAppForm (tabs) ─────────────────────────┐
│  [Stake] [Unstake]                             │
│  ┌─ StakingFormLayout ────────────────────────┐ │
│  │ body:                                       │ │
│  │   Asset select                              │ │
│  │   Meta row  ◄── PRIMARY LAYOUT DIVERGENCE   │ │
│  │   Amount input                              │ │
│  │   Slider                                    │ │
│  │   Action summary + StakingCtaReason         │ │
│  │ footer:                                     │ │
│  │   GlowingButton (min-h inner 22px)          │ │
│  └─────────────────────────────────────────────┘ │
└────────────────────────────────────────────────┘
```

---

## 2. Section-by-section map

### 2.1 Tabs

| | Deposit | Withdraw |
|---|---------|----------|
| **Owner** | `StakingAppForm` | same |
| **Path** | `src/components/pages/staking/StakingAppForm.tsx` | same |
| **Conditional** | `mode === "deposit"` selects child | `mode === "withdraw"` |
| **Typography** | `STAKING_SEGMENT_LIQUID_*` + `font-mono text-gray-500` idle | same |
| **Spacing** | `p-4 sm:p-6` shell; `gap-0.5` tab track; `mt-4` before form | same |
| **Height** | Content-sized tabs; no fixed tab height | same |
| **Mount** | Inactive form **unmounted** | same |

---

### 2.2 Token selector (asset row)

| | Deposit | Withdraw |
|---|---------|----------|
| **Wrapper** | `StakingFormSlotAsset` | same |
| **Component** | `StakingDepositAssetSelect` | `StakingWithdrawAssetSelect` |
| **Implementation** | `StakingAssetSelectSubtree` `variant="deposit"` | `variant="withdraw"` |
| **Path** | `StakingAssetSelectSubtree.tsx` | same |

**Slot spacing:** `shrink-0 min-w-0 pb-3` (`stakingFormSlots.tsx`).

**Conditional rendering:**

| State | Behavior |
|-------|----------|
| `showAssetSkeleton` | Early return: label + non-interactive shell with 3× `Skeleton` (icon `size-5`, text bars `h-3.5` / `h-3`) inside `STAKING_SELECT_TRIGGER` |
| else | Live `Select` + `SelectTrigger` / `SelectContent` |

`showAssetSkeleton` logic differs by chain (Tron vs EVM wallet readiness) — see `StakingAssetSelectSubtree.tsx` L90–118.

**Typography:**

- Label: `text-xs font-light text-neutral-600`
- Item label: `truncate text-neutral-800`
- Item meta: `text-[11px] font-normal leading-none text-neutral-400`

**Trigger height contract:** `STAKING_SELECT_TRIGGER` = `STAKING_INPUT_BASE` → `h-11 min-h-11` (mobile), `sm:h-9 sm:min-h-9` (`stakingInputStyles.ts`). Skeleton branch uses the **same** trigger classes → **stable asset-row height** skeleton ↔ loaded.

**Deposit vs withdraw:** Only copy differs (`"Token to stake"` vs `"Token to withdraw"`); layout identical.

---

### 2.3 Metrics / info row (`StakingFormSlotMeta`)

| | Deposit | Withdraw |
|---|---------|----------|
| **Slot** | `StakingFormSlotMeta` | same |
| **Path** | `stakingFormSlots.tsx` L33–38 | same |
| **Slot classes** | `flex min-h-3 min-w-0 shrink-0 flex-col justify-center pb-1` | same |

> **Stability note:** Slot declares `min-h-3` (12px) while child meta rows use `min-h-5` (20px). The slot does **not** reserve the child’s line height; children dictate height.

#### Deposit — single branch

| | |
|---|---|
| **Component** | `StakingFormBalanceMetaRow` |
| **Path** | `StakingFormBalanceMetaRow.tsx` |
| **Always mounted** | Yes — no ternary wrapper |

**Props / conditionals:**

| Prop | Source |
|------|--------|
| `prefix` | `'Assets:'` |
| `applyGasColumn` | `applyEvmNetworkAndGasCtaBlocks` |
| `showDisconnectedDash` | `applyEvmNetworkAndGasCtaBlocks && !executionConnected` |
| `tokenSkeleton` | `formNumericLoading` |
| `nativeAmount` | `displayNativeGasAmount` — `null` → gas skeleton |

`formNumericLoading` (`StakingAppDepositForm.tsx` L601–604):

```ts
applyEvmNetworkAndGasCtaBlocks
  ? executionConnected && !isWrongNetwork && !vaultDataReady
  : !vaultDataReady
```

**Typography (owned by `StakingFormBalanceMetaRow`):**

- Row: `text-[11px] leading-5` → `sm:text-xs sm:leading-5`, `min-h-5`, `tabular-nums`
- Prefix: `font-normal text-muted-foreground`
- Token amount: `font-medium text-foreground tabular-nums`
- Symbol: `font-mono text-[11px] font-extralight text-gray-400 sm:text-xs`

**Skeleton:**

- Token: `META_SKELETON_CLASS` + `w-29` → `h-5 max-h-5 min-h-5`
- Gas: same + `w-22` when `nativeAmount === null`

**Em dash (`—`):** token column only when `showDisconnectedDash` (EVM disconnected).

**Gas column visibility:** `showGasColumn = applyGasColumn && !showDisconnectedDash` — column **not rendered** when disconnected (not a spacer).

---

#### Withdraw — three branches (primary divergence)

**Path:** `StakingAppWithdrawForm.tsx` L1400–1458.

| Branch | Condition | UI | Gas column |
|--------|-----------|-----|------------|
| A — loading | `formNumericLoading` | `StakingFormBalanceMetaRow`, `tokenSkeleton`, `tokenAmount={ZERO_AMOUNT_DISPLAY}` | Yes (EVM) — same as deposit loading |
| B — constraints | `withdrawAmountMeta.kind === "constraints"` | **Inline** `div.grid grid-cols-2` (not `StakingFormBalanceMetaRow`) | **No** — entire right column absent |
| C — withdrawable | else | `StakingFormBalanceMetaRow`, `prefix='Withdrawable:'`, `tokenSkeleton={false}` | Yes (EVM) |

`withdrawAmountMeta` (`L238–260`):

- Disconnected → `kind: "constraints"` with placeholder segments `Max now — ${label}` / optional `Min — ${label}`
- Connected + `withdrawConstraintsHint` → constraints with real max/min copy
- Else → `kind: "withdrawableOnly"` (unused in JSX — branch C uses formatted max)

**Constraints grid typography (duplicated, not shared):**

```tsx
className='grid min-w-0 grid-cols-2 items-center gap-x-2 px-1 ps-2 text-[11px] leading-snug text-muted-foreground tabular-nums sm:text-xs sm:gap-x-3'
```

- Values: `font-medium text-foreground`, `truncate`
- Empty segment fallback: `\u00A0` (NBSP), not `—`
- **No `min-h-5`** on row container
- **`leading-snug`** vs meta row **`leading-5`** → line box can differ

**Em dash:** Not used in constraints branch. `StakingFormBalanceMetaRow` `—` only in branches A/C when `showDisconnectedDash`.

---

### 2.4 Amount input

| | Deposit | Withdraw |
|---|---------|----------|
| **Slot** | `StakingFormSlotAmount` (`pb-5`) | same |
| **Control** | `Input` from `@/components/ui/input` | same |
| **Wrapper** | `space-y-1` → `relative` | same |

**Shared chrome:** `STAKING_INPUT_*` from `src/staking/ui/stakingInputStyles.ts`

- Base: `h-11 min-h-11` / `sm:h-9 sm:min-h-9`, `text-base` / `sm:text-sm`
- Error: `STAKING_INPUT_ERROR` when connected + validation fail
- View-only: passive Tron `STAKING_INPUT_VIEW_ONLY`

**Conditional Max button:**

| | Deposit | Withdraw |
|---|---------|----------|
| `showAmountMaxButton` | `executionConnected && vaultDataReady && !isWrongNetwork && canTransact` | same **plus** `maxUnstakeWei > 0n && minAmountWei <= maxUnstakeWei` |
| Mount | `{showAmountMaxButton ? <button>Max</button> : null}` | same — **mount/unmount** (adds `pe-14` padding when visible) |

**Deposit-only:** `amountFocusHighlight` border class; `focusAmountRequest` refocus effect; `id='staking-deposit-amount'`.

**Withdraw-only:** `aria-invalid` also includes `belowMinWithdrawal`; `onBlur` calls `flushEstimate()` (deposit does not on blur).

**Skeleton:** None on input — disabled/readonly states only.

---

### 2.5 Slider

| | Deposit | Withdraw |
|---|---------|----------|
| **Slot** | `StakingFormSlotSlider` (`min-w-0 shrink-0 px-1 pb-2`) | same |
| **Inner** | `StakingFormSlotSliderInner` → `STAKING_FORM_V_SLIDER_STACK` (`flex flex-col gap-1.5`) | same |
| **Control** | Radix `Slider` | same |
| **Visual classes** | `STAKING_AMOUNT_SLIDER_*` (`stakingAmountSliderVisual.ts`) | same |
| **Labels** | `flex justify-between text-xs font-medium text-muted-foreground` Min/Max | same |

**Spacing contract:**

- Input → slider: `StakingFormSlotAmount` **`pb-5`** (20px).  
- `STAKING_FORM_V_INPUT_TO_SLIDER` (`mt-5`) exists in `StakingFormLayout.tsx` but is **unused** in the codebase.
- Slider → fee block: slider `pb-2` + following `<section>` (no `STAKING_FORM_V_SLIDER_TO_FEE` — also **unused**).

**Disabled logic:**

| | Deposit | Withdraw |
|---|---------|----------|
| `amountSliderDisabled` | `formFieldsDisabled \|\| formInputsReadOnly` | above **+** `maxUnstakeWei <= 0n` **+** `minAmountWei > maxUnstakeWei` **+** `formNumericLoading` |

**Deposit-only:** `sliderActive` state; pointer capture sets `gasStableWei` on pointer up (no `flushEstimate` on slider up).

**Withdraw-only:** `flushEstimate()` on slider pointer up and input blur.

**Height:** Slider root `py-1.5`; track `h-2.5`; thumb `size-[24px]` — shared, stable when mounted.

---

### 2.6 Fee / receive / profit rows

| | Deposit | Withdraw |
|---|---------|----------|
| **Wrapper** | `<section className='flex w-full min-w-0 shrink-0 flex-col'>` | same (aria-label differs) |
| **Slot** | `StakingFormSlotFeeRows` + `STAKING_FORM_V_FEE_TO_STATUS` (`gap-0.5`) | same |
| **Summary** | `StakingFormActionSummaryDeposit` | `StakingFormActionSummaryWithdraw` |
| **Path** | `StakingFormActionSummary.tsx` | same |
| **Reason line** | `StakingCtaReason` `id='staking-deposit-cta-reason'` | `id='staking-withdraw-cta-reason'` |

**Row geometry (shared):**

- Stack: `gap-px`
- Each row: `h-4 min-h-4` flex justify-between
- Labels: `text-[11px] font-normal` (fee/profit `gray-400`, receive `gray-500`)

**Conditional rows:**

| Row | Deposit | Withdraw |
|-----|---------|----------|
| Network **Fee** | `showNetworkFeeRow={applyEvmNetworkAndGasCtaBlocks}` — row **unmounted** on passive Tron | same |
| **Receive** | skeleton when `receiveLoading`; ghost via `opacity-0` + NBSP | same + `withdrawReceiveLoading` for protocol fee |
| **Profit** | Live text or skeleton; label/value `opacity-0` when empty | **Inert** third row: `aria-hidden`, always `opacity-0` + NBSP — **mounted for height parity** |

**Skeleton sizes** (`src/lib/stakingFeeValueSkeleton.ts`):

- Fee value: `STAKING_SUMMARY_FEE_VALUE_SKELETON` → `h-2.5`, max width ~6.75rem
- Receive/profit: `STAKING_SUMMARY_INLINE_VALUE_SKELETON` → `h-2.5`, max width ~5rem

**Placeholders:** Empty fee/receive use `\u00A0` inside `h-4` rows (not `—`).

**Line-count mismatch:** Withdraw keeps a **third** Profit row (hidden) so stack height matches deposit; when `showNetworkFeeRow` is false, **both** drop to 2 visible rows (Receive + hidden Profit).

---

### 2.7 CTA reason + primary button

| | Deposit | Withdraw |
|---|---------|----------|
| **Reason** | `StakingCtaReason` | same |
| **Path** | `StakingCtaReason.tsx` | same |
| **Reserved height** | `min-h-5` outer; icon gutter `size-3.5`; text `text-xs leading-tight truncate` | same |
| **Empty state** | NBSP + `opacity-0` (row still occupies space) | same |
| **Loading glyph** | `Skeleton` `size-3.5 rounded-full` for loading-like messages | same |

**Footer slot:** `STAKING_FORM_FOOTER_CLASS` = `px-1 pt-2` (`StakingFormLayout.tsx`).

**CTA:** `GlowingButton` + `STAKING_PRIMARY_CTA_BUTTON_CLASS` / passive variant (`stakingFormSlots.tsx`):

- Mobile: `h-12 min-h-12 max-h-12`
- `sm:`: `h-10 min-h-10 max-h-10`
- Label wrapper: `min-h-[22px]`; spinner absolutely centered (no CTA height change)

**Reason visibility vs CTA position:** `StakingCtaReason` always rendered in footer stack; empty reason is invisible but **reserves `min-h-5`**. CTA does not move when reason text appears — only reason line content changes.

---

## 3. Metrics row audit (detailed)

### 3.1 Exact deposit vs withdraw differences

| Aspect | Deposit | Withdraw |
|--------|---------|----------|
| Structure | 1× `StakingFormBalanceMetaRow` always | 3-way branch |
| Prefix | `Assets:` | `Withdrawable:` (branches A/C) / none (branch B) |
| Disconnected UX | `—` in token column (EVM) | Constraints grid with `Max now — {symbol}` placeholders |
| Constraints UX | N/A | 2-column grid; max left, min right |
| Line height | `leading-5` + `min-h-5` | `leading-snug`, no row `min-h-5` in grid |
| EVM gas column | Hidden when disconnected; skeleton when `nativeAmount === null` | Present in A/C; **absent** in constraints branch B |
| Loading | `tokenSkeleton={formNumericLoading}` | Branch A: same; B/C: no skeleton on token in C |

### 3.2 Where line-count mismatch occurs

- **Not** in action summary Profit row (withdraw already mirrors height with inert row).
- **Yes** in **meta slot**:
  - Deposit: always **one** flex row (prefix + token [| gas]).
  - Withdraw constraints: **one** grid row but **two** text columns, different metrics semantics, **no gas**.
- **Fee row:** `showNetworkFeeRow` removes one `h-4` row on Tron — affects both forms equally.

### 3.3 Height instability origins (ranked)

1. **Withdraw meta branch swap** (`StakingFormBalanceMetaRow` ↔ constraints `grid`) — different layout, line-height, and gas column presence.
2. **`StakingFormSlotMeta` `min-h-3`** — under-reserves vs `min-h-5` meta content.
3. **Gas column mount/unmount** — EVM connected ↔ disconnected; withdraw constraints drop gas entirely.
4. **Tab switch** — full form unmount/remount.
5. **Asset skeleton ↔ select** — mitigated by shared `STAKING_SELECT_TRIGGER` height.
6. **Max button mount** — input gains/loses `pe-14` (width only, not vertical).
7. **`showNetworkFeeRow`** — removes one summary row (both forms).
8. **Token hydration** — `formNumericLoading` toggles skeleton in meta row (both forms); withdraw also swaps branch when constraints appear.
9. **CTA reason** — low risk; fixed `min-h-5`.
10. **Summary skeletons** — `h-2.5` inside `h-4` rows; stable by design.

### 3.4 Em dash and placeholder map

| Location | Character | Condition |
|----------|-----------|-----------|
| `StakingFormBalanceMetaRow` token area | `—` | `showDisconnectedDash` |
| Constraints grid empty segment | `\u00A0` | missing max/min segment |
| Action summary empty values | `\u00A0` | `FeeValueCell` / receive / profit empty |
| `StakingCtaReason` empty | `\u00A0` | no reason |

### 3.5 Skeleton dimension comparison

| Surface | Height | Width classes |
|---------|--------|----------------|
| Meta token | `h-5` | `w-29` |
| Meta gas | `h-5` | `w-22` |
| Summary fee | `h-2.5` | `w-[min(100%,6.75rem)]` |
| Summary receive/profit | `h-2.5` | `w-[min(100%,5rem)]` |
| Asset select | `size-5` + `h-3.5` / `h-3` bars | — |
| CTA reason loading | `size-3.5` | circular |

Meta row skeletons are **taller** (`h-5`) than summary skeletons (`h-2.5`) — intentional per row type.

---

## 4. Shared vs duplicated UI

### 4.1 Shared primitives (use as contracts)

| Primitive | Path |
|-----------|------|
| `StakingFormLayout` + vertical constants | `StakingFormLayout.tsx` |
| Slot wrappers | `stakingFormSlots.tsx` |
| `StakingFormBalanceMetaRow` | `StakingFormBalanceMetaRow.tsx` |
| `StakingAssetSelectSubtree` | `StakingAssetSelectSubtree.tsx` |
| `StakingFormActionSummaryDeposit/Withdraw` | `StakingFormActionSummary.tsx` |
| `StakingCtaReason` | `StakingCtaReason.tsx` |
| Input/slider/select chrome | `src/staking/ui/stakingInputStyles.ts`, `stakingAmountSliderVisual.ts` |
| Summary skeleton tokens | `src/lib/stakingFeeValueSkeleton.ts` |
| Tabs chrome | `stakingGlassPanel.ts` (`STAKING_SEGMENT_LIQUID_*`) |

### 4.2 Duplicated typography / spacing

| Duplication | Where |
|-------------|-------|
| Meta row text scale | `StakingFormBalanceMetaRow` `ROW_CLASS` vs withdraw constraints grid inline classes (near-copy, `leading-snug` drift) |
| `ZERO_AMOUNT_DISPLAY` | Both form files locally (`"0.000000"`) |
| Amount block | Identical `space-y-1`, Max button classes, input className wiring |
| Slider Min/Max row | Identical `text-xs font-medium text-muted-foreground` |
| CTA footer | Near-identical `GlowingButton` block |
| Unused rhythm tokens | `STAKING_FORM_V_INPUT_TO_SLIDER`, `STAKING_FORM_V_SLIDER_TO_FEE` exported but unused |
| Unused glass wells | `STAKING_FORM_INPUT_WELL`, `STAKING_FORM_ACTION_WELL` in `stakingGlassPanel.ts` (not wired to forms) |

### 4.3 Duplicated skeleton patterns

- Meta skeletons centralized in `StakingFormBalanceMetaRow`.
- Summary skeletons centralized in `StakingFormActionSummary` + `stakingFeeValueSkeleton.ts`.
- Asset skeleton inline in `StakingAssetSelectSubtree` only.

---

## 5. Layout stability risks

| Risk | Severity | Forms | Mechanism |
|------|----------|-------|-----------|
| Withdraw meta 3-branch swap | **High** | Withdraw | Different component types + gas column dropped in constraints |
| `leading-snug` vs `leading-5` | **Medium** | Withdraw | Constraints grid shorter/taller line box |
| `StakingFormSlotMeta min-h-3` | **Medium** | Both | Slot comment claims fixed height; 12px ≠ 20px content |
| Tab unmount | **Medium** | Both | No preserved layout between Stake/Unstake |
| Gas column conditional | **Medium** | Both (esp. withdraw B) | Column removed from DOM |
| `showNetworkFeeRow` | **Low–Med** | Both | −1 row on Tron |
| Max button + `pe-14` | **Low** | Both (stricter withdraw) | Horizontal only |
| Long constraint strings | **Low** | Withdraw | `truncate` on grid cells — ellipsis not wrap |
| `formNumericLoading` | **Low** | Both | Skeleton ↔ text in shared meta component |
| Receive/profit loading | **Low** | Both | Fixed `h-4` rows |
| Slider disabled churn | **Low** | Withdraw | Extra disable conditions |

### 5.1 CTA movement sources

- **Unlikely:** `StakingCtaReason` `min-h-5`, CTA `min-h-[22px]` inner, fixed button `h-12`/`h-10`.
- **Likely indirect:** Anything above CTA in body (meta, summary rows) shifts footer down as a block — not CTA-internal jumping.

### 5.2 Slider anchor instability

- Slider position in tree is stable (always after amount, before fee section).
- Vertical drift comes from **meta row height changes above**, not slider slot classes changing.

---

## 6. Visual source of truth

**Treat `StakingAppDepositForm` meta row + `StakingFormBalanceMetaRow` as the canonical metrics contract.**

Reasons:

- Single component, no branch swapping.
- Explicit `min-h-5` / `leading-5` / `tabular-nums`.
- Documented skeleton ↔ value parity (`StakingFormBalanceMetaRow` header comment).
- Predictable EVM gas column rules (hidden when disconnected, skeleton when loading).

Withdraw should be aligned **to deposit**, not the reverse — especially the constraints grid branch.

---

## 7. Safe-fix recommendation (presentation-only, minimal blast radius)

**Do not** add a shared metrics-row component or refactor orchestration.

### Recommended smallest fix (ordered)

1. **`StakingFormSlotMeta`** (`stakingFormSlots.tsx`): change `min-h-3` → `min-h-5` (or `min-h-[1.25rem]`) so the slot reserves one meta line everywhere.  
   - Blast radius: both forms, one line.  
   - Preserves deposit appearance; may add ≤8px empty space when empty (rare).

2. **Withdraw constraints branch only** (`StakingAppWithdrawForm.tsx` L1414–1442):  
   - Apply `StakingFormBalanceMetaRow`’s `ROW_CLASS` typography: `leading-5`, `min-h-5`, matching padding.  
   - Keep 2-column grid content (no logic change).  
   - **Optional but high value:** when `applyEvmNetworkAndGasCtaBlocks && !showDisconnectedDash`, render a **fixed-width right column** for gas (reuse `StakingFormBalanceMetaRow` gas cell or empty `min-h-5` spacer) so constraints mode does not drop the gas column.

3. **Avoid** for now: tab keep-alive, new abstractions, `STAKING_FORM_INPUT_WELL` wiring, changing action summary structure.

### Not recommended (overengineering)

- New `StakingFormMetricsRow` shared component wrapping deposit + withdraw + constraints — withdraw’s constraints UX is **semantic**, not just styling; forcing one component increases conditional API surface without fixing branch count.
- Normalizing `withdrawAmountMeta` state machine in this pass — behavior change risk.

---

## 8. File index (quick reference)

| File | Role |
|------|------|
| `StakingAppForm.tsx` | Tabs + form switch |
| `StakingAppDepositForm.tsx` | Deposit body/footer JSX |
| `StakingAppWithdrawForm.tsx` | Withdraw body/footer JSX + meta branches |
| `StakingFormLayout.tsx` | Root/body/footer layout |
| `stakingFormSlots.tsx` | Slot spacing + CTA button classes |
| `StakingFormBalanceMetaRow.tsx` | Metrics row (deposit + withdraw A/C) |
| `StakingFormActionSummary.tsx` | Fee/receive/profit rows |
| `StakingAssetSelectSubtree.tsx` | Asset select + skeleton |
| `StakingCtaReason.tsx` | Inline status above CTA |
| `stakingInputStyles.ts` / `stakingAmountSliderVisual.ts` | Input & slider chrome |
| `stakingFeeValueSkeleton.ts` | Summary skeleton dimensions |
| `stakingGlassPanel.ts` | Tab/panel glass (not form slots) |

---

## 9. Validation summary (post-audit)

| Check | Result |
|-------|--------|
| `pnpm typecheck` | Pass |
| `pnpm build` | Pass |

### Executive answers

1. **Exact source of height shifting:** Withdraw `StakingFormSlotMeta` switching between `StakingFormBalanceMetaRow` (`min-h-5`, optional gas column) and the inline **constraints** `grid` (`leading-snug`, no `min-h-5`, no gas column), compounded by `StakingFormSlotMeta`’s `min-h-3` under-reservation and EVM gas column mount/unmount. Tab unmount is a secondary whole-form shift.

2. **Smallest safe fix:** Bump meta slot to `min-h-5` + align constraints grid classes to `StakingFormBalanceMetaRow` row metrics (and optionally preserve gas column width in constraints mode). No new components.

3. **Visual source-of-truth:** `StakingAppDepositForm` / `StakingFormBalanceMetaRow`.

4. **Shared metrics-row component justified?** **No** for stabilization only — typography alignment on the existing constraints branch is sufficient; a shared component would duplicate branching already in withdraw logic and risks behavior coupling.
