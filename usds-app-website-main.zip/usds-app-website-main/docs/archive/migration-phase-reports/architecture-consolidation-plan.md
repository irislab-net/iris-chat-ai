# Architecture consolidation plan — Phase A+ (planning only)

**Prerequisite:** `docs/architecture-consolidation-census.md` (complete inventory).

**Constraint:** Phases below are **planning only**. No cleanup/refactor/move/rename/delete until each phase is explicitly approved and soak-gated where noted.

**Date:** 2026-05-15

---

## 1. Goals

1. Reduce **entropy** in vault, forms, and tx stack without breaking production-frozen runtime coordinator behavior.
2. Establish **clear module boundaries**: runtime kernel, identity, execution, orchestration, tx, UI, diagnostics.
3. Remove **temporary bridges** only after measurable stability (soak + zero DEV bridge reads).
4. Eliminate **layer inversion** (core → UI types, lib → hooks).

---

## 2. Non-goals (explicit)

- Changing swap/coordinator **semantics** or persistence **format** without a dedicated phase.
- Removing `useAppKitEvmIsolationOnPassiveTron` or Tron passive read path.
- Big-bang rewrite of deposit/withdraw forms in a single PR.
- Production behavior change from DEV-only soak/telemetry modules.

---

## 3. Phase overview

| Phase | Name | Type | Blast radius | Destructive? |
| ----- | ---- | ---- | ------------- | ------------ |
| **A** | Census + plan | Docs only | None | No |
| **B** | Type extraction + boundaries | Refactor (neutral types) | Medium | No |
| **C** | Physical `lib/staking` → `staking/*` (re-exports) | Move + aliases | Medium | No |
| **C1** | Identity layer move | Move + shims | Low | No — **complete** |
| **C2** | Orchestration layer move | Move + shims | Medium | No — **complete** |
| **D** | Vault decomposition (internal modules) | Refactor | **High** | No |
| **E** | Form shared layer | Refactor | High | No |
| **F** | Identity / navbar contract | Refactor | Medium | No |
| **G** | Deprecated bridge removal | Delete exports | Medium | **Yes** |
| **H** | UI relocation (optional) | Move | Medium | No |
| **I** | Legacy shim removal | Delete | Low | **Yes** |

---

## 4. Phase B — Neutral type extraction

### 4.1 Objectives

- Move `TransactionStatusUiPhase` (and minimal snapshot types needed by policy) out of `components/pages/staking/transactionStatusModel.ts` into `src/staking/tx/` or `src/lib/staking/txPhaseTypes.ts`.
- Change `runtimeSwapPolicy.ts` to import from neutral module only.
- Change `stakingFormInlineReasonResolver.ts` to import **types** from `staking/cta` types file, not `useStakingCtaState` hook.

### 4.2 Blast radius

- **Files touched:** ~8–12
- **Runtime-critical:** `runtimeSwapPolicy.ts`, `runtimeSwapEngine.ts` (import path only)
- **Risk:** Type-only; must not change swap admission outcomes

### 4.3 Rollback strategy

- Single revert commit; keep re-export from old paths for one release if needed:
  `export type { TransactionStatusUiPhase } from '@/staking/tx/types'`

### 4.4 Commit strategy

- One PR: `refactor(staking): extract tx phase types for runtime policy`
- No behavior change; `pnpm typecheck` + `pnpm build` required

### 4.5 Verification

- [ ] `pnpm typecheck`
- [ ] `pnpm build`
- [ ] Manual: runtime swap while tx modal in `preview` still blocked by policy
- [ ] DEV: run swap stress harness smoke (`VITE_RUNTIME_SWAP_STRESS`) if enabled locally

### 4.6 Soak requirements

- **None** before merge (non-destructive).
- Run **5 min stable** soak on `/staking/app` after merge on main dev branch (baseline for later phases).

---

## 5. Phase C — `lib/staking` physical consolidation (re-export first)

### 5.1 Objectives

- Create `src/staking/{identity,orchestration,execution,diagnostics,tx}/` folders.
- **Move** files with **barrel re-exports** at old paths (`@/lib/staking/...` → forward to new paths).
- No logic changes in first PR per subdirectory.

### 5.2 Suggested move batches

| Batch | Files | New home |
| ----- | ----- | -------- |
| C1 | `stakingRuntimeWalletIdentity*`, `stakingNavbarVisualHold`, `stakingPassiveRuntimeUx` | `staking/identity/` |
| C2 | `stakingRefreshOrchestrator`, `stakingRefreshMetrics`, `stakingMobileResumeCoordinator` | `staking/orchestration/` |
| C3 | `stakingReadFactory`, `stakingReadProviders`, `ethUsdPriceCache` | `staking/execution/` |
| C4 | `stakingTxSessionPersistence`, `stakingTxOnChainRecovery`, `stakingTxExplorerFromDeployment` | `staking/tx/` |
| C5 | `stakingRuntimeSoak*`, `stakingVault*Dev`, `stakingRuntimeExecutionPlaneTelemetry` | `staking/diagnostics/` |

### 5.3 Blast radius

- Import path churn across vault, forms, services
- Mitigate with re-export shims at `@/lib/staking/*` for ≥1 release

### 5.4 Rollback strategy

- Revert batch PR; shims mean old imports still work if revert is immediate

### 5.5 Commit strategy

- **One batch per PR** (C1…C5), each: `chore(staking): move <area> to staking/<area> with re-exports`
- Final PR (optional): `chore(staking): update imports to new paths` (wide diff)

### 5.6 Verification

- [ ] `pnpm typecheck` + `pnpm build` after each batch
- [ ] Grep: no duplicate module instances (singleton orchestrator still single)

### 5.7 Soak requirements

- After **C2** (orchestrator): **5 min stable** soak; watch `hydration_stall`, `vault_ready` events
- After **C4** (tx persistence): connect → preview tx → cancel; confirm persistence read/write

---

## 5a. Phase C1 — Identity layer (complete)

**Status:** Complete (move-only; backward-compatible shims retained).

### Moved implementations

| New path | Former path |
| -------- | ----------- |
| `src/staking/identity/stakingRuntimeWalletIdentity.ts` | `src/lib/staking/stakingRuntimeWalletIdentity.ts` |
| `src/staking/identity/stakingRuntimeWalletIdentityBridge.ts` | `src/lib/staking/stakingRuntimeWalletIdentityBridge.ts` |
| `src/staking/identity/stakingNavbarVisualHold.ts` | `src/lib/staking/stakingNavbarVisualHold.ts` |
| `src/staking/identity/stakingPassiveRuntimeUx.ts` | `src/lib/staking/stakingPassiveRuntimeUx.ts` |
| `src/staking/identity/tron/resolveUnifiedTronIdentity.ts` | `src/lib/tron/resolveUnifiedTronIdentity.ts` |
| `src/staking/identity/index.ts` | (new barrel) |

### Old-path re-export shims (still valid)

| Shim path | Re-exports from |
| --------- | --------------- |
| `src/lib/staking/stakingRuntimeWalletIdentity.ts` | `@/staking/identity/stakingRuntimeWalletIdentity` |
| `src/lib/staking/stakingRuntimeWalletIdentityBridge.ts` | `@/staking/identity/stakingRuntimeWalletIdentityBridge` |
| `src/lib/staking/stakingNavbarVisualHold.ts` | `@/staking/identity/stakingNavbarVisualHold` |
| `src/lib/staking/stakingPassiveRuntimeUx.ts` | `@/staking/identity/stakingPassiveRuntimeUx` |
| `src/lib/tron/resolveUnifiedTronIdentity.ts` | `@/staking/identity/tron/resolveUnifiedTronIdentity` |

**Singleton note:** `stakingRuntimeWalletIdentityBridge` module state (`published`, `listeners`) lives in **one** implementation file under `staking/identity/`; shims re-export functions only — no duplicate store.

### C1 verification

- [x] `pnpm typecheck`
- [x] `pnpm build`
- [x] Old `@/lib/staking/stakingRuntimeWalletIdentity*` import paths resolve via shims
- [x] No call-site migration required in this phase
- [ ] Manual: navbar wallet chip on `/staking/app`; identity publish on vault mount (recommended smoke)

**Next:** Phase C2 — orchestration batch (`stakingRefreshOrchestrator`, etc.).

---

## 5b. Phase C2 — Orchestration layer (complete)

**Status:** Complete (move-only; backward-compatible shims retained).

**Note:** Source paths differ from early plan labels — implementations were moved from their **actual** locations (`src/lib/wallet/`, `src/hooks/`, `src/staking/core/`, `src/staking/dev/`).

### Moved implementations

| New path | Former path |
| -------- | ----------- |
| `src/staking/orchestration/openUnifiedWallet.ts` | `src/lib/wallet/openUnifiedWallet.ts` |
| `src/staking/orchestration/useUnifiedWalletOrchestration.ts` | `src/hooks/useUnifiedWalletOrchestration.ts` |
| `src/staking/orchestration/runtimeTransitionCoordinator.ts` | `src/staking/core/runtimeTransitionCoordinator.ts` |
| `src/staking/orchestration/runtimeTransitionSequence.ts` | `src/staking/core/runtimeTransitionSequence.ts` |
| `src/staking/orchestration/runtimeSwapEngine.ts` | `src/staking/core/runtimeSwapEngine.ts` |
| `src/staking/orchestration/runtimeSwapPolicy.ts` | `src/staking/core/runtimeSwapPolicy.ts` |
| `src/staking/orchestration/runtimeLifecycleAssertions.ts` | `src/staking/dev/runtimeLifecycleAssertions.ts` |
| `src/staking/orchestration/index.ts` | (new barrel) |

**Not moved (per plan):** `runtimeSelectionContext.tsx`, `RuntimeSelectionProvider`, `runtimeTransitionController.ts`.

### Old-path re-export shims

| Shim path | Re-exports from |
| --------- | --------------- |
| `src/lib/wallet/openUnifiedWallet.ts` | `@/staking/orchestration/openUnifiedWallet` |
| `src/hooks/useUnifiedWalletOrchestration.ts` | `@/staking/orchestration/useUnifiedWalletOrchestration` (+ wallet types from `openUnifiedWallet`) |
| `src/staking/core/runtimeTransitionCoordinator.ts` | `@/staking/orchestration/runtimeTransitionCoordinator` |
| `src/staking/core/runtimeTransitionSequence.ts` | `@/staking/orchestration/runtimeTransitionSequence` |
| `src/staking/core/runtimeSwapEngine.ts` | `@/staking/orchestration/runtimeSwapEngine` |
| `src/staking/core/runtimeSwapPolicy.ts` | `@/staking/orchestration/runtimeSwapPolicy` |
| `src/staking/dev/runtimeLifecycleAssertions.ts` | `@/staking/orchestration/runtimeLifecycleAssertions` |

### Singleton / module state safety

| Module | Mutable state | Location |
| ------ | ------------- | -------- |
| `runtimeSwapPolicy` | `txModalSurfaceGetter`, `devStressTxModalSurfaceOverride` | **Single** implementation in `staking/orchestration/runtimeSwapPolicy.ts` |
| `runtimeTransitionCoordinator` | Pure functions only | N/A |
| `runtimeSwapEngine` | Pure protocol | N/A |
| `openUnifiedWallet` | No module singletons | N/A |

Shims are **re-export only** — no duplicate coordinator or tx-modal policy state.

### Internal import rewrites (orchestration package only)

- `useUnifiedWalletOrchestration` → `@/staking/orchestration/openUnifiedWallet`
- `runtimeTransitionCoordinator` → `@/staking/orchestration/runtimeTransitionSequence`
- `runtimeSwapEngine` → `@/staking/orchestration/runtimeSwapPolicy` + `runtimeTransitionSequence`
- `runtimeLifecycleAssertions` — unchanged deps on `staking/core/*`, `lib/staking/*` (orchestrator)

Consumers still import `@/staking/core/runtimeTransitionCoordinator` etc.; shims forward to orchestration.

### C2 verification

- [x] `pnpm typecheck`
- [x] `pnpm build`
- [x] Old `@/staking/core/*` and `@/hooks/useUnifiedWalletOrchestration` paths resolve
- [ ] Manual: runtime swap (DEV picker); tx modal open during swap denied; `[runtime-transition]` / `[runtime-swap]` DEV traces

**Next:** Phase D — vault decomposition (`useStakingVault` split).

---

## 5e. Phase C5 — Diagnostics layer (complete)

**Status:** Complete (move-only; backward-compatible shims retained).

### Moved implementations

| Implementation | Shim(s) |
| -------------- | ------- |
| `staking/diagnostics/stakingRuntimeSoakMonitor.ts` | `@/lib/staking/stakingRuntimeSoakMonitor` |
| `staking/diagnostics/stakingRuntimeSoakAnalysis.ts` | `@/lib/staking/stakingRuntimeSoakAnalysis` |
| `staking/diagnostics/stakingRuntimeSoakTypes.ts` | `@/lib/staking/stakingRuntimeSoakTypes` |
| `staking/diagnostics/stakingRuntimeExecutionPlaneTelemetry.ts` | `@/lib/staking/stakingRuntimeExecutionPlaneTelemetry` |
| `staking/diagnostics/stakingVaultDeprecatedFieldDev.ts` | `@/lib/staking/stakingVaultDeprecatedFieldDev` |
| `staking/diagnostics/stakingVaultDeprecatedBridgeDev.ts` | `@/lib/staking/stakingVaultDeprecatedBridgeDev` |
| `staking/diagnostics/stakingVaultSemanticAssertionsDev.ts` | `@/lib/staking/stakingVaultSemanticAssertionsDev` |
| `staking/diagnostics/runtimeCoreLayerBoundaryDev.ts` | `@/staking/core/runtimeCoreLayerBoundaryDev` (side-effect import) |
| `staking/diagnostics/stakingLifecycleInstrumentation.ts` | `@/lib/staking/stakingLifecycleInstrumentation` |
| `staking/diagnostics/stakingTxMobileLifecycleDebug.ts` | `@/lib/stakingTxMobileLifecycleDebug` |

Barrel: `@/staking/diagnostics` (`index.ts`).

### Planned filename not present

| Planned path | Notes |
| ------------ | ----- |
| `lib/staking/wave2StakingLifecycleDev.ts` | **Does not exist** in repo |

### Internal import rewrites (diagnostics package only)

- `stakingRuntimeSoakMonitor` → `@/staking/diagnostics/stakingRuntimeSoakAnalysis` + `stakingRuntimeSoakTypes`
- `stakingRuntimeSoakAnalysis` → `@/staking/diagnostics/stakingRuntimeSoakTypes`
- `stakingVaultDeprecatedBridgeDev` → `@/staking/diagnostics/stakingVaultDeprecatedFieldDev`

### Singleton / window debug API safety

- Soak monitor module singletons (`MAX_EVENTS` ring, health state, contamination counters) live in **one** implementation file
- Window globals unchanged: `__stakingRuntimeSoakDump`, `__printStakingRuntimeHealth`, `__stakingRuntimeLastUnstableSnapshot`
- Soak thresholds unchanged: `HYDRATION_STALL_MS` (10s), `EXECUTION_LEAKAGE_MS` (5s), `RUNTIME_SOAK_ANALYSIS_THRESHOLDS`
- DEV log prefixes unchanged: `[staking-runtime-soak]`, `[staking-vault][runtime-execution-plane]`, `[runtime-core-boundary]`, `stakingLifecycleTrace` channels
- Deprecated vault bridge `warned` Set — single module instance

Shims are **re-export / side-effect forward only** — no duplicate soak or telemetry state.

### Not moved (by design)

- `runtimeSelectionContext`, transition coordinator, swap policy, `useStakingVault`, tx provider, navbar, execution/orchestration modules
- `stakingTxIntegrityDev` (stays `@/lib/staking/stakingTxIntegrityDev`)

### C5 verification

- [x] `pnpm typecheck`
- [x] `pnpm build`
- [x] Legacy `@/lib/staking/*` + `@/lib/stakingTxMobileLifecycleDebug` + `@/staking/core/runtimeCoreLayerBoundaryDev` resolve
- [ ] Manual DEV: `window.__stakingRuntimeSoakDump?.()`, `window.__printStakingRuntimeHealth?.()`; soak/telemetry/boundary traces; swap + disconnect without duplicate events

---

## 5d. Phase C4 — Tx persistence layer (complete)

**Status:** Complete (move-only; backward-compatible shims retained).

### Moved implementations

| Implementation | Shim |
| -------------- | ---- |
| `staking/tx/stakingTxSessionPersistence.ts` | `@/lib/staking/stakingTxSessionPersistence` |
| `staking/tx/stakingTxOnChainRecovery.ts` | `@/lib/staking/stakingTxOnChainRecovery` |

Barrel: `@/staking/tx` (`index.ts` — types from `staking/tx/types/` + persistence/recovery).

### Planned filenames not present (no move; logic unchanged)

| Planned path | Current home |
| ------------ | ------------ |
| `stakingTxRecoveryTypes.ts` | Reconcile context/types in `@/staking/core/persistenceTypes` |
| `stakingTxPersistenceTypes.ts` | Session row types in `stakingTxSessionPersistence.ts` |
| `stakingTxLifecycleDev.ts` | `@/lib/stakingTxMobileLifecycleDebug` (UI-adjacent DEV trace; out of C4 scope) |
| `stakingTxHash.ts` | `deriveCurrentTxHashFromSnapshot` in `transactionStatusModel` |
| `stakingTxToastCopy.ts` | Notification copy in `stakingNotificationSpec` / modal UI |
| `stakingTxPersistKey.ts` | `STAKING_TX_SESSION_STORAGE_KEY` in `stakingTxSessionPersistence.ts` |
| `stakingTxUiPhase.ts` | `@/staking/tx/types/transactionStatusUiPhase` (Phase B) |

`stakingTxExplorerFromDeployment` was moved in **C3** (`staking/execution/`).

### Storage / behavior guarantees (unchanged)

- Session key: `waddle_staking_tx_session_v1` (`STAKING_TX_SESSION_STORAGE_KEY`)
- TTL: `STAKING_TX_SESSION_TTL_MS` (48h)
- v2 write flag: `ENABLE_STAKING_TX_SESSION_V2_WRITE` (default `false`)
- Dual-read v2→v1 compatibility path preserved
- `stakingLifecycleTrace("persistence", …)` labels unchanged (`write`, `clear`, `session_ttl_expired`, `reconcile_*`)
- No duplicate sessionStorage accessors — single module instance via shims

### Not moved (by design)

- `TransactionStatusProvider`, `TransactionStatusSurface`, forms
- `transactionStatusModel` (UI snapshot factory; Phase B types already in `staking/tx/types/`)
- Runtime swap policy, transition coordinator, vault tx execution
- `stakingTxIntegrityDev`, `stakingTxMobileLifecycleDebug`

### C4 verification

- [x] `pnpm typecheck`
- [x] `pnpm build`
- [x] Legacy `@/lib/staking/stakingTxSessionPersistence` / `stakingTxOnChainRecovery` resolve
- [ ] Manual: mid-flow refresh restore; recovery reconcile; runtime swap denied with open tx; DEV `tx_phase_*` / `session_read_*` / `recovery_*` traces

---

## 5c. Phase C3 — Execution layer (complete)

**Status:** Complete (move-only; backward-compatible shims retained).

### Moved implementations

| Implementation | Shim(s) |
| -------------- | ------- |
| `staking/execution/stakingReadFactory.ts` | `@/lib/staking/stakingReadFactory` |
| `staking/execution/stakingReadProviders.ts` | `@/lib/staking/stakingReadProviders` |
| `staking/execution/ethUsdPriceCache.ts` | `@/lib/staking/ethUsdPriceCache` |
| `staking/execution/stakingEtherscanHistory.ts` | `@/lib/stakingEtherscanHistory` |
| `staking/execution/stakingGasEstimator.ts` | `@/services/gasEstimator` |
| `staking/execution/stakingGasToastDedupe.ts` | `@/hooks/useStakingGasToastDedupe` |
| `staking/execution/tronPassiveReads.ts` | `@/lib/tron/tronPassiveReads` |
| `staking/execution/createTronReceiptResolver.ts` | `@/staking/core/createTronReceiptResolver` |
| `staking/execution/stakingTxExplorerFromDeployment.ts` | `@/lib/staking/stakingTxExplorerFromDeployment` |

### Not moved (by design)

- `stakingRefreshOrchestrator`, `useStakingVault`, tx persistence/recovery/lifecycle, runtime coordinator/selection
- `tronReceiptResolver.ts` — **does not exist** in repo; Tron receipts use `createTronReceiptResolverRuntime` via `providerRegistry`

### Singleton / cache preservation

- `stakingReadFactory`: `erc20Cache`, `vaultCache` Maps (single module instance)
- `stakingReadProviders`: WS provider registry + block refs
- `stakingGasEstimator`: gas + native TTL maps keyed by `runtimeKey`
- `stakingEtherscanHistory`: `stakingTransactionHistoryCache` Map
- `ethUsdPriceCache`: presentation singleton + inflight dedupe

Shims are **re-export only** — no duplicate cache Maps.

### C3 verification

- [x] `pnpm typecheck`
- [x] `pnpm build`
- [x] Legacy import paths (`@/lib/staking/stakingReadFactory`, `@/services/gasEstimator`, etc.) resolve via shims
- [ ] Manual: passive Tron reads; gas estimate toast dedupe; Etherscan history load

---

## 6. Phase D — Vault decomposition

### 6.0 Phase D0 — Vault anatomy (complete)

**Status:** Complete (documentation only; no code changes).

**Deliverable:** [`docs/vault-anatomy-report.md`](vault-anatomy-report.md)

**Highlights:**

- Full section map (A–L) for `useStakingVaultState` (~2,426 lines, 29 effects)
- Dependency graph, ref/timer inventory, hidden coupling report
- **Safest D1:** `useStakingVaultDiagnostics` (effects already delegate to `@/staking/diagnostics`)
- **Highest risk:** refresh orchestration + `balanceSnapshotRef` + reset/continuity keys
- **Do not split yet:** reset/orchestrator/Tron interval bundle; chain effect before `loadMeta`; `tronPassiveRefetchRef` hook order

**Next:** Phase D3b3 — `useStakingVaultBalanceRefresh` (see [`vault-balance-refresh-topology-report.md`](vault-balance-refresh-topology-report.md)).

### 6.0h Phase D3b3a — Balance refresh topology audit (complete)

**Status:** Complete (documentation only; no code changes).

**Deliverable:** [`docs/vault-balance-refresh-topology-report.md`](vault-balance-refresh-topology-report.md)

**Covers:** `balanceSnapshotRef` ownership, reset/continuity keys, orchestrator start/stop, `refreshKey` graph, `notifyStakingRefresh` fanout, Tron polling/visibility, `onCommit` timing, fast/slow boundaries, mutation timelines, D3b3 extraction shape.

**Verification:** `pnpm typecheck`, `pnpm build` — green

### 6.0g Phase D3b2 — Token reads hook (complete)

**Status:** Complete (behavior-preserving; effect registration order preserved).

**New:** `src/staking/reads/useStakingVaultTokenReads.ts`

| Export | Role |
| ------ | ---- |
| `useStakingVaultTokenReads` | Token state + `loadMeta` callback + `loadMetaRunIdRef` |
| `useStakingVaultTokenReadsAssetLifecycle` | `assetResolved` reset + `loadAsset` effects (composer calls after `refreshBalances`) |
| `useStakingVaultTokenReadsMountLoadMeta` | `void loadMeta()` effect (composer calls **after** EVM chain reconciliation) |

**Vault:** Still owns balance refs, orchestrator, `refreshBalances`, `refreshKey`, Tron polling, reset/continuity, history, tx. `StakingTokenMetaError` re-exported from `@/staking/reads/types`.

**Verification:** `pnpm typecheck`, `pnpm build` — green

### 6.0f Phase D3b1 — Stateless read executors (complete)

**Status:** Complete (pure async extraction; vault owns effects/refs/gates).

**New:** `src/staking/reads/` — `types.ts`, `evm/loadEvmPoolAsset.ts`, `evm/loadEvmTokenMeta.ts`, `tron/loadTronTokenMeta.ts`, `tron/fetchTronPassiveBalances.ts`, `index.ts`

**Vault:** `loadAsset` / `loadMeta` / `refetchTronPassiveBalances` call reads layer; all `useEffect`s, invalidation, coordinator gates, orchestrator, and ref ownership unchanged.

**Verification:** `pnpm typecheck`, `pnpm build` — green

### 6.0e Phase D3b0 — Refresh/read topology audit (complete)

**Status:** Complete (documentation only; no code changes).

**Deliverable:** [`docs/vault-refresh-topology-report.md`](vault-refresh-topology-report.md)

**Covers:** `loadMeta` / `loadAsset`, `refreshBalances`, orchestrator vs Tron 45s polling, `balanceSnapshotRef` + reset/continuity keys, coordinator commit gates, `refreshKey` → tx semantic chain, effect order contracts, safe/unsafe extraction boundaries, recommended D3b1 target (pure read executors).

### 6.0d Phase D3a — Runtime planes extraction (complete)

**Status:** Complete (behavior-preserving; effect/memo order preserved in runtime hook).

**New:** `src/staking/runtime/` — `stakingVaultChainId.ts` (`normalizeStakingVaultChainId`), `useStakingVaultRuntimePlanes.ts`, `index.ts`

**Extracted:** AppKit eip155/tron accounts, passive Tron hooks, `runtimeWallet` composition, identity publish + Tron DEV trace effects, `useEtheriumWallet`, `stakingExplorerUrl`, deprecated bridge fields (`isConnected`, `address`, `chainId`), execution plane fields

**Vault:** `const planes = useStakingVaultRuntimePlanes({ stakingRuntime })` + destructuring; `normalizeStakingVaultChainId` for remaining vault chain comparisons; `isWrongNetwork` / refresh / tx still in vault

**Verification:** `pnpm typecheck`, `pnpm build` — green

### 6.0c Phase D2b — Affiliate / PnL derivations (complete)

**Status:** Complete (pure derivation; `useAffiliateFirestoreStats` stays in vault).

**New:** `src/staking/affiliate/` — `stakingAffiliatePrincipal.ts`, `stakingAffiliatePnlSelectors.ts`, `stakingAffiliatePresentation.ts`

**Extracted:** `selectStakingNetPrincipalWei`, `affiliateBaseBalanceToVaultTokenWei` (re-export), `selectStakingPnlWei`, `selectStakingPnlBasisReady`, `selectStakingAffiliatePnlSnapshot`, presentation helpers (ROI %, floats, direction)

**Vault:** same `useMemo` deps for `stakingNetPrincipalWei`; Firestore hook + `refetchAffiliateStats` on tx unchanged

### 6.0b Phase D2a — Vault presentation selectors (complete)

**Status:** Complete (pure derivation only; no effects/refs moved).

**New:** `src/staking/selectors/` — `stakingVaultDisplaySelectors.ts`, `stakingVaultPresentationMemos.ts`, `stakingVaultDerivedFlags.ts`, `index.ts`

**Extracted:** formatted balances/fee, vault caps, PnL wei, balance anchor ms, wallet short address, token/merchant labels, `isWrongNetwork`, `vaultDataReady`, `canTransact`, `awaitingSigner`, `stakingPnlBasisReady`, `executionNetworkOk`

**Deferred D2b:** `stakingNetPrincipalWei` (affiliate Firestore), `stakingHistoryKey`, runtime identity memos, reset/continuity keys

### 6.0a Phase D1 — Vault diagnostics extraction (complete)

### 6.0a Phase D1 — Vault diagnostics extraction (complete)

**Status:** Complete (behavior-preserving; effect registration order preserved).

**New:** `src/staking/diagnostics/useStakingVaultDiagnostics.ts`

| Export | Call site in `useStakingVault` | Effects moved |
| ------ | ------------------------------ | ------------- |
| `useStakingVaultDiagnosticsMount()` | After `isMountedRef` effect (~L606) | Torture mount/unmount; chaos `STAKING_RUNTIME_CHAOS_WALLET_SURGE_EVENT` → `notifyStakingRefresh` |
| `useStakingVaultDiagnostics(input)` | After `vaultDataReady`, before return (~L2228) | Semantic assertions; execution-plane telemetry; soak `tickStakingRuntimeSoakMonitor` |

**Input:** `StakingVaultDiagnosticsInput` (typed object; no positional args). `executionPlaneTelemetryRef` ownership moved into diagnostics hook (diagnostics-only).

**Remaining in vault:** `stakingAllowanceDevLog` (inside `ensureAllowance` — tx path, not extracted); `withDeprecatedVaultBridgeDevInstrumentation` (return wrapper). `[runtime-core-boundary]` still loads from `runtimeSelectionContext`, not vault.

### 6.1 Objectives

Split `useStakingVault.ts` into focused modules **without** changing `StakingVaultValue` public shape:

| Module | Responsibility |
| ------ | -------------- |
| `useStakingVaultRuntimePlanes.ts` | `runtimeWallet`, `execution*`, identity resolve, publish |
| `useStakingVaultReads.ts` | Balances, token meta, protocol reads |
| `useStakingVaultHistory.ts` | EVM + Tron history merge |
| `useStakingVaultTx.ts` | Deposit/withdraw/approve execution surfaces |
| `useStakingVault.ts` | Thin composer + deprecated bridge object |

### 6.2 Blast radius

- **Highest** in consolidation — touches all staking app surfaces
- Coordinator gates, refresh registration, soak tick must remain wired identically

### 6.3 Rollback strategy

- Keep old `useStakingVault.ts` behind feature flag **not recommended** — prefer single revert commit
- Pre-phase tag: `git tag pre-vault-split`

### 6.4 Commit strategy

- PR1: Extract planes + publish (no tx/read changes)
- PR2: Extract reads + refresh hooks
- PR3: Extract history
- PR4: Extract tx methods
- Each PR must keep green build

### 6.5 Verification

- [ ] Full manual matrix (§10)
- [ ] Affiliate stats still keyed on `executionAddress`
- [ ] Tron passive: `canTransact === false`, reads work
- [ ] `publishStakingRuntimeWalletIdentity` still called on same deps
- [ ] Soak monitor still ticks

### 6.6 Soak requirements (before merge of PR4)

| Gate | Threshold |
| ---- | --------- |
| Live health | `stable` ≥ **5 consecutive minutes** per family (EVM + Tron) |
| Timeline | `analyzeRuntimeSoakTimeline → stable` |
| Bridge reads | Zero `[staking-vault] deprecated` during soak |
| Semantic asserts | Zero warnings (or documented exceptions) |
| Unstable snapshot | None on clean soak |

Reference: `docs/staking-runtime-wallet-migration-status.md` § Bridge removal gate.

---

## 7. Phase E — Form shared layer

### 7.1 Objectives

- Extract shared hooks: amount validation, fee readiness, `ctaIdentityConnected` wiring, lifecycle wiring
- Reduce `StakingAppDepositForm` / `StakingAppWithdrawForm` duplication (~30–40% line reduction target)

### 7.2 Blast radius

- High UX risk (CTA, gas, terms, tx phases)
- **Do not** change `useStakingCtaState` precedence rules

### 7.3 Rollback strategy

- Per-hook extraction PRs; revert individual PR if regression

### 7.4 Commit strategy

- `refactor(staking): extract useStakingFormAmountGate` (example) — one concern per PR

### 7.5 Verification

- [ ] Deposit + withdraw happy paths
- [ ] Wrong network, no ETH, approval path
- [ ] Passive Tron view-only CTA

### 7.6 Soak requirements

- **3 min stable** after each extraction PR sufficient; **5 min** before Phase G

---

## 8. Phase F — Identity / navbar contract

### 8.1 Objectives

- Document and test **publish contract**: empty snapshot shape on disconnect
- Optional: move navbar subscriber inside `StakingVaultProvider` to drop external bridge (larger UX change)
- Harden `stakingNavbarVisualHold` invariants with unit tests (if test harness exists)

### 8.2 Blast radius

- Medium — navbar visible on all `/staking/app` routes
- Bridge removal blocked until this phase completes if navbar stays outside provider

### 8.3 Rollback strategy

- Revert navbar/provider wiring PR only

### 8.4 Verification

- [ ] Disconnect → **Connect Wallet** same frame
- [ ] `[navbar-wallet-disconnect]` DEV trace
- [ ] Runtime swap: no cross-family stale chip
- [ ] Tron wrong network: amber chip, not disconnected

### 8.5 Soak requirements

- Include disconnect/reconnect in **5 min** soak script
- `reconnect_storm` detector must stay below unstable threshold on clean soak

---

## 9. Phase G — Deprecated bridge removal (destructive)

### 9.1 Preconditions (all required)

1. Phase D complete (vault uses `execution*` / `runtimeWallet*` internally only)
2. Grep clean: no `vault.isConnected`, `vault.address`, `vault.chainId` in `src/components` and `src/components/dev`
3. Phase 4.7 DEV: **zero** deprecated bridge read warnings in 5 min soak
4. Phase 4.9: timeline analyzer **`stable`**, convergence ≥ **5 min**
5. Product sign-off on `docs/staking-runtime-wallet-migration-status.md` checklist

### 9.2 Changes

- Remove `isConnected`, `address`, `chainId` from `StakingVaultValue`
- Remove `stakingVaultDeprecatedBridgeDev` instrumentation
- Remove DEV getters installation

### 9.3 Blast radius

- **Any external consumer** of vault (including forks, tests) breaks compile — intentional

### 9.4 Rollback strategy

- Revert commit; re-add bridges with DEV warnings restored
- **Do not** partial rollback in production without redeploy

### 9.5 Commit strategy

- Single PR: `feat(staking)!: remove deprecated vault wallet bridges`
- Changelog breaking change note

### 9.6 Verification

- [ ] `pnpm typecheck` + `pnpm build`
- [ ] Full manual matrix
- [ ] 15 min recommended soak (migration doc)

### 9.7 Soak requirements (strict)

| Signal | Clean soak |
| ------ | ---------- |
| `hydration_stall` | 0 |
| `identity_drift` | 0 |
| `transition_churn` | 0 |
| `contamination_disconnect` | ≤2 / 15 min |
| `consecutiveStableMinutes` | ≥5 (recommended 15) |

---

## 10. Phase H — UI relocation (optional)

### 10.1 Objectives

- Move `src/components/pages/staking/*` → `src/staking/ui/*` with path aliases
- Keep route imports stable via barrel `@/staking/ui`

### 10.2 Blast radius

- Medium (routing, lazy imports, CSS modules if any)

### 10.3 Recommendation

- Defer until Phases B–G complete unless import hygiene is blocking

---

## 11. Phase I — Legacy shim removal

### 11.1 Candidates

- `createTronReceiptResolver.ts`
- Deprecated `createExplorerResolver` export
- Legacy tx phases in `transactionStatusModel` (requires persistence migration project)

### 11.2 Soak requirements

- Standard build + targeted tx/history smoke per shim

---

## 12. Master verification matrix (manual)

Use before and after any **High** blast-radius phase:

| # | Scenario | Expected |
| - | -------- | -------- |
| 1 | EVM connect → deposit preview → cancel | CTA + modal idle; balances refresh |
| 2 | EVM disconnect | Navbar **Connect Wallet**; forms show connect CTA |
| 3 | Switch runtime EVM → Tron (dev picker) | Coordinator settles; Tron reads; EVM isolated |
| 4 | Tron passive connect wrong network | Navbar warning; switch CTA |
| 5 | Tron passive correct network | View-only CTA; balance/history |
| 6 | Runtime swap during idle | No hydration stall >10s |
| 7 | Runtime swap during tx preview | Swap denied or deferred per policy |
| 8 | Mobile tab background → foreground | Resume refresh without storm |
| 9 | History tab | Rows load; hold during loading OK |
| 10 | Referral tab | Uses `executionAddress` on EVM only |

---

## 13. DEV tooling commands (soak gate)

On `/staking/app` with vault mounted:

```text
window.__printStakingRuntimeHealth?.()
window.__stakingRuntimeSoakDump?.()
```

Console filters:

- `[staking-runtime-soak]`
- `[staking-vault][runtime-execution-plane]`
- `[staking-vault] deprecated`
- `[navbar-wallet-disconnect]`

---

## 14. CI / automation strategy

| Check | When |
| ----- | ---- |
| `pnpm typecheck` | Every PR |
| `pnpm build` | Every PR |
| Runtime stress harness | Optional CI job on `main` nightly (DEV flag only) |
| Soak | **Manual** gate before Phase G (not automatable in CI without wallet) |

---

## 15. Risk register

| ID | Risk | Mitigation |
| -- | ---- | ---------- |
| R1 | Coordinator regression on vault split | Phase D split PRs; frozen swap engine untouched |
| R2 | Navbar stale identity after publish change | Phase F contract tests + disconnect trace |
| R3 | Import cycle reintroduced | Phase B type extraction; lint rule: `staking/runtime` must not import `components` |
| R4 | Singleton orchestrator double-init | Phase C batch C2: verify single module instance |
| R5 | Tx persistence corruption | No format change in Phases B–F; dedicated persistence phase for legacy phases |
| R6 | Production bundle includes DEV soak | Verify `import.meta.env.DEV` guards and build tree-shake |

---

## 16. Suggested timeline (indicative)

| Week | Phases |
| ---- | ------ |
| 1 | A (done), B |
| 2 | C1–C3 |
| 3 | C4–C5, start D |
| 4–5 | D complete + soak |
| 6 | E, F |
| 7 | G (after gate sign-off) |
| 8+ | H, I optional |

Adjust based on soak findings; **do not schedule Phase G** until convergence gates pass.

---

## 17. Ownership recommendations (post-consolidation)

| Area | Owner module | Codeowners suggestion |
| ---- | ------------- | --------------------- |
| Runtime kernel | `staking/runtime` | Platform / staking core |
| Vault composition | `hooks/useStakingVault` → `staking/vault` | Staking feature team |
| Identity + navbar | `staking/identity` | Wallet UX |
| Tx lifecycle | `staking/tx` + `staking/ui/tx` | Staking feature team |
| DEV diagnostics | `staking/diagnostics`, `staking/dev` | Platform |

---

## 18. Deliverables checklist (Phase A)

- [x] `docs/architecture-consolidation-census.md`
- [x] `docs/architecture-consolidation-plan.md`
- [ ] Engineering review of census (team)
- [ ] Sign-off on phase order before Phase B start

---

*End of consolidation plan. No code changes in Phase A.*
