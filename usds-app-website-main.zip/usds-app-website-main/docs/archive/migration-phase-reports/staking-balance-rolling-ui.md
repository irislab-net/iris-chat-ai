# Staking balance rolling UI

This document describes how the **staking balance rolling UI** works: data sources, pure time-window model, **rAF-driven** animation layer (base smoothing only), adaptive render epsilon, visibility and window resets, **`RollingTokenAmount` `resetKey`**, and server clock alignment.

**Related code:** `src/lib/stakingRollingBalanceDisplay.ts`, `src/hooks/useRollingStakedDisplay.ts`, `src/hooks/useProfitManagerStatus.ts`, `src/hooks/useStakingVault.ts`, `src/components/pages/staking/StakingAppBalance.tsx`.

---

## 1. Data sources

### Profit manager API (`useProfitManagerStatus` → `stakingProfitManagerStatusUrl()`)

The hook fetches JSON via `fetchWithTimeout` and validates it with `parseProfitManagerStatus`. The response **`Date`** header is used to compute **`serverOffsetMs`** as:

```text
serverMs - (performance.timeOrigin + performance.now())
```

so the offset matches the **high-resolution** clock used by the rolling animation (`serverTimeMs = performance.timeOrigin + performance.now() + serverOffsetMs`).

| Field | Purpose |
|--------|---------|
| **`apy_percentage`** | Annual percentage yield as a number (e.g. `10` → 10%). Drives **`rPeriod`** via `computeRollingStakedModel`. |
| **`share_interval_seconds`** | Target profit-share cadence in seconds (clamped in code to 60–86400). Combined with `SECONDS_PER_YEAR` for **`periodsPerYear`** → **`rPeriod`**. |
| **`last_processed_at`** | ISO start of the interpolation window. |
| **`next_profit_share_at`** | ISO end of the window; defines duration `(next − last)`. |

The hook refetches on an interval (~45s) and polls more frequently (~8s) after the window passes `next_profit_share_at`.

### On-chain (vault)

`useStakingVault` reads **`vault.balanceOf(address)`** as **`stakedAssets`**. In **`StakingAppBalance`**, **`principalWei`** is converted to **`targetBase`** (float) for the model and animation.

---

## 2. Core concept (important)

This is **not** real-time on-chain balance. It is **time-based interpolation** between **`last_processed_at`** and **`next_profit_share_at`**: **`rawProgress`** follows wall clock in that window. **UI smoothing applies only to `smoothedBase`** toward chain **`targetBase`** (plus snap rules); **`rawProgress` is never smoothed.**

The pure reference (e.g. reduced motion) is **`computeRollingStakedDisplayFloat`**, which delegates to **`computeRollingStakedModel`**.

LERP background: [Interpolation (computer graphics)](https://en.wikipedia.org/wiki/Interpolation_%28computer_graphics%29).

---

## 3. Pure mathematical model

Implemented in **`computeRollingStakedModel`** / **`computeRollingStakedDisplayFloat`** (`stakingRollingBalanceDisplay.ts`).

### Steps

1. **`rPeriod`** from APY and `share_interval_seconds` (unchanged compound step).
2. **`rawProgress`** = clamped time fraction in `[lastMs, nextMs]` using **`serverTimeMs`**.
3. Reference display: **`min(targetBase + rawProgress × (targetBase × rPeriod), targetBase + targetBase × rPeriod)`**.

If the window or interval is invalid, the model is **degenerate** and the reference display is **`targetBase`** only.

---

## 4. Animation layer (`useRollingStakedDisplayFloat`)

**Engine:** **`requestAnimationFrame` only** — no `setInterval` for the rolling value.

### Core UI formula (enforced)

```text
smoothedPeriodProfit = smoothedBase × rPeriod
display = min(
  smoothedBase + rawProgress × smoothedPeriodProfit,
  smoothedBase + smoothedPeriodProfit
)
```

- **`rawProgress`**: from the model each frame — **not** smoothed.
- **`smoothedBase`**: eased toward **`targetBase`** using **dt-clamped** exponential smoothing (**`dt ∈ [1, 50]` ms**), with:
  - **Window change** (`last_processed_at` or `next_profit_share_at` string changes): **`smoothedBase = targetBase`**, **`lastRafTs`** reset.
  - **Tab visible** after hide: **`smoothedBase = targetBase`** (snap-on-visible).
  - **Large jump:** if **`targetBase > 0`** and **`|targetBase − smoothedBase| / targetBase > 0.01`**, snap **`smoothedBase = targetBase`**.
  - **`targetBase === 0`**: **`smoothedBase = 0`**.

### React state vs `animatedRef`

- **`animatedRef.current`** updates **every rAF frame** (feeds **`RollingTokenAmount`** `valueRef`).
- **`setDisplayFloat`** runs only when the value crosses **`rollingRenderEpsilon(displayDecimals)`**:

```text
epsilonRender = max(1e-12, 10^-(displayDecimals + 2))
```

When **`displayDecimals`** changes, the previous emitted value is invalidated so the first update under the new precision cannot stick.

### Reduced motion

Uses **`computeRollingStakedDisplayFloat`** on relevant dependency changes (no rAF smoothing loop).

---

## 5. `RollingTokenAmount` `resetKey`

**Must** be stable across profit-manager API refreshes so digit strips do not reset unnecessarily:

```text
resetKey = `${principalWei}-${displayDecimals}`
```

Do **not** include `last_processed_at`, `next_profit_share_at`, or APY fields.

---

## 6. Manual QA scenarios

1. **Normal** — smooth number, stable FPS band.
2. **CPU throttle (4× / 6×)** — FPS drops; **`setDisplayFloat`** rate stays low vs rAF; animation **`dt`** clamp still applies.
3. **Tab hidden → resume** — no runaway spike; snap-on-visible for base.
4. **Large balance change** — **>1%** relative snap.
5. **Profit-manager API refresh** — no **`resetKey`**-driven digit reset; continuity.

---

## 7. One-sentence summary

**The UI uses chain `targetBase` and profit-manager timestamps to compute time-accurate `rawProgress` and `rPeriod`, animates only the base toward chain with rAF and snap rules, derives display from `smoothedBase` and `rawProgress`, and gates React updates with `epsilonRender(displayDecimals)`.**
