# Staking config canonicalization — CFG4 report

**Phase:** CFG4 — destructive env retirement (conservative; **no** RPC/address/Firebase/runtime-flag removals).

**Prerequisites:** CFG1–CFG3 canonicalized consumption; this phase only removes keys and code paths that were **grep-clean** in `src/` and config typings.

**Verification:** `pnpm typecheck` and `pnpm build` succeeded after this change set.

---

## Deleted env keys

| Deleted env | Canonical replacement | Verified grep-clean (`src/**`, `*.ts`/`*.tsx`/`*.json`/CI configs) | Runtime risk |
| ----------- | --------------------- | ------------------------------------------------------------------ | ------------ |
| `VITE_NATIVE_USD_RATE` | ETH/USD from Chainlink (`ethUsdPriceCache` / `VITE_CHAINLINK_ETH_USD_FEED` + `src/constants/ethUsdChainlinkFeeds.ts`) | **Yes** — zero runtime references in app code after removal | **Low** — was parsed in `env.ts` with **no consumers** in `src/` |
| `VITE_STAKING_PROFIT_MANAGER_STATUS_URL` | Firestore-backed profit status (`@/staking/profit`, `useProfitManagerStatus`) | **Yes** — no call sites for `stakingProfitManagerStatusUrl()` or `STAKING_PROFIT_MANAGER_STATUS_URL` outside removed wiring | **Low** — legacy HTTP path unused; UI already uses Firestore |

**Post-change repo grep note:** Historical audit markdown under `docs/archive/migration-phase-reports/staking-config-canonicalization-report.md` still **mentions** the retired keys for archival context; **no** `src/` or runtime config references remain.

---

## Removed code (non-key)

| Removed | Reason |
| ------- | ------ |
| `parseOptionalPositiveNumber` (private helper in `env.ts`) | Only served `VITE_NATIVE_USD_RATE` |
| `readViteNativeUsdRate`, `readViteStakingEtherscanApiKey`, `readViteGasDebug` | Dead exports (no `src/` callers); use Chainlink ETH/USD path, `ETHERSCAN_API_KEY`, or `DEBUG_LOGS` if reintroducing call sites |
| `STAKING_PROFIT_MANAGER_STATUS_URL` export + `stakingProfitManagerStatusUrl()` | Env key deleted; function had no callers |
| Re-export of `STAKING_PROFIT_MANAGER_STATUS_URL` from `stakingVaultConfig.ts` | Same |

**Still present (intentionally):** `getExpectedChainId`, `readViteStakingTermsUrl`, `readViteStakingHighNetworkFeeWei` — actively used via `@/staking/config` re-exports.

---

## Remaining `VITE_*` surface (`src/vite-env.d.ts`)

**Count:** **44** `readonly VITE_*` entries (down from **46** before CFG4).

**Groupings:**

- **Reown / app metadata (required):** `VITE_REOWN_PROJECT_ID`, `VITE_APP_METADATA_*`
- **Staking legacy row (required):** `VITE_STAKING_VAULT_ADDRESS`, `VITE_STAKING_RPC_URL`, `VITE_STAKING_CHAIN_ID`, explorer/network/terms labels, optional `VITE_STAKING_WS_URL`, `VITE_STAKING_TOKEN_ADDRESS`
- **Multi-deployment / explicit sibling rows (optional):** `VITE_STAKING_DEPLOYMENTS_JSON`, `VITE_STAKING_ETH_*`, `VITE_STAKING_TRON_*`, Tron token + Grid history API
- **History / indexers (optional):** `VITE_STAKING_TX_HISTORY_ORIGIN`, `VITE_ETHERSCAN_API_KEY`, `VITE_STAKING_TRON_TX_HISTORY_GRID_API_URL`
- **ETH/USD presentation (optional):** `VITE_CHAINLINK_ETH_USD_FEED`, `VITE_ETH_USD_CACHE_TTL_MS`, `VITE_ETH_USD_FEED_STALE_AFTER_SEC`, `VITE_STAKING_HIGH_NETWORK_FEE_WEI`
- **Debug / telemetry / runtime (optional except semantics):** `VITE_DEBUG_LOGS`, telemetry stage/sample, runtime switch rollout, DEV stress/torture/chaos/picker, `VITE_APPKIT_TRON_IDENTITY`
- **Firebase (required core + optional extended):** `VITE_FIREBASE_*`, affiliate Firestore options

---

## Blast radius

- **`env.ts`:** Dropped parsing for two optional keys; removed small dead API surface.
- **`stakingVaultConfig.ts`:** No longer exports profit-manager URL; staking bundle that only imported constants for re-export is unchanged for all other symbols.
- **Profit UI:** `useProfitManagerStatus` → `@/staking/profit` **unchanged** (never depended on removed env).
- **No** changes to orchestrators, history merge logic, tx persistence semantics, refresh intervals, or chain routing.

---

## Rollback instructions

1. Restore `VITE_STAKING_PROFIT_MANAGER_STATUS_URL` and `VITE_NATIVE_USD_RATE` on `ImportMetaEnv` in `src/vite-env.d.ts`.
2. Reintroduce `optionalEnv` / parsing blocks and deprecated helpers in `src/config/env.ts` from git history.
3. Restore `STAKING_PROFIT_MANAGER_STATUS_URL` import/export and `stakingProfitManagerStatusUrl()` in `src/constants/stakingVaultConfig.ts`.
4. Run `pnpm typecheck` && `pnpm build`.

---

## Smoke checklist (manual)

After deploy or local prod build:

- [ ] **EVM:** connect wallet, correct chain, deposit/withdraw CTA sane
- [ ] **Tron:** passive Tron row — balance/read path if configured
- [ ] **Tx:** submit tx, status surface updates
- [ ] **History:** EVM + Tron history panels load (origins/keys unchanged)
- [ ] **Reconnect:** disconnect/reconnect wallet, no stale chain state
- [ ] **Refresh:** balance refresh / orchestrator still ticks (no timing change intended)
- [ ] **Runtime swap:** internal rollout flags unchanged; swap policy unchanged

---

## Future CFG candidates (not executed)

- Migrate `getExpectedChainId` call sites to `STAKING_CHAIN_ID` import for naming clarity (behavior-identical).
- Archive doc refresh: `docs/archive/migration-phase-reports/staking-config-canonicalization-report.md`, `docs/archive/migration-phase-reports/staking-balance-rolling-ui.md` still describe pre-CFG4 wiring in places.
