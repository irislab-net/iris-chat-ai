# Bridge removal readiness report (Phase G-prep1)

Generated after consumer migration and shim audit. **No bridges or shims were deleted** in this phase.

## Summary

| Area | Status |
|------|--------|
| Deprecated vault public fields (`address`, `isConnected`, `chainId`) | **No UI/runtime consumers** — still exported with DEV getters |
| `activeRuntimeSelection` on vault return | **No vault consumers** — staking UI uses `useActiveRuntimeSelection()` |
| `useStakingVaultEvmNetworkGlue` | **No callers** — composer shim only |
| `@/lib/staking/*` with canonical `@/staking/*` target | **Migrated** where shims exist (execution, tx, identity, diagnostics) |
| `@/lib/staking/*` without canonical home yet | **Documented** — Phase G2 extraction required |
| DEV migration assertions | **Added** (vault bridge, runtime planes, lib shims) |

Verification: `pnpm typecheck` ✅ · `pnpm build` ✅

---

## 1. Deprecated vault public fields

### Intended replacements

| Deprecated | Replacement |
|------------|---------------|
| `vault.address` | `executionAddress` (EVM tx) or `runtimeWalletAddress` / `stakingOwnerAddress` (display) |
| `vault.isConnected` | `executionConnected` (EVM) or `runtimeWalletConnected` / `runtimeWallet.hasAccount` (Tron) |
| `vault.chainId` | `executionChainId` |

### Consumer migration (complete)

All `useStakingVault()` call sites in `src/components/pages/staking/` were audited:

- **Deposit / withdraw forms** — `executionAddress`, `executionConnected`, `executionChainId`, `runtimeWallet*`
- **Balance, referral, history, error surface, asset select** — execution / runtime wallet fields only
- **TransactionStatusProvider** — execution fields + `useActiveRuntimeSelection()` for runtime
- **RuntimePickerDevPanel** — `vault.executionChainId` only

CTA hooks (`useStakingFormLifecycle`, `useStakingCtaState`) receive **explicit** `executionConnected` / `executionAddress` / `executionChainId` from forms — not deprecated vault aliases.

### Public API (unchanged — Phase G)

`assembleStakingVaultPublicValue` still exports `address`, `isConnected`, `chainId` for external compatibility. DEV instrumentation:

- `withDeprecatedVaultBridgeDevInstrumentation` (`@/staking/diagnostics`)
- Warns on read: `[staking-vault] deprecated vault.<field> read`

---

## 2. `activeRuntimeSelection` audit

### Migrated to `useActiveRuntimeSelection()` (runtime ownership)

| File | Usage class |
|------|-------------|
| `StakingAppDepositForm.tsx` | Runtime family, deployment id, pool label, Tron CTA copy |
| `StakingAppWithdrawForm.tsx` | Same |
| `StakingAppBalance.tsx` | Deployment id, Tron runtime, wrong-network aria |
| `StakingAppNetworkChip.tsx` | Runtime swap picker |
| `StakingAppTransactionHistory.tsx` | Deployment id, EVM vault contract address for history |
| `TransactionStatusProvider.tsx` | Tx reconcile, frozen runtime, Tron/EVM surface |
| `TransactionStatusSurface.tsx` | Explorer URLs, modal copy |

### Still on public vault return (external compatibility)

- `stakingVaultPublicAssembly.ts` → `activeRuntimeSelection: stakingRuntime`
- Frozen in `STAKING_VAULT_PUBLIC_TOPOLOGY_KEYS`

**Phase G action:** Remove from public object after confirming no external integrators; runtime UI already uses context hook.

### Not deprecated

`deployment.vault.address` (on-chain vault **contract** address) is configuration, not the vault hook bridge.

---

## 3. Import migration (`@/lib/staking/*` → `@/staking/*`)

### Migrated (canonical paths now used)

| Former import | Canonical |
|---------------|-----------|
| `stakingVaultDeprecatedBridgeDev` | `@/staking/diagnostics` |
| `stakingLifecycleInstrumentation` | `@/staking/diagnostics` |
| `stakingRuntimeSoakMonitor` | `@/staking/diagnostics` |
| `stakingRuntimeWalletIdentity` | `@/staking/identity` |
| `stakingRuntimeWalletIdentityBridge` | `@/staking/identity` |
| `stakingNavbarVisualHold` | `@/staking/identity` |
| `stakingPassiveRuntimeUx` | `@/staking/identity` |
| `stakingReadFactory` / `stakingReadProviders` | `@/staking/execution` |
| `ethUsdPriceCache` | `@/staking/execution` |
| `stakingTxExplorerFromDeployment` | `@/staking/execution` |
| `stakingTxSessionPersistence` | `@/staking/tx` |
| `stakingTxOnChainRecovery` | `@/staking/tx` |

### Core orchestration shims migrated (components/hooks)

| Former | Canonical |
|--------|-----------|
| `@/staking/core/runtimeTransitionCoordinator` | `@/staking/orchestration` |
| `@/staking/core/runtimeSwapPolicy` | `@/staking/orchestration` |
| `@/staking/core/runtimeSwapEngine` | `@/staking/orchestration` |

`@/staking/core/*` modules **without** deprecated shims (e.g. `runtimeSelectionContext`, `runtimeSelectionHooks`, `persistenceTypes`) correctly remain on core.

### Remaining `@/lib/staking/*` (no canonical `@/staking/*` home yet)

**UI / hooks (high visibility)**

- `stakingToast`, `stakingPassiveNotificationPolicy`
- `stakingInputStyles`, `stakingCtaEllipsisPolicy`, `stakingAmountSliderVisual`
- `stakingSnapshotCtaPhase`, `stakingFormInlineReasonResolver`, `stakingCtaDiagnostics`
- `buildNetworkFeePresentation`, `stakingFeeCanonical`
- `stakingRefreshOrchestrator` (`notifyStakingRefresh`)
- `stakingMobileResumeCoordinator`
- `receiptErrorSonnerPolicy`, `receiptSuccessSonnerPolicy`
- `stakingTxIntegrityDev`

**Staking package internals**

- `staking/refresh`, `staking/diagnostics`, `staking/dev/*`, `staking/runtime/network`, `staking/reads`
- `staking/execution` metrics: `stakingRefreshMetrics`
- `staking/orchestration/runtimeLifecycleAssertions` (orchestrator + fee canonical)

**Other**

- `profitManagerStatusSingleton`, `originalTelegramUrl` (non-staking-domain)

Each remaining `lib/staking` **shim** file logs once per module in DEV:

`[staking-migration] deprecated import path: @/lib/staking/<name>`

---

## 4. Network glue shim

| Symbol | Consumers |
|--------|-----------|
| `useStakingVaultEvmNetworkGlue` | **0** — only `src/staking/vault/composer/index.ts` re-export |

Production path: `useStakingVaultNetworkGlue` from `@/staking/runtime/network`.

---

## 5. DEV migration assertions (new)

| Assertion | Module |
|-----------|--------|
| Deprecated vault bridge field read | `stakingVaultDeprecatedBridgeDev` (existing) |
| Deprecated runtime-planes alias read | `stakingRuntimePlanesDeprecatedDev` + `useStakingVaultRuntimePlanes` |
| Deprecated `@/lib/staking/*` shim import | `stakingMigrationAssertionsDev` on shim module load |

---

## 6. Grep-clean evidence (2026-05-15)

### `vault.address` / `vault.isConnected` / `vault.chainId` (deprecated **public** bridge)

```
vault.isConnected  → 0 matches
vault.chainId      → 0 matches
vault.address      → 0 matches (excluding deployment.vault.address config keys)
```

`deployment.vault.address` appears in history/reads/core — **not** the deprecated hook field.

### `useStakingVaultEvmNetworkGlue`

```
src/staking/vault/composer/index.ts          (re-export)
src/staking/vault/composer/useStakingVaultEvmNetworkGlue.ts  (shim definition)
```

### `@/lib/staking/` (consumer + staking packages; excludes intentional lib/staking internals)

~45 import lines remain across `src/components`, `src/hooks`, `src/staking`, `src/providers` — see §3. All have shim warnings or are listed as G2 extraction targets.

---

## 7. Safe-delete candidates (Phase G / G2)

| Item | Prerequisite |
|------|----------------|
| `useStakingVaultEvmNetworkGlue.ts` shim | One release after prep1; grep confirms 0 callers |
| `lib/staking/*` shim files (18) | All importers migrated to `@/staking/*` |
| Public `address`, `isConnected`, `chainId` on vault return | DEV shows zero reads in repo |
| `withDeprecatedVaultBridgeDevInstrumentation` wrapper | After public fields removed |
| `stakingRuntimePlanesDeprecatedDev` | After planes aliases removed |
| `STAKING_VAULT_PUBLIC_TOPOLOGY_KEYS` entries for removed keys | Coordinated API bump |

---

## 8. Unsafe-delete candidates (do not remove in Phase G)

| Item | Why |
|------|-----|
| `activeRuntimeSelection` on public return | External API / topology freeze; UI migrated but export remains |
| `stakingRefreshOrchestrator` | Balance refresh ordering + notify fanout; no `@/staking/refresh` export yet |
| `stakingToast` / passive notification policy | Cross-cutting UX; many UI + network glue deps |
| `stakingFeeCanonical` + receipt policies | Tx modal + persistence reconcile |
| `stakingMobileResumeCoordinator` | Bootstrap + tx surface mobile resume |
| `lib/staking/stakingRefreshOrchestrator.ts` body | Large; move-only to `@/staking/refresh` or `@/staking/orchestration` first |
| Core registry / selection modules | Not shims — real homes under `@/staking/core` |

---

## 9. Phase G blockers (exact)

1. **Extract remaining `lib/staking` modules** into `@/staking/tx`, `@/staking/cta`, `@/staking/ui`, or `@/staking/orchestration` barrels (no behavior change).
2. **Remove public bridge fields** from `assembleStakingVaultPublicValue` + update `STAKING_VAULT_PUBLIC_TOPOLOGY_KEYS`.
3. **Remove `activeRuntimeSelection`** from public vault return (optional alias to document migration: use `useActiveRuntimeSelection()`).
4. **Delete shim files** under `lib/staking/` after import count = 0.
5. **Remove DEV instrumentation** wrappers once fields deleted.
6. **Manual QA** — deposit, withdraw, wrong network, runtime swap, navbar, history, tx modal, reconnect, Tron passive, soak monitor.

---

## 10. Bridge-removal blast radius estimate

| Layer | Files touched (estimate) | Risk |
|-------|--------------------------|------|
| Public vault return shape | 1 assembly + topology + any external consumer | Medium (API) |
| `lib/staking` shim deletion | ~37 shim files + ~45 import sites | Low if extraction done first |
| `activeRuntimeSelection` export | 1 assembly | Low (UI already on context) |
| Network glue shim | 2 files | Very low |
| Runtime planes aliases | `useStakingVaultRuntimePlanes` + internal `planes.isConnected` usages | Low–medium (internal only) |
| Tx / refresh orchestrator move | 10–15 files | Medium (ordering) |

**Overall:** ~60–80 files for full Phase G; **prep1 reduced UI risk to near-zero** for deprecated field reads. Remaining work is **mechanical extraction + export deletion**.

---

## 11. Related docs

- [staking-network-topology.md](./staking-network-topology.md) — network glue sequencing (Phase E1)
- [stakingVaultComposerContracts.ts](../src/staking/vault/composer/stakingVaultComposerContracts.ts) — composer hook order
