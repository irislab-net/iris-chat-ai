# Vault balance + refresh topology report (Phase D3b3a)

**Scope:** Balance snapshot refs, EVM orchestrator session, Tron passive polling, `refreshBalances` / `refreshKey`, reset/continuity keys — in `src/hooks/useStakingVault.ts` and `src/lib/staking/stakingRefreshOrchestrator.ts`.  
**Post-D3b2:** Token reads live in `useStakingVaultTokenReads`; **all balance refresh ownership remains in the vault composer.**  
**Rules:** Analysis only — no code movement, hook extraction, orchestrator changes, or behavior changes.  
**Companions:** [`vault-refresh-topology-report.md`](vault-refresh-topology-report.md) (D3b0 reads+refresh), [`architecture-consolidation-plan.md`](architecture-consolidation-plan.md).

---

## Executive summary

| Finding | Detail |
| ------- | ------ |
| **Authoritative merge surface** | `balanceSnapshotRef` (orchestrator `getPrevious` / commits) + mirror `lastDisplayBalancesRef` (continuity seed only) |
| **Dual engines (mutex)** | EVM: module singleton orchestrator. Tron: vault 45s interval + visibility/pageshow; orchestrator **always stopped** on Tron |
| **Reset vs continuity** | `vaultBalanceResetKey` **zeros** refs + React balance flags; `poolSnapshotContinuityKey` **reseeds** `balanceSnapshotRef` from `lastDisplayBalancesRef` (stale-while-refresh on pool/owner change) |
| **Tx → EVM refresh** | `setRefreshKey` → effect → `notifyStakingRefresh("tx-state-change")`; Tron post-tx relies on `refreshBalances` or 45s poll |
| **onCommit timing** | After fast/slow RPC + `canRuntimeOperationCommit(captured, latest)` in orchestrator; vault `onCommit` adds `canRuntimeOperationCommitWithDevTrace` |
| **D3b3 extraction** | Single hook `useStakingVaultBalanceRefresh` with **ref bag passed from composer**; must co-move reset + continuity + both refresh effects + `refreshBalances` + `refreshKey` |

---

## 1. Full dependency graph

```mermaid
flowchart TB
  subgraph inputs [Vault inputs]
    RT[useRuntimeTransitionSnapshot]
    PLANES[useStakingVaultRuntimePlanes]
    TOKEN[useStakingVaultTokenReads]
    ADDR[tokenAddress / assetResolved]
    WALLET[address / runtimeWalletAddress]
    CHAIN[chainId / isWrongNetwork]
  end

  subgraph refs [Vault refs]
    BSR[balanceSnapshotRef]
    LDB[lastDisplayBalancesRef]
    OBS[observedBalanceRef]
    TPR[tronPassiveRefetchRef]
    TFG[tronPassiveFetchGenRef]
  end

  subgraph react [React balance state]
    WB[walletBalance .. minWithdrawalFeeWei]
    BF[balancesFetched]
    RK[refreshKey]
  end

  subgraph evm_orch [Module: stakingRefreshOrchestrator]
    NS[notifyStakingRefresh]
    TICK[tick]
    FAST[executeStakingFastRead]
    SLOW[executeStakingSlowRead]
    OC[session.onCommit]
  end

  subgraph tron_path [Vault: Tron path]
    RPB[refetchTronPassiveBalances]
    INT[45s setInterval]
    VIS[visibilitychange / pageshow]
  end

  RT --> TICK
  RT --> RPB
  RT --> OC
  PLANES --> ADDR
  PLANES --> WALLET
  PLANES --> CHAIN
  TOKEN --> ADDR

  ADDR --> EVM_START[startStakingRefreshOrchestrator]
  WALLET --> EVM_START
  CHAIN --> EVM_START

  BSR --> FAST
  FAST --> OC
  SLOW --> OC
  OC --> BSR
  OC --> LDB
  OC --> WB
  OC --> OBS

  RPB --> BSR
  RPB --> LDB
  RPB --> WB

  RK --> NS
  RB[refreshBalances] --> NS
  RB --> TPR
  TPR --> RPB

  RESET[vaultBalanceResetKey effect] --> BSR
  RESET --> LDB
  RESET --> BF
  CONT[poolSnapshotContinuityKey effect] --> BSR
  LDB --> CONT

  INT --> RPB
  VIS --> RPB
  NS --> TICK
```

### Hard dependencies (must not break in D3b3)

| Consumer | Depends on |
| -------- | ---------- |
| Orchestrator `getPrevious` | `balanceSnapshotRef.current` at tick time |
| Orchestrator `onCommit` | Same ref + React setters + `lastDisplayBalancesRef` mirror |
| `refetchTronPassiveBalances` | `balanceSnapshotRef`, `tronPassiveFetchGenRef`, `transition` gates |
| `vaultBalanceResetKey` | Runs **before** orchestrator re-start on wallet/runtime change |
| `poolSnapshotContinuityKey` | Runs after reset family; seeds orchestrator merge base |
| `refreshBalances` | Defined **before** `tronPassiveRefetchRef` assignment effect |
| `vaultDataReady` | `balancesFetched` set by orchestrator, Tron refetch, or stop paths |

---

## 2. Effect order graph

**Registration order in `useStakingVaultState` (balance-relevant effects only, current line numbers):**

| # | Location | Effect |
| - | -------- | ------ |
| 1 | L385 | History abort on `isWrongNetwork` |
| 2 | L452 | `isMountedRef` |
| 3 | — | `useStakingVaultDiagnosticsMount()` |
| 4 | L462 | `numericChainIdRef` sync |
| 5 | L467 | `tokenMetaErrorRef` sync |
| 6 | L493 | `useStakingVaultTokenReadsAssetLifecycle` → asset reset + loadAsset (token module) |
| 7 | L488–491 | `refreshBalances` callback defined |
| 8 | L510–590 | `refetchTronPassiveBalances` callback defined |
| 9 | L592 | `tronPassiveRefetchRef` wiring |
| 10 | L700 | Switch verify interval cleanup |
| 11 | L725 | **`vaultBalanceResetKey` reset** |
| 12 | L761 | **`poolSnapshotContinuityKey` seed** |
| 13 | L787 | EVM chain reconciliation (token meta; not balance) |
| 14 | L838 | `useStakingVaultTokenReadsMountLoadMeta` |
| 15 | L840 | **`refreshKey` → notify tx-state-change** |
| 16 | L846 | **EVM orchestrator start/stop** |
| 17 | L946 | **Tron interval + visibility/pageshow** |
| 18 | L1201 | Tron network rehydrate → `refetchTronPassiveBalances` |

```mermaid
flowchart TD
  RESET[vaultBalanceResetKey L725]
  CONT[poolSnapshotContinuity L761]
  CHAIN[chain reconciliation L787]
  META[loadMeta mount L838]
  RK[refreshKey L840]
  ORCH[EVM orchestrator L846]
  TRON[Tron interval L946]

  RESET --> CONT
  CONT --> CHAIN
  CHAIN --> META
  META --> RK
  RK --> ORCH
  ORCH --> TRON
```

**Invariant:** Reset and continuity complete **before** orchestrator session binds `getPrevious: () => balanceSnapshotRef.current`.

**Hook-order invariant:** `refreshBalances` (L488) **before** `tronPassiveRefetchRef` wiring (L592).

---

## 3. Ref ownership table

| Ref | Owner module | Writers | Readers | Invalidation |
| --- | ------------ | ------- | ------- | ------------ |
| `balanceSnapshotRef` | Vault composer | `vaultBalanceResetKey` effect; continuity effect; orchestrator `onCommit`; Tron `refetchTronPassiveBalances`; Tron invalid-owner branch | Orchestrator `getPrevious`; share-change detection (Tron + orchestrator) | Reset key; continuity copy; new commit |
| `lastDisplayBalancesRef` | Vault composer | Same writers as snapshot (always mirrored on commit) | Continuity effect (`…lastDisplayBalancesRef` → `balanceSnapshotRef`) | Reset key; mirrored on every successful commit |
| `observedBalanceRef` | Vault composer | `onCommit` / Tron commit when `sharesChanged` | PnL anchor selectors | Not cleared on reset (only updated on share change) |
| `tronPassiveRefetchRef` | Vault composer | L592 effect assigns `() => void refetchTronPassiveBalances()` | `refreshBalances()` | Cleared when `!isTronPassiveRuntime` |
| `tronPassiveFetchGenRef` | Vault composer | Increment at Tron fetch start; bump on interval cleanup | Stale Tron RPC guard | Cleanup of Tron interval effect |
| `tronPassiveReadFailStreakRef` | Vault composer | Tron catch path | Telemetry | Reset on interval cleanup |
| Orchestrator `session` | `stakingRefreshOrchestrator.ts` | `startStakingRefreshOrchestrator` | `tick()` | `stopStakingRefreshOrchestrator` / dispose |
| Orchestrator `invalidationGen` | Module | `stop`, new tick | Stale tick abort | `stopStakingRefreshOrchestrator` |
| Orchestrator `pendingMask` | Module | `notifyStakingRefresh*` | `tick()` coalescing | Cleared per tick; reset on stop |

**React state (not refs but balance UI authority):** `walletBalance`, `allowance`, `vaultShares`, `stakedAssets`, cap fields, `balancesFetched`, `observedBalanceAnchorMs`, `refreshKey`.

---

## 4. Mutation timeline

### 4.1 EVM refresh (orchestrator tick)

| Phase | What happens |
| ----- | ------------- |
| T0 | `notifyStakingRefresh` sets `pendingMask`, `scheduleNext()` |
| T1 | `tick`: `canRuntimeOperationRefresh(latest)` — may skip |
| T2 | `getPrevious()` → read `balanceSnapshotRef.current` |
| T3 | **Fast read** (if `needFast`): `balanceOf` + vault `balanceOf` — **legacy RPC** (no `stakingReadOptions`) |
| T4 | Mid-tick: `invalidationGen` check; optional **pre-slow** refresh gate |
| T5 | **Slow read** (if `needSlow`): allowance, maxDeposit, maxWithdraw, minFee |
| T6 | `buildCommit(prev, fast, slow)` — failed fields keep `prev` via `mergeField` |
| T7 | `canRuntimeOperationCommit(captured, latest)` — may drop commit |
| T8 | `onCommit(c)` in vault: coordinator DEV trace → write refs + React state → `setBalancesFetched(true)` |

**Fast/slow boundaries:**

| Tier | RPC | Floor / trigger |
| ---- | --- | ---------------- |
| **Fast** | `walletBalance`, `vaultShares` | 45s floor, any `pendingMask`, **always on `tx-state-change`** |
| **Slow** | `allowance`, caps, min fee | 420s floor, mask, tx semantic, network semantic; blocked if `!sequenceStageAllowsBalanceRefresh` |

### 4.2 Tron refresh (`refetchTronPassiveBalances`)

| Phase | What happens |
| ----- | ------------- |
| T0 | `++tronPassiveFetchGenRef` |
| T1 | `fetchTronPassiveBalances` (reads layer → execution FullNode) |
| T2 | Gen + `isMountedRef` check |
| T3 | `canRuntimeOperationCommitWithDevTrace("…tronPassiveBalancesCommit")` |
| T4 | Write `balanceSnapshotRef` + `lastDisplayBalancesRef` + React setters |
| T5 | Optional `observedBalanceRef` if shares changed; `setBalancesFetched(true)` |

**Triggers:** 45s interval, visibility visible, pageshow persisted, `refreshBalances` → ref, `requestNetworkSwitch` (Tron), Tron rehydrate effect.

### 4.3 Tx refresh

| Path | EVM | Tron |
| ---- | --- | ---- |
| Deposit/withdraw receipt | `setRefreshKey` → L840 effect → `notifyStakingRefresh("tx-state-change")` → orchestrator fast+slow bias | Same `refreshKey` effect runs but orchestrator **stopped** — **no automatic balance bump** unless user calls `refreshBalances` or waits for poll |
| Approve | `refreshBalances()` → wallet semantic + Tron refetch | Both paths |

History: `refreshStakingHistory()` direct (not `refreshKey`).

### 4.4 Runtime swap (EVM ↔ Tron)

| Step | Balance behavior |
| ---- | ---------------- |
| 1 | `vaultBalanceResetKey` changes (`runtimeKey`, deployment, wallet identity) |
| 2 | Reset effect: zero refs, `balancesFetched=false`, token meta flags cleared |
| 3 | Tron effect: `stopStakingRefreshOrchestrator()` |
| 4 | EVM effect: either starts orchestrator or stops + `setBalancesFetched(true)` |
| 5 | Coordinator may block commits during `begin_requested` / `refresh_paused` / `runtime_swapped` |
| 6 | After `resume_requested`, orchestrator ticks resume; Tron interval refetches |

**Risk:** Commit during swap with stale `coordinatorSnapshot` captured at session start — mitigated by `canRuntimeOperationCommit(captured, latest)` + vault DEV trace on `onCommit`.

### 4.5 Disconnect

| Family | Behavior |
| ------ | ---------- |
| EVM | Orchestrator effect deps change → `stopStakingRefreshOrchestrator()`; gates fail → `setBalancesFetched(true)` without RPC |
| Tron | Invalid owner → zero refs + React zeros + `balancesFetched=true` (L954–973) |
| Reset key | May fire on `isConnected` / address change → full zero |

### 4.6 Wrong network

| Family | Behavior |
| ------ | ---------- |
| EVM | Orchestrator stopped (L851–860); `setBalancesFetched(true)` — UI not stuck loading |
| Tron | Continuity effect skips seed when `isWrongNetwork` (EVM branch); Tron uses `runtimeWallet.networkOk` elsewhere |
| Token meta | `WRONG_NETWORK` — separate from balance pipeline |

### Ref mutation ordering (single commit)

```
1. balanceSnapshotRef := commit fields
2. lastDisplayBalancesRef := copy(snapshot)
3. setWalletBalance / setAllowance / … (React)
4. if sharesChanged: observedBalanceRef + setObservedBalanceAnchorMs
5. setBalancesFetched(true)
```

Continuity-only (no React balance update):

```
lastDisplayBalancesRef (unchanged) → copy → balanceSnapshotRef
```

Reset:

```
balanceSnapshotRef := z; lastDisplayBalancesRef := z; (React zeros in Tron invalid-owner only)
```

---

## 5. Reset semantics (`vaultBalanceResetKey`)

**Memo (L708–722):**

| Runtime | Key components |
| ------- | ---------------- |
| Tron | `runtimeKey \| deploymentId \| runtimeWalletAddress \| identityOrigin` |
| EVM | `runtimeKey \| address \| numericChainId \| isConnected \| isEthereumNetwork` |

**Effect (L725–741) on key change:**

| Target | Action |
| ------ | ------ |
| `tokenMetaFetched` | `false` |
| `balancesFetched` | `false` |
| `tokenDecimals` | `null` |
| `tokenMetaError` | `null` |
| `balanceSnapshotRef` | All fields zero; caps `MaxUint256` |
| `lastDisplayBalancesRef` | Same zero struct |

**Does not:** Clear React `walletBalance` / allowance / shares (orchestrator or Tron effect may repopulate; Tron invalid-owner explicitly zeros React).

**Does not:** Clear `observedBalanceRef` or `refreshKey`.

**Intent:** New wallet/runtime epoch → orchestrator merge starts from zero; avoid displaying previous wallet’s on-chain snapshot.

---

## 6. Continuity semantics (`poolSnapshotContinuityKey`)

**Memo (L745–758):**

| Runtime | Key |
| ------- | --- |
| Tron | `tokenAddress \| runtimeWalletAddress` |
| EVM | `tokenAddress \| address \| isConnected \| isEthereumNetwork \| isWrongNetwork` |

**Effect (L761–783):**

- **Purpose (Phase 48 / 53.3):** On pool token or owner change, **seed** `balanceSnapshotRef` from last committed display snapshot so orchestrator/UX does not flash zero while new reads are in flight.
- **Does not** reset `tokenMetaFetched` / `balancesFetched`.
- **Does not** update React balance state — ref-only seed.
- **Tron:** Requires valid `runtimeWalletAddress`.
- **EVM:** Requires connected, correct ethereum network, not wrong network.

**Interaction with reset:** If both keys change in one render generation, effect order is reset (L725) then continuity (L761) — continuity may immediately reseed from `lastDisplayBalancesRef` (also zeroed by reset), net zero seed.

---

## 7. Invalidation graph

```mermaid
flowchart LR
  subgraph vault_inv [Vault invalidation]
    TFG[tronPassiveFetchGenRef++]
    RK[refreshKey++]
    STOP[orchestrator dispose]
  end

  subgraph orch_inv [Orchestrator invalidation]
    IG[invalidationGen++]
    ABORT[abortCtrl.abort]
    PM[pendingMask OR= semantic]
  end

  subgraph coord [Coordinator gates]
    REF_G[canRuntimeOperationRefresh]
    COM_G[canRuntimeOperationCommit captured vs latest]
    DEV[canRuntimeOperationCommitWithDevTrace vault]
  end

  PM --> IG
  STOP --> IG
  STOP --> ABORT
  TFG --> RPB_STALE[Tron RPC dropped]
  RK --> PM
  REF_G --> TICK_SKIP[tick skip]
  COM_G --> COM_SKIP[onCommit skip]
  DEV --> VAULT_SKIP[Tron/orchestrator vault skip]
```

| Mechanism | Scope | When |
| --------- | ----- | ---- |
| `tronPassiveFetchGenRef` | Tron balance RPC only | New fetch; interval cleanup |
| `invalidationGen` + `abortCtrl` | Orchestrator tick | Session stop, restart |
| `pendingMask` | Next orchestrator tick | Any `notifyStakingRefresh*` |
| `refreshKey` | Indirect (EVM) | Post deposit/withdraw |
| `isMountedRef` | All vault async commits | Unmount |
| Coordinator refresh gate | Orchestrator tick | Sequence stage / lifecycle |
| Coordinator commit gate | Orchestrator `onCommit` + vault traces | Transition generation drift |

**`notifyStakingRefresh` fanout map:**

| Caller | Raw / semantic | EVM | Tron |
| ------ | -------------- | --- | ---- |
| `refreshBalances` | wallet-state-change | pendingMask | refetch via ref |
| `refreshKey` effect | tx-state-change | pendingMask | no-op (orch stopped) |
| Orchestrator start | network + wallet | initial mask | — |
| Orchestrator visibility | visibility-state-change | pendingMask | — |
| `StakingAppBalance` | profit-boundary → periodic-sync | pendingMask | — |
| Diagnostics / DEV suites | various | pendingMask | — |

---

## 8. Unsafe extraction zones

| Zone | Why unsafe alone |
| ---- | ---------------- |
| EVM orchestrator effect (L846) without `balanceSnapshotRef` | `getPrevious` / `onCommit` closure owns ref |
| Tron interval (L946) without `refetchTronPassiveBalances` + refs | Same ref writes |
| `vaultBalanceResetKey` without continuity | Stale seed or zero flash wrong |
| `poolSnapshotContinuityKey` without reset family | Race on wallet change |
| `refreshBalances` without `tronPassiveRefetchRef` effect order | Rules of Hooks / undefined ref |
| `refreshKey` effect without tx call sites | Post-tx EVM stale balances |
| Moving orchestrator module into hook without stop on unmount | Global singleton leak |
| Splitting fast/slow reads into vault | Today legacy deployment in orchestrator only |
| Passing `stakingReadOptions` into orchestrator without product decision | Changes RPC routing (Phase 19 note) |

---

## 9. Minimal-safe extraction boundary

**Allowed in D3b3 without behavior change (if done as one atomic PR):**

| Piece | Notes |
| ----- | ----- |
| `useStakingVaultBalanceRefresh({ refBag, setters, transition, … })` | Single hook file |
| Ref bag created in composer | `balanceSnapshotRef`, `lastDisplayBalancesRef`, `observedBalanceRef`, `tronPassiveRefetchRef`, `tronPassiveFetchGenRef`, `tronPassiveReadFailStreakRef` |
| Move callbacks | `refreshBalances`, `refetchTronPassiveBalances` |
| Move effects | Reset, continuity, orchestrator, Tron interval, refreshKey — **preserve registration order via split mount helpers** |
| Re-export `refreshBalances` on vault return | Composer destructures hook result |

**Still in composer after D3b3:**

- `useRuntimeTransitionSnapshot()`
- Token reads hook + chain reconciliation before loadMeta
- History, tx, diagnostics, return wrapper

**Not in D3b3 minimal slice:**

- Changing orchestrator module location
- Threading `stakingReadOptions` into orchestrator
- Fixing Tron post-tx refresh gap (behavior change)

---

## 10. Recommended D3b3 shape

### Proposed files

```
src/staking/refresh/
  types.ts                    # BalanceRefBag, RefreshSetters, RefreshInputs
  useStakingVaultBalanceRefresh.ts
  index.ts
```

### Hook surface

```typescript
type BalanceRefBag = {
  balanceSnapshotRef: MutableRefObject<BalanceSnapshot>
  lastDisplayBalancesRef: MutableRefObject<BalanceSnapshot>
  observedBalanceRef: MutableRefObject<{ balance: bigint; anchorMs: number } | null>
  tronPassiveRefetchRef: MutableRefObject<(() => void) | null>
  tronPassiveFetchGenRef: MutableRefObject<number>
  tronPassiveReadFailStreakRef: MutableRefObject<number>
}

// Returns:
refreshBalances
refetchTronPassiveBalances  // if needed externally (rehydrate)
// Side-effect registration via sub-helpers (mirror D3b2 token pattern):
useStakingVaultBalanceRefreshResetAndContinuity(...)
useStakingVaultBalanceRefreshOrchestrator(...)
useStakingVaultBalanceRefreshTronPolling(...)
useStakingVaultBalanceRefreshTxNotify(refreshKey)
```

### Composer call order (unchanged)

1. Create ref bag + balance React state  
2. `useStakingVaultTokenReads` + asset lifecycle + …  
3. Define `refreshBalances` / register Tron ref **or** receive from balance hook after token effects slot  
4. **`useStakingVaultBalanceRefreshResetAndContinuity`** (L725, L761)  
5. Chain reconciliation + loadMeta  
6. **`useStakingVaultBalanceRefreshTxNotify`** (L840)  
7. **`useStakingVaultBalanceRefreshOrchestrator`** (L846)  
8. **`useStakingVaultBalanceRefreshTronPolling`** (L946)  

### PR strategy

| PR | Content |
| -- | ------- |
| D3b3 | Full balance refresh hook + composer wiring only |
| D3c | History (separate) |
| D3d | Tx methods |

### Verification matrix (manual)

1. EVM connect → balances populate via orchestrator  
2. Tron connect → 45s + visibility refetch  
3. Runtime swap EVM ↔ Tron → reset then repopulate  
4. Wrong network → no stale caps; `balancesFetched` not stuck  
5. Deposit/withdraw EVM → balance updates within fast/slow floors  
6. `refreshBalances` → EVM notify + Tron refetch  
7. Pool token change → continuity seed (no zero flash)  
8. Runtime transition during tick → commit suppressed, no corrupt snapshot  

---

## Related code anchors (post-D3b2)

| Concern | File | Lines (approx) |
| ------- | ---- | -------------- |
| Refs + refreshKey | `useStakingVault.ts` | 302–352 |
| refreshBalances / Tron refetch | `useStakingVault.ts` | 488–603 |
| Reset + continuity | `useStakingVault.ts` | 708–783 |
| refreshKey + orchestrator | `useStakingVault.ts` | 840–944 |
| Tron polling | `useStakingVault.ts` | 946–1002 |
| Orchestrator tick/commit | `stakingRefreshOrchestrator.ts` | 333–528 |
| Session lifecycle | `stakingRefreshOrchestrator.ts` | 542–599 |

---

*Generated for Architecture Consolidation Phase D3b3a. No production code modified.*
