# Staking network topology (Phase E1)

This document describes the **execution plane**, **runtime plane**, and **network glue** boundaries for `useStakingVaultState`. It is the source of truth for Phase G (deprecated bridge removal).

## Planes

### Runtime plane

- **Owner:** `useStakingVaultRuntimeContext`, `useStakingVaultRuntimePlanes`
- **Identity:** `stakingRuntime.deployment` (CAIP-2, chain family, labels)
- **Passive Tron:** `runtimeWallet` (TronLink `networkOk`, address, chain id)
- **Selection:** `useRuntimeTransitionSnapshot` — EVM ↔ Tron runtime swap

Runtime answers: *which deployment are we operating on?* and *is the passive wallet on the right network?*

### Execution plane (EVM tx)

- **Owner:** AppKit eip155 account inside runtime planes
- **Fields:** `executionAddress`, `executionConnected`, `executionChainId`, `executionNetworkOk`, `signer`, `provider`
- **Scope:** Deposit, withdraw, approve — EVM signing only

Execution answers: *can we sign an EVM transaction on the expected chain?*

### Network glue plane

- **Owner:** `@/staking/runtime/network` (`useStakingVaultNetworkGlue`)
- **Responsibilities:**
  - Auto-switch when connected on wrong EVM chain
  - Manual `requestNetworkSwitch` (orchestration + AppKit fallback)
  - EVM chain reconciliation **before** `loadMeta`
  - Switch-verify polling (150ms / 1500ms max)
  - Tron passive: invalidate meta/balances + refetch on successful switch

Network glue does **not** own token reads, balance refresh orchestration, or tx execution.

## Chain semantics

| Signal | EVM | Tron passive |
| ------ | --- | ------------ |
| `numericChainId` | AppKit chain id | N/A for reconcile |
| `isWrongNetwork` | `connected && ethereum && chainId !== expected` | `hasAccount && !networkOk` |
| `executionNetworkOk` | `executionConnected && executionChainId === expected` | Not used for tx |
| `canTransact` | Requires signer + correct network + meta | Tron path via runtime wallet |

Derived in vault composer via `selectIsWrongNetwork`, `selectExecutionNetworkOk`, `selectCanTransact` — **not** inside network glue.

## Registration order (forbidden to reorder)

1. Runtime + composer refs + network refs
2. Token reads, balance/tx state
3. Identity: `isWrongNetwork`, wallet orchestration, early history clear
4. Lifecycle mount + **network chain mirrors** (`numericChainIdRef`, `tokenMetaErrorRef`)
5. **Refresh plane:**
   1. Asset lifecycle
   2. Balance refresh callbacks
   3. Tron ref wiring
   4. Reset / continuity
   5. **Network glue** (reconciliation + switches)
   6. **`loadMeta` mount**
   7. Tx-notify → orchestrator → Tron polling
6. History plane → presentation → tx execution → diagnostics → public assembly

## Reconciliation flow (EVM-only)

```
connected + numericChainId known
  → chainId === expected?
      yes → clear poll, reset switch flags, clear WRONG_NETWORK → loadMeta
      no  → if !hasTriedSwitch && meta !== WRONG_NETWORK → auto-switch
non-EVM runtime → clear poll/flags, no reconcile body
```

## Auto-switch flow

1. `switchNetwork(STAKING_APPKIT_NETWORK)`
2. Poll `numericChainIdRef` every 150ms up to 1500ms
3. On timeout: set `tokenMetaError = WRONG_NETWORK`, toast once (deduped)

## Manual switch flow

1. `walletOrchestration.requestNetworkSwitch(caip2)`
2. **Tron:** on success → reset fetched flags → `refetchTronPassiveBalances`
3. **EVM:** if not switched → `handleAutoSwitch`

## Wrong-network flow

- **UI:** `isWrongNetwork` drives CTA, navbar chip, `canTransact === false`
- **History:** early vault effect clears history via glue ref when wrong
- **Runtime swap during wrong network:** reconciliation effect keyed on `chainFamily`; Tron branch clears EVM poll state

## AppKit interaction boundaries

| Concern | AppKit / planes | Network glue |
| ------- | ---------------- | ------------ |
| Connect / disconnect | Runtime planes | — |
| `switchNetwork` | Exposed on planes | Called by auto-switch |
| CAIP-2 switch request | Wallet orchestration | `requestNetworkSwitch` |
| EVM isolation on passive Tron | `useAppKitEvmIsolationOnPassiveTron` (hook) | Must not publish Tron as EVM chain |

## DEV topology assertions

`stakingNetworkTopologyDev.ts` + `stakingVaultPublicTopology.ts`:

- EVM runtime must not publish Tron-only `runtimeWallet.networkOk` without account
- Tron runtime must not expose live `executionChainId` while `executionConnected`
- Reconciliation effect must register before `loadMeta` mount (module-level DEV flags)
- Public API keys frozen in `STAKING_VAULT_PUBLIC_TOPOLOGY_KEYS`

## Module map

| Module | Role |
| ------ | ---- |
| `stakingNetworkContracts.ts` | Ownership table, constants, wrong-network truth table |
| `stakingNetworkDtos.ts` | Glue input builder |
| `useStakingVaultNetworkGlue.ts` | Hooks: refs, mirrors, glue |
| `stakingNetworkTopologyDev.ts` | DEV assertions |
| *(removed G4d)* | `useStakingVaultEvmNetworkGlue` — **deleted**; use `useStakingVaultNetworkGlue` only |

## Phase G prep

Network glue is extracted; **deprecated bridge** (`address`, `isConnected` aliases, `withDeprecatedVaultBridgeDevInstrumentation`) remains on the public return until Phase G.
