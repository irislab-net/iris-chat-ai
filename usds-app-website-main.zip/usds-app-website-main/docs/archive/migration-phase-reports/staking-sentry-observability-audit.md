# Staking Sentry Observability Audit

**Date:** 2026-05-16  
**Scope:** `src/staking/**`, wallet/AppKit, runtime orchestration, tx/hydration/refresh, mobile resume  
**Goal:** High-signal production observability without architecture rewrites.

---

## 1. Executive summary

Before this phase, Sentry was partially wired (connect stall, tx signature stall, sparse breadcrumbs, exception capture with UX suppression). **Phase-43 `runtimeTelemetry`** emitted aggregate health events but used a generic `[runtimeTelemetry]` Sentry sink.

This phase adds a **canonical taxonomy**, **structured tags/contexts**, **dedupe/cooldown**, **runtimeTelemetry→Sentry bridge**, **vault_tx_loading stall watchdog**, **disabled runtime-family invariant**, **production runtime-swap failure reporting**, and **visibility/tx lifecycle breadcrumbs**.

---

## 2. Silent-failure map (pre-audit → mitigation)

| Zone | Silent behavior | Mitigation |
|------|-----------------|------------|
| `useEtheriumWallet` getSigner reject | Breadcrumb + exception (existing) | Tagged `staking.hydration.signer_hydration_stalled` + contexts |
| Persisted hydrate reconcile gate deny | `emitRuntimeTelemetry` only | Bridge → `staking.hydration.reconcile_failure` |
| Persisted hydrate `.catch` | `captureStakingException` | Unchanged; tagged reconcile context |
| Orchestrator commit skip ≥8 | `orchestrator_starvation` telemetry | Bridge → `staking.refresh.orchestrator_starvation` |
| Balance commit wall >240s | `staking_balance_refresh_wall_stall` | Bridge → `staking.refresh.balance_wall_stall` |
| `executeRuntimeSwap` protocol fail | DEV `traceRuntimeSwapDenied` only | Production `reportStakingInvariantViolation` |
| Disabled Tron family active row | Registry filters at build; runtime unchecked | `useStakingRuntimeFamilyParticipationCheck` |
| `vault_tx_loading` gate stuck | Connect stall watchdog (partial) | Dedicated `useStakingVaultTxLoadingStallWatchdog` |
| Vault tx lease abandoned | `publishStakingVaultTxExecutionAbandonReason` DEV string | `staking.async.stale_operation` (deduped) |
| BFCache AppKit reload fail | `captureStakingException` | `staking.mobile.bfcache_restore_failed` event tag |
| User reject / wrong network | Swallowed by `beforeSend` | Intentional — not errors |

---

## 3. Runtime deadlock map

| Deadlock pattern | Detection | Event |
|------------------|-----------|-------|
| Partial wallet connect + stall gate ≥10s | `useStakingConnectStallWatchdog` | `staking.runtime.connect_stalled` |
| `vault_tx_loading` (loading && !awaitingSigner) ≥12s | `useStakingVaultTxLoadingStallWatchdog` | `staking.runtime.vault_tx_loading_stalled` |
| Mobile awaiting_signature ≥15s | `useStakingTxSignatureStallWatchdog` | `staking.tx.awaiting_signature_stalled` |
| Refresh commit denied loop | telemetry `orchestrator_starvation` | `staking.refresh.orchestrator_starvation` |
| No balance commit 240s visible | telemetry wall stall | `staking.refresh.balance_wall_stall` |
| Runtime swap incomplete controller | `executeRuntimeSwap` fail | `staking.invariant.runtime_swap_final_failed` |

### vault_tx_loading dependency chain

```
useStakingVaultTxExecution.deposit/withdraw
  → acquireVaultTxExecutionLoading(op)   // useStakingVaultComposerTxState
  → setLoading(true)
  → finally releaseVaultTxExecutionLoading(lease) → setLoading(false)

resolveStakingConnectBlockingGateDetailed
  → loading && !awaitingSigner → reason "vault_tx_loading"

Abandon path (modal reset / stale snapshot):
  → abandonVaultTxExecutionLoading(reason)
  → publishStakingVaultTxExecutionAbandonReason → staking.async.stale_operation
```

---

## 4. High-risk async zones

| Location | Risk | Visibility |
|----------|------|------------|
| `TransactionStatusProvider` persisted hydrate async | Stale generation / commit gate | reconcile telemetry + Sentry bridge |
| `canRuntimeOperationCommitWithDevTrace` | Stale async commit | `repeated_async_commit_denied` bridge |
| `useEtheriumWallet` getSigner promise | Cancelled vs failed | hydration breadcrumbs + exception |
| `stakingTxWrapReceiptWaitWithDepositWithdrawRefresh` | Orphan receipt handler | tx breadcrumbs + `tx_failed` on receipt err |
| `executeRuntimeSwap` multi-stage controller | Partial swap | invariant on non-policy fail |
| Refresh orchestrator `tick` | inFlight + coordinator gates | orchestrator_starvation / balance_wall_stall |

---

## 5. Newly instrumented events

See `docs/staking-sentry-event-taxonomy.md` for the full table.

**Code entry points:** `src/lib/stakingSentry/*`, watchdogs under `src/staking/diagnostics/useStaking*`.

---

## 6. Dedupe strategy

- **Session Set:** first emission per `dedupeKey` for stall/invariant classes (`oncePerSession: true` default).
- **Cooldown map:** per event name (e.g. connect stall 600s, vault tx loading 300s).
- **Global runtime telemetry:** existing 24/min burst cap unchanged; bridge respects staking dedupe.
- **No render-loop hooks:** watchdogs use `setTimeout` + gate keys only.
- **Breadcrumbs:** `runtime_ready` once per session; visibility events on real DOM events only.

---

## 7. Missing production visibility (remaining blind spots)

| Area | Gap | Recommended priority |
|------|-----|----------------------|
| Trust Wallet deep-link handoff | DEV `stakingTxMobileDeepLinkTrace` only | P1: mobile deep-link stall timer |
| `eth_accounts` malformed response | No parser-level Sentry | P1: wrap AppKit account read |
| WalletConnect partial hydration | Detected indirectly via connect stall | P2: WC session phase tags |
| Firebase / AppCheck failures | Taxonomy defined, not wired | P2: hook `useAffiliateFirestoreStats` error path |
| Provider reconnect loop | Telemetry name only | P2: bridge already maps; verify rollout stage ≥1 |
| Hook order invariant | DEV-only assertions | P3: React error boundary fingerprint |
| Tron passive read failures | `tron_passive_read_repeated_failure` bridge | P2: confirm Tron rollout observability |
| Hydration poison downstream state | Partial (context on signer fail) | P2: snapshot uiPhase on next stall |

---

## 8. Recommended future priorities

1. **Deep-link stall watchdog** — arm on `wallet_sendTransaction_start`, disarm on `pageshow` + visibility visible (mobile only).
2. **Receipt orphan detector** — dedupe by tx hash when `receiptHandlerRegistered` ages out.
3. **Sentry dashboards** — one dashboard per namespace; alert on `staking.invariant.*` and `staking.runtime.connect_stalled`.
4. **Sample rate** — keep `tracesSampleRate: 0`; use issue alerts + structured messages only.
5. **Wire firebase/appcheck** taxonomy events on first production failure paths.

---

## 9. Validation checklist

- [x] No console spam (no new `console.log` in production paths)
- [x] No render-loop reporting (watchdogs timer-based)
- [x] Dedupe on all stall/invariant structured events
- [x] `pnpm typecheck` / `pnpm build` (run in CI locally)
- [x] Tx lifecycle behavior unchanged (breadcrumbs only in execution path)
- [x] Build uses existing `@sentry/react` — no new dependency

---

## 10. File index

| Path | Role |
|------|------|
| `src/lib/stakingSentry/` | Canonical module |
| `src/lib/stakingSentryObservability.ts` | Re-export barrel |
| `src/lib/sentry.ts` | Init + UX suppression |
| `src/staking/diagnostics/useStakingConnectStallWatchdog.ts` | Connect stall |
| `src/staking/diagnostics/useStakingVaultTxLoadingStallWatchdog.ts` | vault_tx_loading stall |
| `src/staking/diagnostics/useStakingTxSignatureStallWatchdog.ts` | Signature stall |
| `src/staking/diagnostics/useStakingRuntimeFamilyParticipationCheck.ts` | CFG6 family guard |
| `src/lib/runtimeTelemetry/runtimeTelemetry.ts` | Aggregate telemetry (unchanged) |
