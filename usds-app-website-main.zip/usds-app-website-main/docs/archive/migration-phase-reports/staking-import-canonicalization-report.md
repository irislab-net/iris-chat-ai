# Staking import canonicalization report (Phase G3)

Import-only migration: app/components/hooks/staking consumers now import from `@/staking/*` canonical barrels. **No shim deletion, no bridge removal, no logic changes.**

Verification: `pnpm typecheck` ✅ · `pnpm build` ✅

---

## 1. Summary

| Metric | Count |
|--------|------:|
| Files with import path updates | **37** |
| New canonical re-export bridges (tron) | **2** |
| Barrel export gaps fixed (build) | **2** (`execution`, `cta`) |
| Remaining non-shim `from "@/lib/staking/*"` consumers | **2** |
| Remaining non-shim `from "@/lib/tron/*"` consumers | **0** (only canonical bridges) |
| Remaining hook/service/wallet legacy import consumers | **0** |

---

## 2. Migrated files (37)

### App / layout / providers

- `src/components/layout/NavbarWalletSection.tsx`
- `src/components/pages/staking/StakingAppBalance.tsx`
- `src/components/pages/staking/StakingAppDepositForm.tsx`
- `src/components/pages/staking/StakingAppErrorSurface.tsx`
- `src/components/pages/staking/StakingAppReferral.tsx`
- `src/components/pages/staking/StakingAppTransactionHistory.tsx`
- `src/components/pages/staking/StakingAppWithdrawForm.tsx`
- `src/components/pages/staking/StakingAssetSelectSubtree.tsx`
- `src/components/pages/staking/StakingCtaEllipsisLabel.tsx`
- `src/components/pages/staking/StakingCtaReason.tsx`
- `src/components/pages/staking/StakingTermsConsentProvider.tsx`
- `src/components/pages/staking/TransactionStatusContext.tsx`
- `src/components/pages/staking/transactionStatusModel.ts`
- `src/components/pages/staking/TransactionStatusProvider.tsx`
- `src/components/pages/staking/TransactionStatusSurface.tsx`
- `src/providers/BootstrapOrchestrationProvider.tsx`

### Hooks / lib

- `src/hooks/useAppKitTronIdentityDiagnostics.ts`
- `src/hooks/useStakingCtaState.ts`
- `src/hooks/useStakingEthUsdPresentation.ts`
- `src/hooks/useStakingFeeDisplaySmoothing.ts`
- `src/hooks/useStakingGasEstimate.ts`
- `src/hooks/useStakingVault.ts`
- `src/lib/stakingProduct/stakingProductUserMessages.ts`
- `src/lib/stakingUiPhase.ts`
- `src/lib/stakingAffiliateTxHistory.ts`
- `src/lib/tron/tronTransactionHistory.ts` (internal dep → `@/staking/execution`)

### Staking tree

- `src/staking/history/useStakingVaultHistory.ts`
- `src/staking/identity/tron/resolveUnifiedTronIdentity.ts`
- `src/staking/orchestration/openUnifiedWallet.ts`
- `src/staking/runtime/network/stakingNetworkDtos.ts`
- `src/staking/runtime/useStakingVaultRuntimePlanes.ts`
- `src/staking/selectors/stakingVaultDisplaySelectors.ts`
- `src/staking/vault/composer/useStakingVaultEvmNetworkGlue.ts`
- `src/staking/vault/composer/useStakingVaultRefreshPlane.ts`

### Docs-only reference (comment)

- `src/constants/stakingNotificationSpec.ts` (comment already pointed at `@/staking/ui`)

---

## 3. Import mapping applied

| Legacy | Canonical |
|--------|-----------|
| `@/lib/staking/stakingToast`, `stakingInputStyles`, `stakingAmountSliderVisual` | `@/staking/ui` |
| `@/lib/staking/stakingPassiveNotificationPolicy`, `receipt*SonnerPolicy` | `@/staking/notifications` |
| `@/lib/staking/stakingCta*`, `stakingFormInlineReasonResolver`, `stakingSnapshotCtaPhase` | `@/staking/cta` |
| `@/lib/staking/stakingRefreshOrchestrator` | `@/staking/refresh` |
| `@/lib/staking/stakingFeeCanonical` | `@/staking/tx` |
| `@/lib/staking/buildNetworkFeePresentation` | `@/staking/execution` |
| `@/lib/staking/stakingMobileResumeCoordinator` | `@/staking/orchestration` |
| `@/lib/staking/stakingTxIntegrityDev` | `@/staking/diagnostics` |
| `@/lib/stakingEtherscanHistory` | `@/staking/execution` |
| `@/hooks/useStakingGasToastDedupe` | `@/staking/execution` |
| `@/services/gasEstimator` | `@/staking/execution` |
| `@/lib/stakingTxMobileLifecycleDebug` | `@/staking/diagnostics` |
| `@/hooks/useUnifiedWalletOrchestration` | `@/staking/orchestration` |
| `@/lib/tron/tronWalletIdentity` | `@/staking/identity/tron/tronWalletIdentity` |
| `@/lib/tron/tronTransactionHistory` | `@/staking/history/tronTransactionHistory` |
| `@/staking/core/runtimeSwapEngine`, `runtimeSwapPolicy` | `@/staking/orchestration` |

---

## 4. New canonical bridges (G3)

| File | Role |
|------|------|
| `src/staking/identity/tron/tronWalletIdentity.ts` | Re-exports passive Tron identity from `lib/tron` |
| `src/staking/history/tronTransactionHistory.ts` | Re-exports Tron history loader from `lib/tron` |

Implementation stays in `lib/tron/*` until G4 move/delete.

---

## 5. Grep evidence (required checks)

### `@/lib/staking/` — `from` imports

```
src/hooks/useProfitManagerStatus.ts          → profitManagerStatusSingleton (BLOCKED)
src/providers/TelegramEscalationProvider.tsx → originalTelegramUrl (BLOCKED)
```

All other matches are **shim files** (`src/lib/staking/*` DEV warning strings) or **diagnostics message text**.

### `@/lib/tron/`

```
src/staking/identity/tron/tronWalletIdentity.ts   (canonical bridge only)
src/staking/history/tronTransactionHistory.ts       (canonical bridge only)
```

### `@/services/gasEstimator` · `@/hooks/useStakingGasToastDedupe` · `@/lib/stakingTxMobileLifecycleDebug` · `@/hooks/useUnifiedWalletOrchestration` · `@/lib/wallet/openUnifiedWallet`

**0** non-shim `from` imports. Shims remain:

- `src/services/gasEstimator.ts`
- `src/hooks/useStakingGasToastDedupe.ts`
- `src/lib/stakingTxMobileLifecycleDebug.ts`
- `src/hooks/useUnifiedWalletOrchestration.ts`
- `src/lib/wallet/openUnifiedWallet.ts`

### `@/staking/core/*` orchestration shims

**0** non-shim `from "@/staking/core/runtimeTransitionCoordinator|runtimeSwapEngine|runtimeSwapPolicy"` imports.

### `@/lib/stakingEtherscanHistory`

**0** non-shim `from` imports (shim: `src/lib/stakingEtherscanHistory.ts` only).

---

## 6. Remaining legacy imports (non-shim consumers)

| File | Legacy import | Blocker |
|------|---------------|---------|
| `src/hooks/useProfitManagerStatus.ts` | `@/lib/staking/profitManagerStatusSingleton` | No `@/staking/*` home yet |
| `src/providers/TelegramEscalationProvider.tsx` | `@/lib/staking/originalTelegramUrl` | No `@/staking/*` home yet |

**Count: 2** (intentionally left for G4+).

---

## 7. Ignored shim files (do not delete in G3)

### `src/lib/staking/*` (~36 modules)

All `@deprecated` re-exports to `@/staking/*` with DEV warnings.

### Hook / service / lib shims

- `src/hooks/useUnifiedWalletOrchestration.ts`
- `src/hooks/useStakingGasToastDedupe.ts`
- `src/services/gasEstimator.ts`
- `src/lib/stakingTxMobileLifecycleDebug.ts`
- `src/lib/stakingEtherscanHistory.ts`
- `src/lib/wallet/openUnifiedWallet.ts`

### Core orchestration shims

- `src/staking/core/runtimeTransitionCoordinator.ts`
- `src/staking/core/runtimeSwapPolicy.ts`
- `src/staking/core/runtimeSwapEngine.ts`
- `src/staking/core/createTronReceiptResolver.ts` (if present)

### Tron implementation (not yet under `staking/`)

- `src/lib/tron/tronWalletIdentity.ts`
- `src/lib/tron/tronTransactionHistory.ts`

---

## 8. Safe-delete shim candidates (after G4, once blockers resolved)

Delete when grep shows **zero** imports (including the 2 blocked consumers):

1. **All** `src/lib/staking/*` listed in §7 except `profitManagerStatusSingleton.ts` and `originalTelegramUrl.ts` until homes exist.
2. `src/hooks/useUnifiedWalletOrchestration.ts`
3. `src/hooks/useStakingGasToastDedupe.ts`
4. `src/services/gasEstimator.ts`
5. `src/lib/stakingTxMobileLifecycleDebug.ts`
6. `src/lib/stakingEtherscanHistory.ts`
7. `src/lib/wallet/openUnifiedWallet.ts`
8. `src/staking/core/runtimeTransitionCoordinator.ts`
9. `src/staking/core/runtimeSwapPolicy.ts`
10. `src/staking/core/runtimeSwapEngine.ts`
11. G3 tron bridges (`staking/identity/tron/tronWalletIdentity.ts`, `staking/history/tronTransactionHistory.ts`) **after** moving `lib/tron/*` implementations into `staking/`.

---

## 9. G4 blockers

| Blocker | Action for G4 |
|---------|----------------|
| `profitManagerStatusSingleton` | Add `@/staking/vault` or `@/staking/runtime` home; migrate `useProfitManagerStatus` |
| `originalTelegramUrl` | Add `@/staking/notifications` or app-level constant module |
| `lib/tron/*` implementations | Move into `staking/identity/tron` + `staking/history`; delete bridges |
| Public vault bridge fields | Phase G bridge removal (separate from import migration) |
| `useStakingVaultEvmNetworkGlue` composer shim | Delete after all imports use `@/staking/runtime/network` |

---

## 10. Barrel fixes (G3, export surface only)

To satisfy Vite/Rollup after barrel imports:

- `src/staking/execution/index.ts` — export `ethUsdPresentationKey`, `computeEthFeeMicroUsd`, `formatMicroUsdParen`
- `src/staking/cta/index.ts` — export `shouldAnimateStakingPrimaryEllipsis`, `shouldAnimateStakingReasonEllipsis`

No runtime behavior change.

---

## 11. Manual QA checklist

1. `/staking/app` loads  
2. Navbar wallet  
3. EVM connect  
4. Tron passive runtime  
5. Runtime swap  
6. Wrong network  
7. Deposit/withdraw  
8. Tx modal  
9. History  
10. Soak monitor  

---

*Generated: Phase G3 — import canonicalization complete.*
