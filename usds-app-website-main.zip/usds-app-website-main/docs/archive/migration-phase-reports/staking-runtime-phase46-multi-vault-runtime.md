# Phase 46 — Multi-vault runtime configuration and product routing

This phase adds **explicit env-backed sibling deployments** (optional Ethereum block + optional Tron block) to the **normalized deployment registry**, while keeping **independent vault semantics**: no shared liquidity, no cross-chain execution state, no merged balances or APY.

## 1. Env configuration structure

**Primary (unchanged, required):** legacy staking row `legacy-primary` is built from the existing `VITE_STAKING_*` keys in `src/config/env.ts` (`buildLegacyDeploymentFromEnv`).

**Optional explicit Ethereum block (all must be present to ingest one row):**

| Key | Maps to `env.ts` export |
| --- | --- |
| `VITE_STAKING_ETH_VAULT_ADDRESS` | `STAKING_ETH_VAULT_ADDRESS` |
| `VITE_STAKING_ETH_CHAIN_ID` | `STAKING_ETH_CHAIN_ID_RAW` |
| `VITE_STAKING_ETH_RPC_URL` | `STAKING_ETH_RPC_HTTP_URL` |
| `VITE_STAKING_ETH_NETWORK_LABEL` | `STAKING_ETH_NETWORK_LABEL` |
| `VITE_STAKING_ETH_EXPLORER_BASE_URL` | `STAKING_ETH_EXPLORER_BASE_URL` |
| `VITE_STAKING_ETH_EXPLORER_LABEL` | `STAKING_ETH_EXPLORER_LABEL` |

**Optional within the block:** `VITE_STAKING_ETH_WS_URL`, `VITE_STAKING_ETH_CAIP2` (defaults `eip155:{chainId}` when omitted).

**Optional explicit Tron block (all must be present to ingest one row):**

| Key | Maps to `env.ts` export |
| --- | --- |
| `VITE_STAKING_TRON_VAULT_ADDRESS` | `STAKING_TRON_VAULT_ADDRESS` |
| `VITE_STAKING_TRON_RPC_URL` | `STAKING_TRON_RPC_HTTP_URL` |
| `VITE_STAKING_TRON_NETWORK_LABEL` | `STAKING_TRON_NETWORK_LABEL` |
| `VITE_STAKING_TRON_EXPLORER_BASE_URL` | `STAKING_TRON_EXPLORER_BASE_URL` |
| `VITE_STAKING_TRON_EXPLORER_LABEL` | `STAKING_TRON_EXPLORER_LABEL` |

**Optional:** `VITE_STAKING_TRON_CAIP2` (defaults `tron:mainnet` when omitted).

**Partial blocks:** if any required field in a block is missing, that block is skipped (no half rows). Invalid values append **ingest notes** and the row is dropped.

**Implementation:** `src/staking/core/buildExplicitEnvDeploymentRows.ts` → `collectExplicitEnvNormalizedDeployments(ingestNotes)`.

## 2. Deployment registry structure and merge order

1. **`buildNormalizedLegacyRegistry()`** — always includes **`legacy-primary`** first; `defaultDeploymentId` stays **`legacy-primary`**.
2. **`mergeExplicitEnvDeploymentRowsIntoRegistry`** — appends at most two rows: `env-explicit-ethereum`, `env-explicit-tron` (ids from `src/staking/core/types.ts`), deduped by **`deriveProviderRuntimeKey`** and **deployment id** against existing rows.
3. **`mergeOptionalDeploymentsJsonIntoRegistry`** — appends `VITE_STAKING_DEPLOYMENTS_JSON` rows with the same dedupe rules.

**Validation:** `validateStakingDeploymentRegistryFull` on the merged candidate. On **error** severity, the public API falls back to **legacy-only** (same as Phase 16 JSON behavior).

**Code:** `src/staking/core/getStakingDeploymentRegistry.ts`.

## 3. Runtime routing model (product vs execution)

| Layer | Behavior |
| --- | --- |
| **Registry** | Lists every valid row; each row remains **isolated** (own vault address, RPC, explorer, labels, `chainFamily`). |
| **Execution capability** | `isDeploymentRuntimeExecutable` in `runtimeCapabilities.ts` is **`true` only for `legacy-primary` EVM**. Other EVM rows are **passive EVM** (reads/receipts policy may apply; no staking execution). Tron rows are **passive Tron**. |
| **Product routing helper** | `src/lib/stakingProduct/stakingProductRouting.ts` — `listStakingProductNetworkChoices`, `resolveStakingProductDefaultDeploymentId`, `stakingProductUnsupportedExecutionHint`, `stakingProductCapabilitiesForDeploymentId`. Chooses **presentation** and capability flags; it does **not** merge vault accounting. |

**Future:** when multiple **executable** pools are allowed, routing can pick among executable rows using **selected network**, **wallet compatibility**, and **availability** — still **one active execution target** at a time, no shared tx queue across families.

## 4. Transaction isolation guarantees

- **Ethereum txs** (MetaMask / WalletConnect EVM): ethers `Signer`, EVM RPC, EVM receipts — all bound to the **active EVM execution deployment** (`assertExecutableDeployment` / execution-target guards in vault flows).
- **Tron txs:** there is **no** shared queue with EVM; Tron-specific paths (where present) use Tron HTTP + Tron receipt style polling in the provider stack, separate from EVM signing.
- **No synthetic cross-chain state:** coordinator / modal flows use **frozen execution targets** so a hash from one runtime is not “completed” under another (`TransactionStatusProvider` + execution target checks).
- **Hydration / recovery:** each family’s receipts and history indexing remain **keyed by deployment / CAIP-2**; the app does not merge two vaults into one logical position.

## 5. Balance + history presentation

- **Allowed:** group or filter UI by **product** / **network label** / **`routingKey`** (catalog from Phase 45).
- **Not allowed:** one combined on-chain balance, one blended APY, or one “merged” execution progress across Ethereum and Tron vaults.

## 6. Wallet compatibility matrix (explicit validation target)

| Wallet / connector | Ethereum staking (this app) | Tron registry row |
| --- | --- | --- |
| **MetaMask (EVM)** | Supported for **legacy-primary** execution when chain matches. | **Not** used for Tron; Tron requires Tron-capable stack. |
| **TronLink** | **Not** an EVM signer here. | Use only for **Tron**-family interactions if/when Tron execution is enabled; today rows are passive-capability gated. |
| **WalletConnect (EVM)** | Same rules as other EVM wallets — must match expected chain for staking actions. | WC sessions are **chain-specific**; do not assume one session drives both families. |
| **Wrong wallet / wrong chain** | UI: **“Wrong network”** on balance CTA + switch flow (`StakingAppBalance`); policy denials use `RUNTIME_SWAP_POLICY_DENIAL_MESSAGES` (`runtimeSwapPolicy.ts`). | `stakingProductUnsupportedExecutionHint` explains passive Tron / non-legacy EVM rows without implying cross-chain staking. |

## 7. Unsupported-wallet / unsupported-runtime UX

- **Passive row selected or visible:** plain-language hint from `stakingProductUnsupportedExecutionHint` (separate Tron vault vs passive Ethereum deployment).
- **Runtime swap denied:** `policy_wallet_compatibility_denied` → *“Your wallet can’t use that network for staking yet.”* (product language, no internal jargon).
- **Execution inadequate:** `policy_target_execution_inadequate_for_active_path` → capability-aware denial string.

## 8. “Safe independent-vault architecture?” conclusion

**Yes, for the stated invariant:** Ethereum and Tron remain **independent vault systems** at the contract and transaction layers. The app adds **registry capacity + unified product vocabulary** only. Execution remains **explicitly gated** to **one** legacy EVM row until product policy deliberately enables additional executors — which must keep **per-deployment** tx lifecycle and balances.

## 9. Critical invariant

**Ethereum staking and Tron staking are independent vault systems.** The app provides a **unified product experience** (labels, activity framing, catalog), **not** a merged cross-chain staking protocol.
