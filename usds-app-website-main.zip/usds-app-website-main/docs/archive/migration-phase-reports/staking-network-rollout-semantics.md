# CFG5 — Staking network rollout semantics (`VITE_ENABLE_ETHEREUM` / `VITE_ENABLE_TRON`)

Analysis-only (no behavior changes in the CFG5 pass). This document classifies **where** the two flags take effect, **what stays active** when each is false, and how that compares to informal expectations (“hide rows” vs “disable a chain family”).

---

## 1. Current semantics (as implemented)

### 1.1 What actually reads the flags?

Only two modules call `isStakingEthereumEnabled()` / `isStakingTronEnabled()` (both from `@/config/env`, via `readNetworkFamilyRolloutEnabled`):

| Location | Behavior |
|----------|----------|
| `src/staking/core/buildExplicitEnvDeploymentRows.ts` | Before building optional **explicit env** rows (`VITE_STAKING_ETH_*` / `VITE_STAKING_TRON_*`), the corresponding flag must be true. If false, that row is **never added** to the registry (the builder is not invoked for that family). |
| `src/staking/core/getStakingDeploymentRegistry.ts` | When merging **`VITE_STAKING_DEPLOYMENTS_JSON`**, optional rows with `chainFamily === "evm"` are dropped if Ethereum rollout is false; rows with `chainFamily === "tron"` are dropped if Tron rollout is false. Ingest notes record the skip reason. |

No other staking runtime, wallet, orchestrator, refresh, history, or tx module imports these functions today (`stakingFeatureFlags.ts` only re-exports them).

### 1.2 What is **not** gated by the flags?

- **`legacy-primary`** is always constructed from `VITE_STAKING_*` (vault, chain id, RPC, explorer, etc.) in `buildNormalizedLegacyRegistry()` — **independent** of both rollout flags.
- **Default passive runtime selection** remains **`resolveLegacyStakingDeployment()`** / `getDefaultRuntimeSelection()` today (EVM legacy row).
- **Staking execution** (`isDeploymentRuntimeExecutable`) is defined only for **legacy-primary + EVM** in `runtimeCapabilities.ts` — unrelated to rollout flags.
- **`import.meta.env` / `env.ts`** still parses `VITE_STAKING_ETH_*`, `VITE_STAKING_TRON_*`, `STAKING_TRON_TOKEN_ADDRESS`, etc. Flags do not blank those exports.

---

## 2. Actual runtime behavior when flags are false

### 2.1 `VITE_ENABLE_ETHEREUM=false`

| Layer | Effect |
|-------|--------|
| **Registry** | Legacy-primary **EVM** row **still present**. Explicit env ETH sibling (if configured) **omitted**. JSON deployments with `chainFamily === "evm"` **omitted** (non–legacy-primary rows only; legacy is not ingested from JSON anyway). |
| **Runtime selection** | Default remains **legacy-primary** → full EVM staking path (reads, gas, allowance, txs) **unchanged**. |
| **Execution / tx** | **Unchanged** — still targets legacy-primary EVM. |
| **Wallet (Reown / AppKit)** | **Unchanged** — EVM remains `defaultNetwork` via `STAKING_APPKIT_NETWORK`; adapters unchanged (`reownKit.ts`). |
| **Refresh** | EVM refresh path driven by legacy deployment; **unchanged**. |
| **History** | EVM / Etherscan-style history when `isTronPassiveRuntime` is false; **unchanged**. |
| **UI** | Picker / network choices derive from registry (`listStakingProductNetworkChoices`, etc.): **extra EVM rows** disappear; **legacy EVM** still appears as the sole EVM choice (unless product dedupes oddly—today one EVM row remains). |

**Interpretation:** the flag is **not** “turn off Ethereum”; it is **“hide optional/supplemental EVM registry rows”** (explicit + JSON). Naming is easy to misread.

### 2.2 `VITE_ENABLE_TRON=false`

| Layer | Effect |
|-------|--------|
| **Registry** | Explicit env Tron row **omitted**. JSON `tron` rows **omitted**. |
| **Runtime selection (typical)** | With no Tron deployment in the registry, **production default** stays legacy EVM; `stakingRuntime.deployment.chainFamily` is **`evm`**. |
| **Passive Tron reads / refresh / history** | Code paths branch on **`isTronPassiveRuntime`** / `deployment.chainFamily === "tron"` (e.g. `useStakingVaultTokenReads`, `useStakingVaultBalanceRefresh`, `useStakingVaultHistory`). In the **default** configuration with flags false and no Tron rows, these branches **do not run** for the active runtime. |
| **Wallet (Reown / AppKit)** | **Still always on:** `TronAdapter`, `tronMainnet` / Nile / Shasta networks are registered in `reownKit.ts` **regardless** of `VITE_ENABLE_TRON`. Users can still connect Tron in the wallet modal; staking UI still prefers EIP-155 selection for execution. |
| **Env-backed Tron constants** | `STAKING_TRON_TOKEN_ADDRESS`, `STAKING_TRON_TX_HISTORY_GRID_API_URL`, etc. **remain defined** if present in `.env`; they are simply unused while the active runtime is not Tron (no compile-time or module-init “kill switch”). |

**Interpretation:** for the **staking registry + passive Tron runtime slice**, disabling Tron is **effective** in normal flows (no row → no Tron passive runtime). **Wallet-level Tron** remains available globally.

---

## 3. “Hidden” always-on paths (surprising without this audit)

1. **Registry bootstrap always includes legacy-primary** — rollout flags never skip it.
2. **Reown stack** always includes **Solana + EVM + Tron** adapters and **multiple Tron networks** — not tied to `VITE_ENABLE_TRON`.
3. **`env.ts` sibling env blocks** still populate module exports when keys exist; only **registry merge** suppresses rows.
4. **Internal runtime swap** (`executeRuntimeSwap`) can only swap to deployments that exist in the **current** registry; disabling Tron removes Tron targets but does not remove wallet namespaces.
5. **No guard** ties `isStaking*Enabled` to orchestrator planes, hook order, or tx semantics (by design of current wiring).

---

## 4. Legacy-primary coupling

- **Executable staking** is **hard-coupled** to **`legacy-primary` + `evm`** (`isDeploymentRuntimeExecutable`, `getRuntimeCapabilitiesForDeployment`).
- Rollout flags are **decoupled** from that invariant: they only affect **additional** registry rows (explicit env + JSON optional rows).
- Therefore **`VITE_ENABLE_ETHEREUM`** cannot disable “Ethereum” in the sense of “disable the app’s primary chain”; it only suppresses **extra** EVM registrations.

---

## 5. Toggle classification

| Flag | Cosmetic? | Partial? | Hard-disable family? |
|------|-----------|----------|----------------------|
| `VITE_ENABLE_ETHEREUM` | No (registry/UX change) | **Yes** — **partial**: suppresses non-legacy EVM rows only; legacy EVM + wallet + txs remain. | **No** |
| `VITE_ENABLE_TRON` | No | **Yes** — **partial**: removes Tron from registry; passive Tron runtime inactive in default selection; **wallet Tron** still registered. | **No** (not a global Tron kill switch) |

Overall, the pair behaves as **registry / product-surface rollout toggles**, not **family-level circuit breakers**.

---

## 6. Safe future options

### A. Registry-only toggles (current behavior, documented)

- **Pros:** Minimal risk; preserves legacy-primary execution; clear separation: “what appears in deployment picker / passive rows.”
- **Cons:** Names like `ENABLE_ETHEREUM` over-promise; operators may expect chain-wide disable.

**Recommendation:** treat as canonical unless product explicitly renames (e.g. `VITE_STAKING_REGISTRY_ENABLE_EXPLICIT_ETH` / `..._JSON_ETH`).

### B. Full runtime disable (family-level)

Would require, at minimum:

- **Ethereum “off”:** redefine or gate **legacy-primary** construction, **default AppKit network**, **all EVM read/tx entrypoints**, and likely show a dedicated “staking unavailable” state — **breaking** today’s contract that legacy is always executable.
- **Tron “off”:** additionally strip Tron from **Reown** adapters/networks (or no-op Tron connect), and assert **no** code path constructs `ActiveRuntimeSelection` with Tron **from any source** (including dev tooling, persisted ids, deep links).

This is a **large** cross-cutting change (wallet + runtime + UX), not an env-only tweak.

### C. Deployment-level capability matrix

- Centralize “allowed families” / “allowed deployment ids” in one **typed** matrix (e.g. under `src/staking/config/`) consumed by:

  - registry merge,
  - runtime swap policy,
  - wallet connect surfaces,
  - optional: refresh/history admission.

- **Pros:** Explicit, testable, avoids ambiguous env names.
- **Cons:** Design + migration effort; must stay compatible with Phase 42 frozen swap protocol if execution paths change.

---

## 7. Is the current behavior misleading?

**Yes, mildly, by naming and mental model:**

- **`VITE_ENABLE_ETHEREUM`** suggests whole-chain enablement but only gates **supplemental** EVM rows; **primary Ethereum staking remains on**.
- **`VITE_ENABLE_TRON`** reads like a global Tron switch but **only** removes Tron **from the staking deployment registry**; the **wallet** still exposes Tron.

The **implemented** semantics are closer to: **“Include this family’s optional registry rows (explicit env + JSON passives).”**

---

## 8. What would “true” hard-disable require? (checklist, not a plan)

1. **Single source of truth** for “family allowed” that **all** of: registry, `resolveLegacyStakingDeployment` / default selection, Reown adapters, and open-wallet flows consult.
2. **Legacy-primary policy:** either allow disabling primary EVM (product decision) or **rename** env vars to match “sibling rows only.”
3. **Persistence:** reconcile stored `deploymentId` / tx context when a family is turned off (session + recovery).
4. **DEV tools:** runtime picker / stress harness must respect the same matrix.
5. **Tests / smoke:** matrix scenarios for each flag + combinations (registry-only vs hard-off).

---

## 9. Code map (reference)

| Concern | Representative entrypoints |
|---------|----------------------------|
| Rollout flags | `src/config/env.ts` (`isStakingEthereumEnabled`, `isStakingTronEnabled`) |
| Registry gating | `src/staking/core/buildExplicitEnvDeploymentRows.ts`, `src/staking/core/getStakingDeploymentRegistry.ts` |
| Legacy row | `src/staking/core/buildLegacyDeploymentFromEnv.ts`, `getStakingDeploymentRegistry.ts` |
| Executable policy | `src/staking/core/runtimeCapabilities.ts` |
| Default runtime | `src/staking/core/runtimeSelectionDefaults.ts`, `src/staking/core/runtimeSelection.ts` |
| Product choices | `src/lib/stakingProduct/stakingProductRouting.ts` |
| Passive Tron reads | `src/staking/reads/useStakingVaultTokenReads.ts`, `src/staking/refresh/useStakingVaultBalanceRefresh.ts` |
| Tron history | `src/staking/history/useStakingVaultHistory.ts`, `src/staking/history/tron/tronTransactionHistory.ts` |
| Wallet bootstrap | `src/reownKit.ts` |
| Internal swap | `src/staking/orchestration/runtimeSwapEngine.ts`, `runtime swapPolicy.ts` |

---

*Last updated: CFG5 network rollout semantics audit (documentation only).*
