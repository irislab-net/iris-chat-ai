# Staking destructive cleanup — Phase P4 report

**Date:** 2026-05-16  
**Scope:** Dead code and asset purge, dependency hygiene, doc archival, and low-risk bundle graph slimming **without** changing staking architecture, hook order, ownership, orchestrator semantics, or refresh/history/tx topology.

## Summary

- **Deleted source files:** 75 (verified unreferenced via Knip, `tsc`, and targeted `grep` before removal).
- **Removed exports:** Not individually pruned from live barrels (Knip still reports hundreds of “unused exports” on intentional public re-exports). Effective export removal is the **deleted modules** plus removal of two dead barrels: `src/staking/runtime/index.ts`, `src/staking/cta/types/index.ts`.
- **Dependencies:** Added **`@reown/appkit-common@^1.8.19`** so `ChainNamespace` / `CaipNetwork` imports resolve explicitly (Knip “unlisted dependency”; behavior unchanged). Removed **`@radix-ui/react-popover`**, **`@radix-ui/react-scroll-area`**, and **`cmdk`** (only consumed by the deleted MTX ICO UI).

## Detection methods used

| Tool / check | Role |
|--------------|------|
| **Knip 5** | First-pass unused files, exports, deps. |
| **TypeScript** | `pnpm typecheck` — authoritative after edits. |
| **Grep** | Disambiguate Knip false positives (e.g. lazy routes, duplicated component names). |
| **depcheck** | Cross-check only; **not** used to remove packages (many false positives: `tailwindcss`, Solana stack, etc.). |
| **Vite build** | Confirms no missing modules / broken graph. |

`ts-prune` was not added as a project script; Knip + `tsc` covered the same surface for this pass.

## What was deleted (categories)

1. **MTX ICO / Rubic chain** — `icoBuyDialog`, Rubic hooks, `icoConfig`, related types; only referenced each other, not `/mtx` route.
2. **Unreachable marketing pages** — `blog/`, `brand/`, `build/` (no `routes.tsx` entries).
3. **Unused home sections** — `homeNewsletter`, `homeTrusted`.
4. **Unused staking marketing chunks** — `stakingFeatures`, `stakingProblem`, `stakingRoadmap`; fee row components superseded by `StakingFormActionSummary`.
5. **Dead lib** — `stakingNetPrincipal` storage helper (logic lives in affiliate plane); unused `color` / `random`; unused `stakingProductModel` + `buildStakingProductCatalog`.
6. **Unused UI primitives** — `alert`, `command`, `popover`, `scroll-area` (only ICO dialog depended on them).
7. **Icons** — Static and animated icons with **zero** importers after the above.
8. **Dead barrels** — `staking/runtime/index.ts` (nothing imported `@/staking/runtime`; side-effect registration was unreachable), `staking/cta/types/index.ts` (callers import `stakingCtaContracts` directly).

## Docs / archive

- **Moved to** `docs/archive/migration-phase-reports/` (14 files): pre-freeze migration, census, vault topology, G4a–G4c, bridge readiness, import/canonicalization/final canonicalization reports, runtime wallet migration status.
- **Index:** `docs/archive/migration-phase-reports/README.md` explains archival intent.

## Staking notification spec

- `src/constants/stakingNotificationSpec.ts`: §15.6 / §26–§27 updated so they no longer describe the removed MTX ICO dialog (no product behavior change).

## Core doc comment fix

- `src/staking/core/address/index.ts`: audit comment path updated from obsolete `src/lib/staking/...` to `src/staking/tx/stakingTxSessionPersistence.ts`.

## Bundle impact (qualitative)

- Production build **succeeds**; module count **6379** transformed (post-cleanup run).
- **StakingApp** chunk (example build): **~476 kB** minified, **~137 kB** gzip — snapshot only; no historical delta captured in-repo. Removing the MTX/Rubic subtree and unused pages/icons shrinks the dependency graph and eliminates unreachable chunks; **no** intentional change to staking lazy boundaries.

## Runtime impact

- **None intended:** no edits to `useStakingVault`, refresh/history/composer planes, orchestration sequencing, or transaction topology.
- **Architecture smoke / soak / invariants:** Left **intact** (only dead entrypoints removed). Browser-only smoke (`window.__STAKING_ARCHITECTURE_SMOKE__`) was not automated in CI here; **verify in dev** if you rely on the global.

## Intentionally preserved complexity

- Diagnostics barrels (`@/staking/diagnostics/*`), soak monitor/analysis, architecture smoke, boundary rules, and dev-only torture/chaos dynamic imports.
- Large **public** re-exports on plane `index.ts` files (Knip “unused export” noise).

## Remaining technical debt

- **Knip** still lists many unused exports on barrels and config — trimming them is a separate, higher-risk API cleanup.
- **depcheck** reports unused `@solana/*`, `cmdk`, `rxjs`, etc.; confirm with usage + product roadmap before removing.
- **Chunk size:** main `index-*.js` ~2.5 MB minified — needs a dedicated code-splitting phase (out of scope for P4 topology freeze).

## Dangerous areas intentionally untouched

- Vault composer, refresh orchestration, history plane, tx execution, runtime network glue, and AppKit wiring.
- Dynamic imports in `runtimeSelectionContext` (dev suites) and staking diagnostics globals.

## Verification

- `pnpm typecheck` — **pass**
- `pnpm build` — **pass**
