# Staking stabilization report (Phase S1)

Hardening and DX pass after G4a/G4b canonicalization. **No runtime ownership moves, no public API removals, no behavior changes** (effect order and dependency arrays preserved).

Verification: `pnpm typecheck` ✅ · `pnpm build` ✅

Manual QA (deposit, withdraw, runtime swap, soak, navbar, etc.) — **not run in CI**; use checklist in §8.

---

## 1. Executive summary

| Metric | Value |
|--------|------:|
| **Boundary rules (catalog)** | **10** |
| **ESLint boundary blocks** | **5** (+ existing env import rule) |
| **DEV invariant functions** | **6** |
| **DEV invariant call sites wired** | **14** |
| **Architecture smoke checks** | **5** |
| **Package owner registrations** | **8** |
| **Barrel cleanups (material)** | **1** (`diagnostics/index.ts` explicit exports) |
| **Tx boundary fixes** | **2** files (`stakingTxSessionPersistence`, `stakingTxOnChainRecovery`) |
| **Stale comment cleanups** | **~8** files (phase/migration headers) |

**Recommendation:** **Proceed to G4c** after completing manual QA (§8). Optional **G4d** for `useStakingVaultEvmNetworkGlue` can run in parallel or immediately after G4c.

---

## 2. Boundary rules

**Source:** `src/staking/diagnostics/stakingBoundaryRules.ts`

| ID | Owner | Rule |
|----|-------|------|
| `runtime-no-ui` | runtime | No components, `staking/ui`, vault composer |
| `execution-no-components` | execution | No components or UI |
| `tx-no-presentation` | tx | No page staking components or UI |
| `refresh-no-ui` | refresh | No UI/components |
| `history-no-ui` | history | No UI/components |
| `orchestration-no-ui` | orchestration | No UI/components |
| `vault-composition-only` | vault | No modal/provider surfaces |
| `ui-presentation-only` | ui | No vault composer or orchestrator internals |
| `tree-no-lib-staking` | core | No `@/lib/staking/*` |
| `tree-no-lib-tron` | core | No `@/lib/tron/*` |

**ESLint:** `eslint.config.js` — patterns aligned with `STAKING_ESLINT_BOUNDARY_PATTERNS` (runtime, execution, tx, refresh/history/orchestration, legacy lib paths).

**DEV registration:** Package owners registered from barrels: `runtime`, `execution`, `tx`, `refresh`, `orchestration`, `history`, `ui`, `vault`.

---

## 3. Invariant coverage

| Invariant | Function | Wired at |
|-----------|----------|----------|
| Refresh plane hook order | `devAssertRefreshPlaneRegistrationOrder` | 9 phases in `useStakingVaultRefreshPlane` |
| Single orchestrator session | `devAssertSingleRefreshOrchestratorOwner` | After `startStakingRefreshOrchestrator` in balance refresh |
| History / deployment alignment | `devAssertHistoryRuntimeFamilyMatch` | `useStakingVaultHistoryPlane` effect |
| Tron passive non-transacting | `devAssertTronPassiveNonTransactingInvariant` | `useStakingVaultDiagnostics` |
| Public assembly leak | `devAssertPublicAssemblyNoInternalLeakage` | `assertStakingVaultPublicTopology` |
| Runtime context stable | `devAssertRuntimeContextStable` | `useStakingVaultRuntimeContext` |

**Architecture smoke** (`stakingArchitectureSmokeDev.ts`): orchestrator session snapshot, profit singleton, package owners ≥5, boundary rules ≥8, stale bridge prefix catalog.

**Global:** `window.__STAKING_ARCHITECTURE_SMOKE__` in DEV.

### Boundary assertion count (for metrics)

| Category | Count |
|----------|------:|
| Catalog rules (`STAKING_BOUNDARY_RULES`) | 10 |
| ESLint restricted-import blocks (staking-specific) | 5 |
| DEV invariant call sites | 14 |
| Smoke checks per run | 5 |
| **Total enforcement touchpoints** | **34** |

---

## 4. Barrel audit

| Barrel | Status |
|--------|--------|
| `staking/diagnostics/index.ts` | **Cleaned** — replaced `export *` with explicit named exports (soak, boundary, invariants, smoke) |
| `staking/runtime`, `execution`, `tx`, `refresh` | Explicit exports + DEV owner registration |
| `staking/orchestration`, `history`, `ui`, `vault/composer` | Explicit exports + DEV owner registration |
| `staking/cta`, `notifications`, `profit`, `integrations`, `affiliate` | Already explicit |
| `staking/tx/execution`, `tx/types`, `core/address` | Narrow sub-barrels — no loops found |

**Barrel cleanup count:** **1** material refactor + **8** owner-registration side effects (no symbol removal).

**No circular barrel exposure** detected via `export *` (none remain under `src/staking/`).

---

## 5. DTO audit

| Area | Change |
|------|--------|
| `stakingVaultComposerDtos.ts` | Return types narrowed to `Readonly<>` for ref bag and refresh setters |
| `stakingVaultPublicAssembly.ts` | Unchanged behavior; topology assertion only |
| Large pass-through DTOs | **No structural reduction** — deferred to avoid dependency-array risk |

**Forbidden changes avoided:** effect order, hook order, orchestrator session shape.

---

## 6. Singleton / smoke audit

| Singleton | Smoke check |
|-----------|-------------|
| Refresh orchestrator | `getStakingRefreshOrchestratorDevSnapshot` |
| Profit manager status | `getProfitManagerStatusSnapshot` |
| Package owners | `devGetRegisteredStakingPackageOwners` |

**Stale bridge catalog** documents zero-import targets for CI grep: `@/lib/staking/*`, `@/lib/tron/*`, legacy hook paths.

---

## 7. Remaining architectural debt

### Unstable zones (do not break before G4c)

1. **Public vault bridge** — `address`, `isConnected`, `chainId`, `activeRuntimeSelection` + `withDeprecatedVaultBridgeDevInstrumentation`
2. **`useStakingVaultEvmNetworkGlue`** — deprecated composer path (G4d)
3. **`runtimeCoreLayerBoundaryDev`** — side-effect shim imported from runtime selection context

### Technical debt clusters

| Cluster | Severity | Phase |
|---------|----------|-------|
| Public bridge removal | High (external API) | **G4c** |
| EVM network glue deletion | Medium | **G4d** |
| `lib/stakingDepositApprovalExecution` shared with components | Low | Optional extract to `staking/tx` |
| Large staking app components (`StakingAppDepositForm`, `StakingAppTransactionHistory`) | Low | UX refactor only |
| CI grep for stale bridge prefixes | Medium | S2 or G4c prep |

---

## 8. Manual QA checklist

1. EVM runtime connect  
2. Tron passive runtime  
3. Runtime swap (EVM ↔ Tron)  
4. Deposit  
5. Withdraw  
6. Approval flow  
7. Transaction history (EVM + Tron)  
8. Refresh orchestration (balance updates after tx)  
9. Soak monitor (`printStakingRuntimeHealthSummary` / DEV tools)  
10. Navbar wallet section  
11. Wrong network handling  
12. `window.__STAKING_ARCHITECTURE_SMOKE__()` — expect `ok: true`  

---

## 9. G4c readiness assessment

| Criterion | Status |
|-----------|--------|
| Zero `@/lib/staking/*` / `@/lib/tron/*` in `src/staking/*` | ✅ |
| Tx plane does not import presentation model | ✅ |
| Boundary rules + ESLint | ✅ |
| DEV invariants on composer planes | ✅ |
| `pnpm typecheck` / `pnpm build` | ✅ |
| Manual QA complete | ⏳ **User** |
| External consumers of deprecated vault fields identified | ⏳ **Before G4c** |

**Verdict:** G4c completed — see `docs/g4c-bridge-retirement-report.md`. Proceed to **G4d** or architecture freeze after manual QA.

---

## 10. Recommended future phases

| Phase | Scope |
|-------|--------|
| **G4c** | Remove public vault bridge fields; update topology + types |
| **G4d** | Replace `useStakingVaultEvmNetworkGlue` with canonical network glue |
| **S2** (optional) | CI script: grep stale bridge prefixes + import boundary report |
| **S3** (optional) | Composer DTO consolidation behind readonly facades |

---

## 11. Related docs

- `docs/staking-domain-boundaries.md` — ownership matrix  
- `docs/staking-runtime-contracts.md` — hook order, refresh, tx contracts  
- `docs/g4a-shim-deletion-report.md` — shim deletion  
- `docs/g4b-tron-retirement-report.md` — Tron relocation  

---

*Phase S1 complete — stabilization hardening only.*
