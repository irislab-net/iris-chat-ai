# Staking runtime vs execution wallet migration — status

> Archived migration status. Current vault API, AppKit boundaries, and tx continuity rules are in `../../staking-domain-boundaries.md`, `../../staking-runtime-contracts.md`, and `../../staking-runtime-edgecases.md`. Statements about deprecated bridge keys below are historical and may be superseded.

Tracks the phased split between **UI/runtime identity** (`runtimeWallet*`) and **EVM execution** (`execution*` / `eip155` namespace). Bridges remain exported until an explicit removal phase.

---

## Completed phases

| Phase | Scope | Outcome |
| ----- | ----- | ------- |
| **4.2** | `useAppKitEvmIsolationOnPassiveTron` | Edge-triggered EIP-155 isolation on passive Tron; no disconnect churn |
| **4.3** | Coexistence soak (audit) | Safe with 4.2 + unified UX flag off; not yet for full AppKit Tron as sole identity |
| **4.4** | Namespace ownership (audit) | Locked: UI = `runtimeWallet`; EVM tx = `execution*`; no global `useAppKitAccount()` for staking semantics |
| **4.5** | Vault normalization slice 1 | `useStakingVault` composes `eip155` + `tron` namespaces; deprecated bridges aliased internally |
| **4.6** | Consumer migration | Staking UI consumers use `runtimeWallet*` / `execution*`; no consumer reads of `vault.isConnected` / `vault.address` / `vault.chainId` |
| **4.7** | Bridge hardening + telemetry | DEV getters on bridges, semantic assertions, `logRuntimeExecutionPlaneSnapshot`; bridges still exported |
| **4.8** | Runtime stabilization soak | DEV soak monitor, instability detectors, timeline buffer, `getRuntimeSoakHealth()`; zero production overhead |
| **4.9** | Soak validation + convergence | Timeline analyzer, convergence metrics, unstable snapshot freeze, recovery telemetry, health printer |

---

## Ownership rules (runtime vs execution)

| Concern | Source of truth | Notes |
| ------- | ----------------- | ----- |
| Toolbar / balance / history / explorer links | `runtimeWallet`, `runtimeWalletAddress`, `runtimeWalletConnected` | Includes passive Tron + unified Tron when enabled |
| EVM signing, gas, allowances, affiliate Firestore | `executionAddress`, `executionConnected`, `executionChainId`, `executionNetworkOk` | `useAppKitAccount({ namespace: "eip155" })` only |
| Tron passive owner / read paths | `stakingOwnerAddress` (= published runtime address) | Not EVM execution |
| CTA “connected” | `ctaIdentityConnected` | EVM: `executionConnected`; Tron: `runtimeWallet.hasAccount` |
| Deprecated bridges | `isConnected`, `address`, `chainId` | Still on vault return object; DEV getters warn on read |

**Do not** drive staking semantics from global `useAppKitAccount()` (no namespace) or from passive Tron inject alone.

---

## Intentional divergences

| Situation | Behavior |
| --------- | -------- |
| Tron passive runtime | `executionChainId` is `null`; `canTransact` is always `false`; EVM signer unused |
| Tron wrong network | `runtimeWallet.hasAccount` may be true while `networkOk` is false; `connected` is false on passive-only path (`hasAccount && networkOk`) |
| Unified Tron (`VITE_APPKIT_TRON_IDENTITY`) | Resolver may choose AppKit vs passive; identity origin traced in DEV |
| EVM leakage while on Tron | `useAppKitEvmIsolationOnPassiveTron` disconnects `eip155`; semantic DEV asserts flag non-null `executionChainId` / `executionNetworkOk` on Tron |
| Affiliate / referral | EVM checksummed `executionAddress` only (not runtime Tron base58) |
| Tx persistence `chainId` column | Unchanged format; EVM values written via `executionChainId` in `TransactionStatusProvider` |
| `deployment.vault.address` | On-chain vault contract — not wallet bridge `address` |

---

## Remaining global leaks (out of vault consumer scope)

| Location | Risk | Mitigation / note |
| -------- | ---- | ----------------- |
| `NavbarWalletSection.tsx`, `walletButton.tsx` | Marketing nav uses `useWallet()` | Not staking semantics; separate product surface |
| `useAppKitTronAccount.ts` | Diagnostics | Do not wire into vault |
| `useUnifiedWalletOrchestration` | `switchNetwork` only in vault | Namespace scoped by runtime family |
| Internal `useStakingVault` | Still uses bridge *locals* (`isConnected`, `address`) for EVM paths | Acceptable until internal refactor phase |

---

## Phase 4.7 DEV tooling

### Deprecated bridge warnings

- Module: `src/lib/staking/stakingVaultDeprecatedFieldDev.ts`
- Installed via getters on `isConnected`, `address`, `chainId` in DEV only (`stakingVaultDeprecatedBridgeDev.ts`)
- Deduped by **callsite + field**; includes `runtimeKey`, `chainFamily`, `replaceWith`

### Semantic assertions (console.warn, no throw)

- Module: `src/lib/staking/stakingVaultSemanticAssertionsDev.ts`
- **Tron:** `executionChainId === null`, `!executionNetworkOk`, `!canTransact`, `connected → networkOk`
- **EVM:** when `runtimeWallet.connected`, `runtimeWallet.address === executionAddress`

### Migration telemetry

- `logRuntimeExecutionPlaneSnapshot` in `src/lib/staking/stakingRuntimeExecutionPlaneTelemetry.ts`
- Emits on: runtime swap (`runtimeKey` / `generation`), wallet connect/disconnect, network change
- Filter console: `[staking-vault][runtime-execution-plane]`

---

## Phase 4.8 — Runtime stabilization soak (DEV only)

### Goals

- Detect instability under **rapid runtime swaps**, **hydration stalls**, **reconnect storms**, and **runtime/execution identity drift** during manual or scripted soaks.
- Provide a **replayable timeline** for debugging without production logging or coordinator / persistence changes.

### Module

- `src/lib/staking/stakingRuntimeSoakMonitor.ts`
- Ticked from `useStakingVault` (full snapshot + transition `sequenceStage` / `lifecycle`)
- `contamination_disconnect` recorded from `useAppKitEvmIsolationOnPassiveTron` when EIP-155 isolation fires

### Tracked sample fields

`runtimeKey`, `generation`, `chainFamily`, `sequenceStage`, `lifecycle`, `vaultDataReady`, `runtimeWallet.connected`, `executionConnected`, `isWrongNetwork`, `canTransact` (+ addresses for drift)

### Instability definitions

| Detector | Condition | Dedup |
| -------- | --------- | ----- |
| **Hydration stall** | `vaultDataReady === false` for **>10s** after `sequenceStage` is `idle` or `settled` | Once per `runtimeKey` |
| **Execution leakage** | Tron runtime + `executionConnected === true` for **>5s** | Once per session |
| **Identity drift** | EVM + both planes connected + `runtimeWallet.address !== executionAddress` for **>2s** | Once per session (warn) |
| **Transition churn** | **>3** runtime swaps within **15s** | Once per session |
| **Reconnect storm** | **>4** connect/disconnect edges within **20s** on the same namespace (`eip155` or `runtime_wallet`) | Once per namespace per session |

Duration detectors re-run on a **1s DEV interval** while the vault is mounted (no production timers).

### Timeline and dump

- Ring buffer: last **100** events (`runtime_swap`, `network_change`, `wallet_connect`, `wallet_disconnect`, `vault_ready`, `vault_not_ready`, `contamination_disconnect`, `hydration_stall`, `transition_churn`)
- Console filter: `[staking-runtime-soak]`
- Dump: `window.__stakingRuntimeSoakDump?.()` → `{ health, events, activeFlags, lastSample }`

### `getRuntimeSoakHealth()` (pure helper, no UI yet)

| State | Meaning |
| ----- | ------- |
| **stable** | Settled sequence, vault ready, no active instability flags |
| **warming** | Recent swap (<5s) or sequence not settled, or vault still loading within early window |
| **degraded** | Identity drift active, or vault slow after settle (before hydration stall threshold) |
| **unstable** | Hydration stall, execution leakage, transition churn, or reconnect storm |

---

## Phase 4.9 — Soak validation and convergence (DEV only)

### Analyzer

- `analyzeRuntimeSoakTimeline(events)` in `src/lib/staking/stakingRuntimeSoakAnalysis.ts`
- Returns **`stable` | `warning` | `unstable`** plus metrics:
  - swap frequency / reconnect density (per minute of timeline span)
  - average and max hydration duration
  - contamination / identity drift counts
  - instability burst clusters (≥2 instability events within 30s)

### Convergence metrics

- `getRuntimeSoakConvergenceMetrics()` — consecutive stable minutes, longest stable streak, last recovery duration (`unstable → stable`, `degraded → stable`)
- Updated live while health is **`stable`**

### Unstable snapshot freeze

When live health enters **`unstable`**, the current last-100 timeline is frozen:

- `window.__stakingRuntimeLastUnstableSnapshot` — events, flags, sample, timeline analysis, reason

### Recovery telemetry

Console: `[staking-runtime-soak][recovery]` — `unstable_to_stable`, `degraded_to_stable`, `entered_unstable` with durations.

### DEV console printer

```text
window.__printStakingRuntimeHealth?.()
```

Also available via dump: `window.__stakingRuntimeSoakDump?.()` (includes `timelineAnalysis`, `convergence`, `instabilityCounters`).

---

## Bridge removal gate (decision checklist)

Bridges (`isConnected`, `address`, `chainId`) may be removed only after a **clean convergence session** passes all gates below. This is a **product/eng sign-off**, not an automated flag.

### Minimum soak stability requirements

| Requirement | Threshold |
| ----------- | --------- |
| Live health | `getRuntimeSoakHealth() === "stable"` for **≥5 consecutive minutes** per exercised runtime (legacy EVM + passive Tron minimum) |
| Longest stable streak | `getRuntimeSoakConvergenceMetrics().longestStableStreakMinutes` **≥5** after full soak |
| Timeline analyzer | `analyzeRuntimeSoakTimeline(dump.events).verdict === "stable"` at gate check |
| Unstable snapshots | **None** during clean soak (`__stakingRuntimeLastUnstableSnapshot` unset or stale from intentional stress only) |
| Phase 4.7 | Zero deprecated-bridge reads and semantic assertion warnings |
| Phase 4.6 | No consumer destructure of bridge fields |

### Required clean-session duration

- **Minimum:** 5 minutes continuous **`stable`** live health per runtime family exercised.
- **Recommended:** 15 minutes before production bridge-removal PR, including at least one connect → deposit preview → disconnect cycle on EVM and passive Tron browse on Tron.

### Acceptable instability thresholds (clean soak)

| Signal | Acceptable on clean soak |
| ------ | ------------------------ |
| `hydration_stall` events | **0** |
| `transition_churn` events | **0** (allowed only in intentional stress run) |
| `contamination_disconnect` | **≤2** per 15 min (isolation may fire on Tron entry); analyzer **`warning`** OK, **`unstable`** not OK |
| `identity_drift` | **0** |
| Max hydration (timeline) | **<10s** (analyzer unstable threshold) |
| Swap frequency | **<4/min** (warning threshold) on clean soak |
| Reconnect density | **<6/min** (warning threshold) |
| Recovery time `unstable → stable` | **<30s** when induced in stress test; N/A on clean soak |

### Gate commands (DEV, `/staking/app`)

```text
window.__printStakingRuntimeHealth?.()
window.__stakingRuntimeSoakDump?.()
```

**Pass example:** `health: stable`, `timeline verdict: stable`, `activeFlags` all false, `consecutiveStableMinutes ≥ 5`.

---

## Bridge removal criteria (future phase)

Remove `isConnected`, `address`, and `chainId` from `useStakingVault` only when **all** are true:

1. **Zero** DEV warnings from deprecated bridge getters for one full manual soak (connect, swap runtime, deposit/withdraw, Tron passive, wrong network).
2. **Zero** semantic assertion warnings in the same soak (or each documented as accepted product state).
3. No remaining imports/destructures of bridge names under `src/components/pages/staking/` and `src/components/dev/`.
4. Internal vault hook refactored to `execution*` / `runtimeWallet*` locals only (no bridge locals).
5. `pnpm typecheck` + `pnpm build` green; tx persistence and coordinator unchanged unless explicitly scoped.

Until then: bridges stay exported; public `StakingVaultValue` shape unchanged.

### Required stable-runtime criteria (soak gate)

Superseded by **Bridge removal gate** above (Phase 4.9): use **5-minute** consecutive stable convergence and timeline analyzer **`stable`** verdict as the primary gate.

---

## Related docs

- `docs/staking-runtime-phase42-stabilization.md` — production-frozen runtime coordinator / swap
- `docs/staking-runtime-phase43-telemetry.md` — runtime transition telemetry
- `docs/archive/migration-phase-reports/staking-runtime-phase45-unified-product-ux.md` — product routing / catalog
- `docs/archive/migration-phase-reports/staking-runtime-phase46-multi-vault-runtime.md` — multi-deployment registry
