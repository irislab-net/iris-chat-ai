# Staking DEV & diagnostics cleanup candidates — Phase P1

**Policy:** **Do not delete** without an explicit cleanup phase and QA. This document **classifies** only.

**Classification legend**

| Label | Meaning |
|-------|---------|
| **keep** | Intended long-term; supports freeze, soak, or safety |
| **safe** | Removing or narrowing is unlikely to affect prod behavior |
| **optional** | Product/process choice (noise vs observability) |
| **dangerous-to-remove** | Breaks soak, chaos QA, boundary audits, or incident debugging |

---

## 1. Temporary DEBUG traces (post-incident)

**Phase P2 (2026):** `[staking-balance-debug]` and `[staking-history-refresh-debug]` console blocks were **removed** from:

- `staking/execution/stakingReadFactory.ts`
- `staking/refresh/useStakingVaultBalanceRefresh.ts`
- `staking/history/useStakingVaultHistory.ts`
- `components/pages/staking/StakingAppTransactionHistory.tsx`

See `docs/archive/migration-phase-reports/staking-cleanup-report.md`. Reintroduce only behind `import.meta.env.DEV` if a new regression investigation needs them.

---

## 2. Permanent diagnostics (architecture / freeze)

| Module | Classification |
|--------|----------------|
| `staking/diagnostics/stakingInvariantAssertionsDev.ts` | **keep** — refresh plane order, topology |
| `staking/diagnostics/stakingArchitectureSmokeDev.ts` | **keep** — `window.__STAKING_ARCHITECTURE_SMOKE__` |
| `staking/diagnostics/stakingBoundaryRules.ts` + boundary warnings | **keep** |
| `staking/diagnostics/stakingCanonicalBoundaryDev.ts` | **keep** |
| `staking/vault/composer/stakingVaultPublicTopology.ts` | **keep** |
| `staking/runtime/network/stakingNetworkTopologyDev.ts` | **keep** |
| `staking/diagnostics/stakingG4dFrozenTopologyDev.ts` | **keep** |

---

## 3. Soak / telemetry / torture (runtime observation)

| Module | Classification |
|--------|----------------|
| `staking/diagnostics/stakingRuntimeSoakMonitor.ts` | **keep** — **dangerous-to-remove** for long-run regression detection |
| `staking/diagnostics/stakingRuntimeSoakAnalysis.ts` | **keep** |
| `staking/diagnostics/stakingRuntimeExecutionPlaneTelemetry.ts` | **keep** |
| `staking/core/runtimeTransitionTelemetry.ts` | **keep** — ties to chaos / torture / traces |
| `devRegisterStakingRefreshOrchestratorStressTickProbe` (orchestrator comments) | **optional** — stress harness only |

---

## 4. Chaos & torture suites

| Module | Classification |
|--------|----------------|
| `staking/dev/runtimeChaosSuite.ts` | **optional** in prod tree — **keep** in repo; gated by env (`VITE_RUNTIME_CHAOS` / config) — **dangerous-to-remove** for stress QA |
| `staking/dev/runtimeTortureSuite.ts` | **optional** / **keep** (same) |
| `staking/dev/runtimeSwapStressHarness.ts` | **optional** |
| `staking/dev/runtimeReadinessGate.ts` | **optional** — dev gate console noise |

---

## 5. Console usage (non-prefixed)

Many `console.warn` / `console.info` under diagnostics (architecture smoke, boundaries). **keep** as **DEV-gated** or low-frequency.

**Rule of thumb:** grep `console.` under `src/staking` and `src/components/pages/staking` before any bulk removal — prefer **narrowing** to DEV or telemetry events vs delete.

---

## 6. Mobile / tx lifecycle debug

| Module | Classification |
|--------|----------------|
| `staking/diagnostics/stakingTxMobileLifecycleDebug.ts` | **optional** — **keep** until mobile staking declared stable |
| `staking/diagnostics/stakingTxIntegrityDev.ts` | **keep** |

---

## 7. Migration / semantic assertions

| Module | Classification |
|--------|----------------|
| `staking/diagnostics/stakingMigrationAssertionsDev.ts` | **optional** — safe to thin after migration complete |
| `staking/diagnostics/stakingVaultSemanticAssertionsDev.ts` | **keep** |

---

## 8. Suggested cleanup order (when allowed)

1. ~~**optional:** Remove `[staking-balance-debug]` / `[staking-history-refresh-debug]`~~ — **Done in P2** (`docs/archive/migration-phase-reports/staking-cleanup-report.md`).
2. **safe:** Audit `console.log` without `import.meta.env.DEV` in staking tree (should be zero in prod-critical paths).
3. **dangerous-to-remove:** Soak monitor, smoke install, invariant registration order asserts — **do not** batch-delete.

---

*Phase P1 — classification only.*
