# CFG6 — Hard-disable plan (`VITE_ENABLE_ETHEREUM` / `VITE_ENABLE_TRON`)

Maps runtime paths → **single gating layer** → blast radius. Implementation: `src/staking/runtime/capabilities/` + targeted consumers (no orchestrator / hook-order refactors).

## Central modules

| Module | Role |
|--------|------|
| `stakingRuntimeFamilyRollout.ts` | `isRuntimeFamilyEnabled("evm" \| "tron")`, `getEnabledRuntimeFamilies()` — reads `env` only (no registry import). |
| `stakingRuntimeDisabledSentinel.ts` | Sentinel deployment id + `buildCfg6StakingRuntimeDisabledSentinelDeployment()`, `isCfg6StakingRuntimeDisabledSentinel()`, `resolveStakingDeploymentForActiveSelection(registry)`. |
| `stakingRuntimeHydration.ts` | `isStakingVaultRuntimeHydrationEnabled(deployment)` = family rollout on **and** not sentinel. |

## Path → disable point → blast radius

| Path | Disable point | Blast radius |
|------|---------------|--------------|
| Deployment registry | `getStakingDeploymentRegistry`: omit legacy EVM when `!isRuntimeFamilyEnabled("evm")`; merge JSON/explicit as today; final `filter` by family; `defaultDeploymentId` from first row or legacy if present; **empty** `{ deployments: [], defaultDeploymentId: "" }` when no rows. | All registry consumers see only enabled families; validation allows empty registry. |
| Default / active selection | `resolveStakingDeploymentForActiveSelection` → sentinel row when registry empty; `getActiveStakingRuntimeSelection` + `resolveLegacyStakingDeployment` use same resolver. | One consistent “no live deployment” identity; capabilities all false. |
| Runtime capabilities | `getRuntimeCapabilitiesForDeployment` / `isDeploymentRuntimeExecutable`: sentinel → `UNKNOWN_FAMILY` / non-executable. | Tx / gas / reads that assert capabilities fail closed without new policy types. |
| Read HTTP / receipts | `getReadProviderForDeployment`: reject sentinel (throw). | Accidental provider hydration from default deployment throws clearly. |
| Vault runtime context | `useStakingVaultRuntimeContext`: no `getJsonRpcProviderForDeployment` when sentinel or non-EVM. | No JsonRpc singleton for disabled EVM session. |
| WS / RPC probes | `stakingReadProviders`: skip WS acquire + HTTP probe when EVM hydration off / sentinel. | No background WS loop when EVM disabled. |
| ETH/USD feed | `readChainlinkEthUsdLatest`: return null when `!isRuntimeFamilyEnabled("evm")`. | No Chainlink reads without EVM. |
| Refresh orchestrator | `useStakingVaultBalanceRefreshOrchestrator`: `runtimeHydrationEnabled` gate → stop orchestrator. | No EVM polling loop. |
| Tron polling | `useStakingVaultBalanceRefreshTronPolling`: same gate. | No Tron passive polling. |
| History | `buildStakingHistoryKey` null for sentinel; `refreshStakingHistory` early exit when `!isStakingVaultRuntimeHydrationEnabled`. | No history fetch / cache keys for disabled session. |
| Runtime swap (DEV) | `evaluateRuntimeSwapPolicy`: deny when `!isRuntimeFamilyEnabled(next.chainFamily)`. | Cannot swap into a build-disabled family. |
| Wallet (Reown) | `reownKit.ts`: omit Ethers/Tron adapters + related networks; adjust `defaultNetwork` (Solana fallback when both off). | Modal matches enabled families only (global AppKit scope). |
| AppKit EVM isolation | `useAppKitEvmIsolationOnPassiveTron`: no-op when `!isRuntimeFamilyEnabled("tron")`. | No Tron-only disconnect choreography when Tron family off. |

## Safe gating layer (summary)

1. **Rollout truth:** `isRuntimeFamilyEnabled` (env-backed).  
2. **Session truth:** `isStakingVaultRuntimeHydrationEnabled(deployment)` for planes / refresh / history.  
3. **Empty registry:** sentinel deployment + capabilities all false — fail closed for execution and passive reads.

## Validation / fallback

- `validateDeploymentIds`: allow **empty** registry iff `defaultDeploymentId === ""`.  
- `getStakingDeploymentRegistry`: on validation **error**, fallback to legacy-only if EVM enabled; else **empty** registry (never revive legacy when EVM is off).

## Surviving always-on paths

- **Solana** adapter/networks in AppKit remain for non-staking global wallet UX (until product removes them).  
- React hook **subscriptions** to AppKit (e.g. `useAppKitAccount`) still run where hooks rules require; **staking** work is gated, not Removed hooks.  
- Env keys for disabled families still exist in `import.meta.env` (no format change per constraints).
