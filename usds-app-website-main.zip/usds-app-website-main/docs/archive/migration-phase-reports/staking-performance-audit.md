# Staking performance & render audit — Phase P1

**Scope:** Production-facing staking surfaces (`components/pages/staking/*`), vault composer wiring (`staking/vault/composer/*`), refresh (`staking/refresh/*`), history (`staking/history/*`), navbar wallet (`components/layout/NavbarWalletSection.tsx`). **No code changes in P1** — observations and recommendations only.

**Constraints respected:** Frozen topology (G4d), no hook-order or plane-ownership changes in this phase.

---

## 1. Hot spots by size (proxy for parse/render cost)

| Asset (approx. LOC) | Risk |
|---------------------|------|
| `StakingAppDepositForm.tsx` (~1730) | High — many derived values, gas/fee paths, amount sync |
| `StakingAppTransactionHistory.tsx` (~1666) | High — tab state, affiliate + tx lists, search/filter |
| `StakingAppWithdrawForm.tsx` (~1521) | High — symmetric to deposit |
| `TransactionStatusProvider.tsx` (~1468) | High — modal/session context subscribers |
| `TransactionStatusSurface.tsx` (~1254) | High — presentation tied to modal state |
| `stakingRefreshOrchestrator.ts` (~574) | Medium — single-flight tick; not React render |
| `useStakingVaultBalanceRefresh.ts` (~543) | Medium — multiple `useEffect` / `useCallback` deps |
| `StakingAppBalance.tsx` (~507) | Medium — PnL / residual / rolling UI |
| `NavbarWalletSection.tsx` (~525+) | Medium — visual hold + runtime identity branches |

**Interpretation:** Large files correlate with **many child updates** when parent props from `useStakingVault()` or transaction context change. Splitting components is a **medium-risk** refactor (behavior parity); **not** done in P1.

---

## 2. Excessive rerenders — plausible causes (uninstrumented)

1. **Vault public object** — `assembleStakingVaultPublicValue` returns a wide object; consumers that depend on the whole hook or pass large prop blobs may rerender when any field changes.
2. **`TransactionStatusProvider`** — deep context; any state update can fan out to `TransactionStatusSurface` and forms that read snapshot helpers.
3. **`StakingAppTransactionHistory`** — combines staking history, affiliate loading, tabs, manual refresh, `txHistoryIdentity` memoization; frequent identity or loading toggles can rerender large subtrees.
4. **Deposit / withdraw forms** — `formatUnits` / `removeTrailingZeros` on many code paths; repeated work per render unless memoized at the right granularity.
5. **Navbar** — `useStakingNavbarVisualIdentity` uses refs + branch updates; `STAKING_NAV_VISUAL_HOLD_MS` reduces flicker but adds timed state churn on edge transitions.

**Safe quick wins (future):** React DevTools Profiler + `why-did-you-render` on a **branch** only; no production code change.

**Dangerous:** Blind `memo()` on exported app components without profiling (stale prop bugs).

---

## 3. Unstable callbacks & memos

- **`useStakingVault`** and planes use extensive `useMemo` / `useCallback` (e.g. selectors, orchestration). ESLint `react-hooks/exhaustive-deps` currently reports **many warnings** under `src/staking/*` — these are **intentional stability** tradeoffs in places; “fixing” deps wholesale is **medium–high risk**.
- **History refresh** (`handleManualRefresh` in transaction history) intentionally lists `refreshBtnLoading` and `historyUiActive` in deps for debug parity; verify Profiler does not show runaway effect churn (not measured in P1).

---

## 4. Expensive formatting & selector overlap

| Pattern | Locations |
|---------|-----------|
| `removeTrailingZeros(formatUnits(...))` | Deposit/withdraw forms, `useWithdrawalProtocolFee` — **shared** `strip` helper in `@/lib/utils` (good) |
| `formatUnits` + `parseFloat` for display | `StakingAppBalance`, `stakingAffiliatePresentation` — **similar residual/dust math** (potential duplication vs single helper) |
| `formatEther` for native gas | Deposit/withdraw, `useStakingGasEstimate`, `stakingGasEstimator` |
| Canonical vault display | `stakingVaultDisplaySelectors` (`formatVaultTokenAmountHuman`) |

**Bundle / CPU:** Duplicated **dust/neutral** logic between `StakingAppBalance` and `stakingAffiliatePresentation` is a **medium-risk** dedup (tests needed). **Not** architecture.

**Fee presentation:** `buildNetworkFeePresentation` is the single canonical builder for network fee strings; keep consumers on that path.

---

## 5. Animation / layout thrash

- **Refresh spinners** (`RefreshCw` + `animate-spin`) — low cost if conditional on loading only.
- **Rolling / blurred labels** in transaction history (loading placeholders) — can cause layout shift if not fixed-height; verify mobile (manual QA).
- **Modal** — `TransactionStatusSurface` + dialog animations; watch for double-mount on rapid tx.

---

## 6. Modal, transaction history, balance panel, navbar

| Surface | Notes |
|---------|------|
| Modal | Large provider; isolate Profiler to “one tx step” to see commit count |
| Transaction history | Affiliate + staking rows; virtualization **not** observed in P1 — long lists = DOM cost |
| Balance panel | `StakingAppBalance` + `RollingTokenAmount` — rolling animation may tick state |
| Navbar wallet | Visual hold + disconnect tracing (DEV) — production path is ref-heavy |

---

## 7. Orchestrator & “refresh storms” (logic review, not metrics)

From `stakingRefreshOrchestrator.ts` + `useStakingVaultBalanceRefreshOrchestrator`:

- **Single session:** `startStakingRefreshOrchestrator` calls `stopStakingRefreshOrchestrator` first — **no duplicate sessions** by design.
- **Coalescing:** `notifyStakingRefresh` merges semantics via bitmask; tick uses **floors** (`FAST_FLOOR_MS` / `SLOW_FLOOR_MS`) and **single-flight** `inFlight`.
- **Gates:** `canRuntimeOperationRefresh` / `canRuntimeOperationCommit` prevent stale commits during transitions.

**Conclusion:** Architecture is biased **against** refresh storms; production issues would likely be **upstream notify spam** (e.g. rapid wallet events) — monitor with existing telemetry if needed.

---

## 8. Bundle audit (static)

| Finding | Severity |
|---------|----------|
| **Large app chunks** | Vite already warns on **>500 kB** chunks — staking contributes via Reown/AppKit + `StakingApp` bundle; address via **route-level code split** (product decision) |
| **`staking/execution` barrel** | Re-exports history + gas + reads — **tree-shaking** depends on import style; avoid `import *` from barrel in hot paths |
| **Duplicate dust math** | `StakingAppBalance` vs `stakingAffiliatePresentation` — maintainability + tiny CPU |
| **No duplicate `removeTrailingZeros`** | Centralized in `@/lib/utils` |

Dead exports / unnecessary barrels: **not exhaustively enumerated** in P1 — recommend `knip` or `ts-prune` on a CI branch (no merge in P1).

---

## 9. Recommendations summary

| Tier | Action |
|------|--------|
| **Safe quick wins** | Profiler-guided `memo` on **leaf** list rows in transaction history; confirm skeleton fixed heights |
| **Medium risk** | Extract shared “human amount + dust” helper used by balance + affiliate presentation |
| **Dangerous** | Reordering hooks; widening `useCallback` deps across vault planes without tests |
| **Frozen / untouched** | Composer order, network glue slot, orchestrator gates, refresh/history ownership |

---

*Phase P1 — audit only; verify with `pnpm typecheck` && `pnpm build`.*
