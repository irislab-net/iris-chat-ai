# Vault anatomy report — `useStakingVault.ts` (Phase D0)

**Scope:** `src/hooks/useStakingVault.ts` (~2,426 lines, single export `useStakingVaultState`).  
**Context provider:** `stakingVaultContext.ts` wraps `useStakingVaultState` as `StakingVaultValue`.  
**Phase D0 rules:** analysis/documentation only — no refactors, moves, or behavior changes.

---

## Executive summary

| Item | Finding |
| ---- | ------- |
| **Hook shape** | One monolithic state hook: 29 `useEffect`, 14 `useMemo`, 12 `useCallback`, 18 `useRef`, 20+ `useState` fields |
| **Authority** | `useRuntimeTransitionSnapshot()` owns runtime identity; AppKit/`useEtheriumWallet` own execution signing; hook owns vault UI state + read caches |
| **Family split** | `stakingRuntime.deployment.chainFamily === "tron"` gates almost every subsystem (reads, refresh, history, `canTransact`) |
| **Safest D1 extraction** | **Diagnostics plane** (`J`) — already delegated to `@/staking/diagnostics/*`; thin `useStakingVaultDiagnostics` wrapper with identical effect deps |
| **Highest-risk area** | **Refresh orchestration (`F`) + balance reads (`C`) + reset/continuity keys** — shared `balanceSnapshotRef`, coordinator commit gates, EVM orchestrator vs Tron interval |
| **Must stay in root composer** | `transition` subscription, `return withDeprecatedVaultBridgeDevInstrumentation(...)`, `refreshBalances` + `tronPassiveRefetchRef` wiring, `vaultBalanceResetKey` / orchestrator lifecycle |
| **Tx persistence** | **Not in vault** — `TransactionStatusProvider` owns sessionStorage; vault only bumps `refreshKey` → `notifyStakingRefresh("tx-state-change")` |

---

## File map (line ranges)

| Lines | Symbol / area |
| ----- | ------------- |
| 1–112 | Imports + `useAffiliateFirestoreStats` / `useEtheriumWallet` |
| 114–167 | Module helpers + module singleton `stakingHistoryWarnedDeprecatedZeroBlock` |
| 169–207 | Exported types (`StakingTxOptions`, `StakingTxResult`, …) |
| 233–414 | **A** Runtime identity + publish + Tron DEV traces |
| 416–418 | **B** `useEtheriumWallet` (EVM provider/signer) |
| 420–426 | **E** Affiliate hook |
| 428–511 | **C** Token + balance state + refs |
| 513–652 | Wrong network, wallet orchestration, affiliate PnL memos, `canTransact` |
| 654–732 | **F/C** `refreshBalances`, asset resolution (`loadAsset` effect) |
| 734–933 | **C** `loadMeta` |
| 935–1028 | **C/F** Tron passive balance refetch + ref wiring |
| 1030–1131 | **B** Network switch (EVM poll + unified orchestration) |
| 1133–1208 | **C** `vaultBalanceResetKey`, `poolSnapshotContinuityKey` effects |
| 1210–1271 | **B/F** EVM chain reconciliation → `loadMeta`; `refreshKey` → refresh notify |
| 1273–1429 | **F** EVM `startStakingRefreshOrchestrator` / Tron interval+visibility |
| 1431–1481 | **K** `vaultDataReady`, history keys, merchant labels |
| 1483–1767 | **D** `refreshStakingHistory` + stall recovery + cache hydrate + auto-fetch |
| 1769–1816 | **K** Formatted balances, PnL, caps |
| 1818–2223 | **G** `ensureAllowance`, `deposit`, `approveStakeAmount`, `withdraw` |
| 2225–2336 | **J** Semantic assertions, execution-plane telemetry, soak tick |
| 2338–2425 | **L** Deprecated bridge wrapper + public return object |

---

## A. Runtime identity plane

| Attribute | Detail |
| --------- | ------ |
| **Ownership** | Derived from `useRuntimeTransitionSnapshot()` → `stakingRuntime` (`operationContext`) |
| **State authority** | **External:** runtime selection context / coordinator (not owned here). **Local:** `runtimeWallet` memo, deprecated `isConnected`/`address`/`chainId` bridges |
| **Key outputs** | `runtimeWallet`, `runtimeWalletAddress`, `stakingOwnerAddress`, `executionAddress`, `executionConnected`, `executionChainId`, `executionNetworkOk`, `hasTronAccount` |
| **Side effects** | `publishStakingRuntimeWalletIdentity` / `clearStakingRuntimeWalletIdentityPublish` (effect on `runtimeWallet` + `runtimeKey`); Tron DEV traces (`traceUnifiedTronFallbackActivationDev`, `traceUnifiedTronIdentityMismatchDev`) |
| **Async** | None directly (sync memos + publish) |
| **Refresh triggers** | `stakingRuntime.runtimeKey`, wallet identity fields, AppKit account/network |
| **Dependencies** | `resolveStakingRuntimeWalletIdentity`, `stakingRuntimeWalletIdentityBridge`, `usePassiveTronWallet*`, dual `useAppKitAccount`, env `isAppKitTronIdentityEnabled` |
| **Runtime family** | `isTronPassiveRuntime = chainFamily === "tron"` drives identity inputs (unified Tron vs EVM-only) |
| **Singletons** | **Global publish bridge** (`publishStakingRuntimeWalletIdentity`) — navbar reads published identity |
| **Persistence** | None |
| **Telemetry** | Tron identity DEV traces only |
| **Coordinator** | Reads `transition` but does not mutate coordinator |
| **Tx lifecycle** | None (modal uses frozen `transactionRuntime` separately) |

**Extraction boundary:** **Medium risk** — publish/cleanup ordering must match mount/unmount; navbar depends on bridge singleton.

---

## B. Execution plane

| Attribute | Detail |
| --------- | ------ |
| **Ownership** | EVM: AppKit `eip155` namespace + `useEtheriumWallet({ evmRuntimeActive: !isTronPassiveRuntime })` |
| **State authority** | AppKit for connection/chain; hook for `isWrongNetwork`, switch refs, `isAttemptingNetworkSwitch` |
| **Side effects** | `switchNetwork`, `walletOrchestration.requestNetworkSwitch`, `setInterval` verify poll (`VERIFY_POLL_MS` / `VERIFY_MAX_MS`) |
| **Async** | `handleAutoSwitch`, `requestNetworkSwitch` |
| **Refresh triggers** | `numericChainId`, `hasTriedSwitch`, `tokenMetaError`, connect/disconnect |
| **Dependencies** | `useUnifiedWalletOrchestration`, `STAKING_APPKIT_NETWORK`, passive notification policy + toasts |
| **Runtime family** | EVM-only auto-switch effect (`chainFamily !== "evm"` early return); Tron uses orchestrated switch + `refetchTronPassiveBalances` |
| **Coordinator** | None on switch path |
| **Tx lifecycle** | `canTransact` requires `signer` + `provider` (EVM only); `guardStakingTxExecutionTarget` uses `deriveRuntimeExecutionTarget(stakingRuntime)` |

**Extraction boundary:** **Dangerous** — shares `numericChainIdRef`, `switchVerifyIntervalRef`, `tokenMetaErrorRef`, `wrongNetworkToastShown` with **C** and effect order constraint (chain effect before `loadMeta`).

---

## C. Balance + token meta reads

| Attribute | Detail |
| --------- | ------ |
| **Ownership** | Hook state: `tokenAddress`, `tokenDecimals`, balances, `tokenMetaFetched`, `balancesFetched`, `vaultDataReady` |
| **State authority** | React state + **`balanceSnapshotRef`** / **`lastDisplayBalancesRef`** (orchestrator merge + stale-while-refresh) |
| **Side effects** | RPC via `getStakingVaultRead` / `getStakingErc20Read` / `fetchTronPassiveTokenMeta` / `fetchTronPassiveReadBalances`; toasts on RPC meta failure |
| **Async** | `loadAsset` effect, `loadMeta`, `refetchTronPassiveBalances` |
| **Refresh triggers** | `vaultBalanceResetKey`, `poolSnapshotContinuityKey`, `loadMeta` dep array, `refreshBalances` → `notifyStakingRefresh` + Tron refetch |
| **Dependencies** | `@/staking/execution/stakingReadFactory` (shim), `tronPassiveReads`, `getJsonRpcProviderForDeployment`, `stakingReadOptions` |
| **Runtime family** | Parallel implementations: EVM contract reads vs Tron FullNode passive reads |
| **Singletons** | Read factory module caches (`erc20Cache`, `vaultCache`) — keyed by provider + `runtimeKey` in options |
| **Coordinator** | **Every commit path** calls `canRuntimeOperationCommitWithDevTrace(label, coordinatorAtStart, latestRef.current)` |
| **Stale guards** | `loadMetaRunIdRef`, `tronPassiveFetchGenRef`, `isMountedRef` |

**Extraction boundary:** **Dangerous** — tightly coupled to **F** via `balanceSnapshotRef` and reset keys.

---

## D. History subsystem

| Attribute | Detail |
| --------- | ------ |
| **Ownership** | `stakingHistoryRows`, totals, loading/fetched flags, indexer errors, PnL history readiness |
| **State authority** | React state + **`stakingTransactionHistoryCache`** (module Map singleton) |
| **Side effects** | `loadStakingTransactionHistoryRows` (EVM) / `loadTronStakingTransactionHistoryRows`; abort via `stakingHistoryAbortRef` |
| **Async** | `refreshStakingHistory`, auto-fetch effect when `vaultDataReady` |
| **Refresh triggers** | `stakingHistoryKey` (owner + token + deployment), post-tx `refreshStakingHistory()` from deposit/withdraw |
| **Dependencies** | Etherscan history module, Tron history loader, `mergeStakingHistoryByHash`, `aggregateStakingHistoryRows` |
| **Runtime family** | Branch in `refreshStakingHistory`; Tron requires base58-valid owner/token |
| **Timers** | 15s stall watchdog while loading (90s wall) → telemetry + forced re-fetch |
| **Persistence** | **Cache only** (not tx modal session) |
| **Coordinator** | None on history path |

**Extraction boundary:** **Medium risk** — self-contained API surface (`refreshStakingHistory`) but many refs + `refreshStakingHistoryRef` + Tron rehydrate effect coupling to **A/C**.

---

## E. Affiliate subsystem

| Attribute | Detail |
| --------- | ------ |
| **Ownership** | `useAffiliateFirestoreStats(executionAddress)` — external hook |
| **State authority** | Firestore hook; vault derives `stakingNetPrincipalWei`, `stakingPnlBasisReady`, `stakingPnlWei` |
| **Side effects** | `refetchAffiliateStats` after deposit/withdraw |
| **Async** | Firestore reads (inside child hook) |
| **Refresh triggers** | `executionAddress`, token decimals, affiliate loading/error |
| **Runtime family** | **EVM `executionAddress` only** (not `stakingOwnerAddress`) — intentional for Firestore stats |
| **Tx lifecycle** | `readStoredReferral()` in `deposit` for affiliate vault method |

**Extraction boundary:** **Safe** for thin wrapper — already isolated hook; vault memos are pure derivations.

---

## F. Refresh orchestration

| Attribute | Detail |
| --------- | ------ |
| **Ownership** | EVM: `startStakingRefreshOrchestrator` / `stopStakingRefreshOrchestrator` (module singleton orchestrator) |
| **State authority** | Orchestrator reads/writes **`balanceSnapshotRef`** via `onCommit` |
| **Side effects** | `notifyStakingRefresh(reason)` — fans out to orchestrator + WS block signals (external) |
| **Async** | Orchestrator internal polling; Tron: 45s `setInterval` + `visibilitychange` / `pageshow` |
| **Refresh triggers** | `refreshBalances`, `refreshKey`, wallet/chain/token gates, visibility |
| **Dependencies** | `stakingRefreshOrchestrator`, `transition.executionIdentity`, coordinator snapshot refs |
| **Runtime family** | **Mutually exclusive:** EVM starts orchestrator; Tron stops it and uses passive interval |
| **Coordinator** | `orchestratorCoordinatorAtStart` + `canRuntimeOperationCommitWithDevTrace` on every `onCommit` |
| **Tx lifecycle** | `refreshKey` effect → `notifyStakingRefresh("tx-state-change")` after deposit/withdraw |

**Extraction boundary:** **Dangerous / blocked** without moving `balanceSnapshotRef` + reset effects together.

---

## G. Transaction orchestration hooks

| Attribute | Detail |
| --------- | ------ |
| **Ownership** | `ensureAllowance`, `deposit`, `approveStakeAmount`, `withdraw`, `loading`, `refreshKey` |
| **State authority** | Local `loading`; env-backed `STAKING_VAULT_ADDRESS` contracts via `signer` |
| **Side effects** | On-chain txs; `setRefreshKey`; `refreshStakingHistory`; `refetchAffiliateStats`; `refreshBalances` after approve |
| **Async** | All tx methods; optional `waitForReceipt: false` + `receiptWait` |
| **Guards** | `guardStakingTxExecutionTarget` → `assertExecutionTargetMatchesActive` (Phase 30 modal freeze) |
| **Runtime family** | **EVM-only** (`canTransact` excludes Tron passive) |
| **Modal split** | Vault executes on live env/wallet; modal owns frozen `transactionRuntime` (documented in file header) |
| **Persistence** | Indirect — post-tx refresh may help UI; session restore is **not** here |

**Extraction boundary:** **Medium risk** — large but coherent; must keep `guardStakingTxExecutionTarget` closure over `stakingRuntime`.

---

## H. Persistence / recovery reactions

| Attribute | Detail |
| --------- | ------ |
| **In vault?** | **No direct** sessionStorage or `reconcilePersistedTxSnapshot` |
| **Indirect** | `refreshKey` → `notifyStakingRefresh("tx-state-change")` syncs balance reads after tx completion |
| **Owner** | `TransactionStatusProvider` + `@/staking/tx/stakingTxSessionPersistence` |

**Extraction boundary:** **Blocked** from vault split — belongs to tx provider layer.

---

## I. Runtime transition reactions

| Attribute | Detail |
| --------- | ------ |
| **Ownership** | `transition = useRuntimeTransitionSnapshot()` threaded everywhere |
| **Gates** | `canRuntimeOperationCommitWithDevTrace` on: `loadAsset`, `loadMeta`, Tron balances, orchestrator `onCommit` |
| **Capture pattern** | `coordinatorAtStart` + `latestCoordinatorSnapshotRefLocal.current` at async boundaries |
| **Sequence** | `transition.sequenceStage` fed to soak monitor |
| **Swap policy** | Not imported — denial lives in coordinator/orchestration |

**Extraction boundary:** **Dangerous** — cross-cuts **C**, **F**, **D** (indirect); any extract must receive stable `transition` + ref snapshot API.

---

## J. Diagnostics + soak + telemetry

| Attribute | Detail |
| --------- | ------ |
| **Ownership** | Effects only — logic in `@/staking/diagnostics/*` |
| **Calls** | `recordRuntimeTortureVaultMount/Unmount`, chaos `window` event → `notifyStakingRefresh`, `runStakingVaultSemanticAssertionsDev`, `logRuntimeExecutionPlaneSnapshot`, `tickStakingRuntimeSoakMonitor` |
| **State** | `executionPlaneTelemetryRef` (dedupe cursor), module-level soak singleton |
| **Window APIs** | Registered in soak monitor module: `__stakingRuntimeSoakDump`, `__printStakingRuntimeHealth`, `__stakingRuntimeLastUnstableSnapshot` |
| **Labels** | `[staking-vault][runtime-execution-plane]`, `[staking-runtime-soak]`, `[runtime-core-boundary]` (boundary dev loaded from selection context, not vault) |

**Extraction boundary:** **Safe first** — extract `useStakingVaultDiagnostics(transition, planes, vaultDataReady, …)` with copy-paste effects and identical deps.

---

## K. Derived selectors / memo layer

| Includes | `isWrongNetwork`, `canTransact`, `awaitingSigner`, `vaultDataReady`, `stakingHistoryKey`, formatted strings, `maxStakeWei` / `maxUnstakeWei`, `stakingPnlWei`, `stakingBalanceAnchorMs`, `merchantToken*` |
| **Authority** | Pure derivations from state — no side effects |
| **Risk** | Low — but many depend on deprecated `isConnected` bridge |

**Extraction boundary:** **Safe** after **A/B/C** outputs are stable as a typed “plane snapshot” object.

---

## L. Public API composition

| Attribute | Detail |
| --------- | ------ |
| **Shape** | `StakingVaultValue = ReturnType<typeof useStakingVaultState>` |
| **Wrapper** | `withDeprecatedVaultBridgeDevInstrumentation(returnObject, deprecatedBridgeDevCtx)` |
| **Deprecated fields** | `isConnected`, `address`, `chainId` proxied for soak/legacy consumers |
| **Notable exports** | `activeRuntimeSelection: stakingRuntime`, tx methods, `refreshStakingHistory`, explorer URL resolver |
| **Consumers** | Forms, balance, history, referral, `TransactionStatusSurface`, `RuntimePickerDevPanel`, CTA hooks (types only) |

**Extraction boundary:** **Must remain** final composer — any split feeds into this object unchanged.

---

## Section ownership table

| Cat | Primary state | Primary refs | External singletons | Coordinator gates |
| --- | ------------- | ------------ | --------------------- | ------------------- |
| A | `runtimeWallet` memo | `prevTronIdentityOriginRef` | identity publish bridge | No |
| B | switch flags | `switchVerifyIntervalRef`, `numericChainIdRef`, `isSwitchingRef` | AppKit | No |
| C | token + balances | `balanceSnapshotRef`, `loadMetaRunIdRef`, … | read factory caches | Yes |
| D | history arrays | `stakingHistoryAbortRef`, `stakingHistoryFetchGenRef` | `stakingTransactionHistoryCache` | No |
| E | (hook external) | — | Firestore | No |
| F | `balancesFetched` | `balanceSnapshotRef`, `tronPassiveRefetchRef` | refresh orchestrator | Yes (EVM commit) |
| G | `loading`, `refreshKey` | — | — | No (tx guard only) |
| H | — | — | tx session (provider) | No |
| I | — | `latestCoordinatorSnapshotRef` | coordinator (core) | Yes |
| J | — | `executionPlaneTelemetryRef` | soak monitor | No |
| K | memos | — | — | No |
| L | return object | — | deprecated bridge `warned` Set | No |

---

## Dependency graph (imports → subsystems)

```mermaid
flowchart TB
  subgraph external_hooks [External hooks]
    RTS[useRuntimeTransitionSnapshot]
    AppKit[useAppKitAccount / useAppKitNetwork]
    ETH[useEtheriumWallet]
    AFF[useAffiliateFirestoreStats]
    UWO[useUnifiedWalletOrchestration]
    TronId[usePassiveTronWallet*]
  end

  subgraph vault_hook [useStakingVaultState]
    A[A Runtime identity]
    B[B Execution plane]
    C[C Reads / meta / balances]
    D[D History]
    E[E Affiliate derivations]
    F[F Refresh orchestration]
    G[G Tx methods]
    J[J Diagnostics effects]
    K[K Memos]
    L[L Public return]
  end

  subgraph singletons [Module / global singletons]
    PubBridge[publishStakingRuntimeWalletIdentity]
    HistCache[stakingTransactionHistoryCache]
    RefreshOrch[stakingRefreshOrchestrator]
    ReadFactory[stakingReadFactory caches]
    Soak[tickStakingRuntimeSoakMonitor / window APIs]
  end

  RTS --> A
  RTS --> I[I Transition gates]
  I --> C
  I --> F
  AppKit --> A
  AppKit --> B
  TronId --> A
  ETH --> B
  ETH --> G
  AFF --> E
  UWO --> B
  A --> PubBridge
  C --> ReadFactory
  F --> RefreshOrch
  F --> C
  D --> HistCache
  G --> D
  G --> F
  J --> Soak
  A --> K
  C --> K
  D --> K
  E --> K
  K --> L
  G --> L
  F --> L
  J --> L
```

### Mutable refs (cross-section)

| Ref | Shared by |
| --- | --------- |
| `balanceSnapshotRef` | F orchestrator `onCommit`, C Tron refetch, `vaultBalanceResetKey`, `poolSnapshotContinuityKey` |
| `lastDisplayBalancesRef` | C continuity seeding, F `onCommit`, reset effects |
| `numericChainIdRef` | B switch verify interval, B chain effect |
| `tokenMetaErrorRef` | B switch poll, B `loadMeta` coordination |
| `tronPassiveRefetchRef` | F `refreshBalances`, C Tron effect wiring |
| `refreshStakingHistoryRef` | D stall recovery, D Tron rehydrate |
| `isMountedRef` | C async guards, B switch, F orchestrator |

### Timers / listeners

| Mechanism | Location | Purpose |
| --------- | -------- | ------- |
| `setInterval` 150ms | B `handleAutoSwitch` | Post-switch chain verify |
| `setInterval` 45s | F Tron balances | Passive poll |
| `setInterval` 15s | D history | Stall watchdog |
| `visibilitychange` / `pageshow` | F Tron | Resume refetch |
| `STAKING_RUNTIME_CHAOS_WALLET_SURGE_EVENT` | J | DEV refresh surge |

---

## Hidden coupling report

### 1. Effect ordering (documented in source)

- **Lines 1210–1265:** EVM chain reconciliation runs **before** `void loadMeta()` (line 1263) so correct-chain handling precedes meta load.
- **Risk:** Splitting B and C into separate files without preserving mount order may regress wrong-network → meta races.

### 2. Shared balance snapshot pipeline

- EVM orchestrator and Tron refetch **both** write `balanceSnapshotRef` + React setters.
- `vaultBalanceResetKey` zeroes refs **and** React state on runtime/wallet change.
- `poolSnapshotContinuityKey` seeds `balanceSnapshotRef` from `lastDisplayBalancesRef` on token change (Phase 48/53.3).
- **Write-after-read hazard:** orchestrator `getPrevious: () => balanceSnapshotRef.current` vs reset effect on same key family.

### 3. Coordinator generation drift

- Async handlers capture `coordinatorAtStart` but commit checks read **latest** ref.
- **Risk:** Stale commits suppressed correctly today; extraction must not collapse start/latest into one value.

### 4. `refreshKey` bridge to global refresh

- Deposit/withdraw increment `refreshKey` → effect calls `notifyStakingRefresh("tx-state-change")`.
- **Couples G → F** without direct tx modal import.

### 5. Dual address model

- **History / PnL owner:** `stakingOwnerAddress` (`runtimeWalletAddress`)
- **Execution / affiliate / EVM reads:** `executionAddress` / `address`
- **Tron:** unified identity may differ from AppKit Tron namespace.
- **Risk:** Extracting history without A planes breaks Tron unified identity.

### 6. `tronPassiveRefetchRef` indirection

- `refreshBalances` defined **before** Tron effect assigns ref (comment: avoid hook reorder).
- **Blocked:** Cannot move `refreshBalances` below Tron effect without violating rules of hooks.

### 7. `isConnected` deprecated bridge

- Tron: `runtimeWallet.connected`; EVM: `executionConnected`.
- `canTransact`, affiliate PnL, history gates use mixed bridge — soak/telemetry still consume deprecated fields via return wrapper.

### 8. Module-level singletons

- `stakingTransactionHistoryCache` — shared across vault instances (typically one provider).
- `stakingHistoryWarnedDeprecatedZeroBlock` — module-once warn.
- Read factory caches — global per deployment/provider.

### 9. No tx session in vault

- Recovery after refresh is **not** vault-owned; avoid pulling persistence into vault extracts.

---

## Extraction boundaries

| Candidate module | Risk | Notes |
| ---------------- | ---- | ----- |
| `useStakingVaultDiagnostics` (J) | **Safe** | Pure effects; external modules already extracted (C5) |
| `useStakingVaultAffiliateDerivations` (E + K PnL memos) | **Safe** | Thin; `useAffiliateFirestoreStats` already separate |
| `useStakingVaultFormattedSelectors` (K subset) | **Safe** | Pure memos; needs stable input DTO |
| `useStakingVaultHistory` (D) | **Medium** | Clear `refreshStakingHistory` API; refs + cache + stall timer |
| `useStakingVaultTx` (G) | **Medium** | Large; needs `canTransact`, signer, guard, refresh callbacks |
| `useStakingVaultRuntimePlanes` (A + B partial) | **Medium** | Publish bridge + AppKit + wrong network |
| `useStakingVaultReads` (C) | **Dangerous** | `loadMeta`, refs, Tron/EVM fork, coordinator gates |
| `useStakingVaultRefresh` (F) | **Dangerous** | Orchestrator singleton + Tron timers + `balanceSnapshotRef` |
| Split `vaultBalanceResetKey` / continuity effects | **Dangerous** | Must move with C+F |
| Transition gate helper inline | **Blocked** | Cross-cuts async paths — keep as shared import from core |

---

## DO NOT SPLIT YET

1. **`vaultBalanceResetKey` effect + `poolSnapshotContinuityKey` effect + EVM orchestrator effect + Tron interval effect** — shared `balanceSnapshotRef` / `lastDisplayBalancesRef`.
2. **EVM chain reconciliation effect + `loadMeta` effect + `loadAsset` effect** — ordering comment is a contract.
3. **`refreshBalances` + `tronPassiveRefetchRef` assignment effect** — hook order constraint.
4. **`transition` snapshot + all `canRuntimeOperationCommitWithDevTrace` call sites** — keep one import surface until coordinator API is stable.
5. **Deprecated bridge return** — `withDeprecatedVaultBridgeDevInstrumentation` must wrap final object once.
6. **`refreshKey` → `notifyStakingRefresh`** — ties post-tx G to F.

---

## Recommended decomposition order

| Phase | Target | Rationale |
| ----- | ------ | ----------- |
| **D1** | `useStakingVaultDiagnostics.ts` | Lowest blast radius; C5 already moved implementations; copy effects 2239–2336 + 608–626 |
| **D2** | Affiliate + PnL memos (or keep inline) | Already isolated Firestore hook |
| **D3** | `useStakingVaultHistory.ts` | Bounded API; pass `refreshStakingHistory` + state setters; watch cache singleton |
| **D4** | `useStakingVaultTx.ts` | Coherent tx surface; inject `guardStakingTxExecutionTarget`, refresh callbacks |
| **D5** | `useStakingVaultRuntimePlanes.ts` | Identity + publish + execution addresses |
| **D6** | `useStakingVaultReads.ts` + `useStakingVaultRefresh.ts` | **Highest risk** — do together or keep merged; share refs via returned ref bag |
| **D7** | Thin `useStakingVault.ts` composer | Wire planes → reads → refresh → history → tx → diagnostics → `L` |

### Must remain in root composer

- `useRuntimeTransitionSnapshot()` subscription
- Ref bag creation **or** explicit pass-through from sub-hooks
- `withDeprecatedVaultBridgeDevInstrumentation(...)` return
- `refreshBalances` / `tronPassiveRefetchRef` wiring if Tron effect stays separate from F

### Temporary bridge requirements

- Export unchanged `StakingVaultValue` type from composer
- Keep `@/hooks/useStakingVault` types (`StakingTokenMetaError`, etc.) stable
- Sub-hooks should return **plain objects**; composer merges into current key order for minimal consumer diff

---

## Danger zones

| Zone | Why |
| ---- | --- |
| **F + C ref sharing** | Silent balance corruption if orchestrator and reset effects diverge |
| **Coordinator commit gates** | Removing/refactoring labels breaks DEV soak diagnostics |
| **EVM vs Tron refresh split** | Starting orchestrator on Tron or Tron interval on EVM |
| **Effect order B → C** | Wrong-network meta flapping |
| **Affiliate address vs runtime owner** | Wrong PnL if `executionAddress` swapped for `stakingOwnerAddress` |
| **Global history cache** | Second vault instance (tests) can cross-contaminate rows |
| **Identity publish bridge** | Navbar stale if publish/cleanup effect dropped |

---

## Safe-first candidates (Phase D1)

**Recommended Phase D1 target:** `src/hooks/useStakingVaultDiagnostics.ts`

- Extract lines **608–626** (torture mount, chaos listener) + **2239–2336** (semantic assertions, execution-plane telemetry, soak tick).
- Pass inputs: `stakingRuntime`, `transition`, execution/wallet plane fields, `vaultDataReady`, `canTransact`, `isWrongNetwork`.
- **No behavior change** if effect dependency arrays are byte-identical.
- Validates extraction pipeline before touching `balanceSnapshotRef`.

**Alternative safe D1:** Document-only sub-typing — introduce `StakingVaultPlaneSnapshot` type alias without moving code (optional D0.5).

---

## Verification (Phase D0)

| Check | Status |
| ----- | ------ |
| Code behavior unchanged | Yes — documentation only |
| `pnpm typecheck` | Run below |
| `pnpm build` | Run below |

---

## Related files (not in scope for split)

| File | Role |
| ---- | ---- |
| `stakingVaultContext.ts` | Provider + `useStakingVault` |
| `stakingRefreshOrchestrator.ts` | EVM balance polling singleton |
| `TransactionStatusProvider.tsx` | Tx modal + session persistence |
| `stakingRuntimeWalletIdentityBridge.ts` | Global published identity |

---

*Generated for Architecture Consolidation Phase D0. No production code modified.*
