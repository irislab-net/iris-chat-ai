# Phase B — Layer boundary report

**Status:** Complete (type extraction only; no runtime/orchestration/tx behavior changes).

**Date:** 2026-05-15

---

## 1. Objective

Eliminate layer inversion between `staking/core`, tx lifecycle types, UI components, and hooks by introducing **neutral type modules** and **temporary re-export bridges**, without changing swap policy semantics, tx modal lifecycle, or orchestration.

---

## 2. New modules created

| Path | Contents |
| ---- | -------- |
| `src/staking/tx/types/transactionStatusScenario.ts` | `TransactionStatusScenario` |
| `src/staking/tx/types/transactionStatusWirePhase.ts` | `TransactionWireStepPhase` |
| `src/staking/tx/types/transactionStatusUiPhase.ts` | `TransactionStatusUiPhase`, `isTransactionStatusInFlightPhase`, `TERMINAL_UI_PHASES_FOR_RUNTIME_SWAP` |
| `src/staking/tx/types/transactionStatusSnapshot.ts` | `TransactionStatusSnapshot` (shape only) |
| `src/staking/tx/types/index.ts` | Barrel re-exports |
| `src/staking/cta/types/stakingCtaContracts.ts` | `StakingCtaActionType`, `StakingCtaInlineSnapshot` |
| `src/staking/cta/types/index.ts` | Barrel re-exports |
| `src/staking/core/runtimeCoreLayerBoundaryDev.ts` | DEV static import boundary scanner |

**Not moved:** `transactionStatusModel.ts` (implementation, context API, helpers remain in place).

---

## 3. Imports removed (layer inversions fixed)

### 3.1 `staking/core` → `components/` (removed)

| File | Before | After |
| ---- | ------ | ----- |
| `runtimeSwapPolicy.ts` | `@/components/pages/staking/transactionStatusModel` (`TransactionStatusUiPhase`) | `@/staking/tx/types/transactionStatusUiPhase` |

`runtimeTransitionCoordinator.ts` — **no change required** (already had no `components/` or `hooks/` imports).

### 3.2 `staking/dev` → `components/` (removed)

| File | Before | After |
| ---- | ------ | ----- |
| `runtimeLifecycleAssertions.ts` | `TransactionStatusSnapshot` from `transactionStatusModel` | `@/staking/tx/types/transactionStatusSnapshot` |

### 3.3 `lib/staking` → `hooks/` (removed)

| File | Before | After |
| ---- | ------ | ----- |
| `stakingFormInlineReasonResolver.ts` | `Pick<StakingCtaState, …>` from `useStakingCtaState` | `StakingCtaInlineSnapshot` from `@/staking/cta/types` |

### 3.4 Additional type-path alignment (non-breaking)

| File | Change |
| ---- | ------ |
| `stakingSnapshotCtaPhase.ts` | Types from `@/staking/tx/types/*` |
| `stakingUiPhase.ts` | `TransactionStatusUiPhase` from neutral module |
| `useStakingCtaState.ts` | `TransactionStatusSnapshot` + `StakingCtaActionType` from neutral modules |

---

## 4. Temporary re-export bridges (backward compatibility)

`src/components/pages/staking/transactionStatusModel.ts` re-exports neutral types so existing imports keep working:

```ts
export type { TransactionStatusScenario } from "@/staking/tx/types/transactionStatusScenario"
export type { TransactionWireStepPhase } from "@/staking/tx/types/transactionStatusWirePhase"
export type { TransactionStatusUiPhase } from "@/staking/tx/types/transactionStatusUiPhase"
export type { TransactionStatusSnapshot } from "@/staking/tx/types/transactionStatusSnapshot"
export {
  isTransactionStatusInFlightPhase,
  TERMINAL_UI_PHASES_FOR_RUNTIME_SWAP,
} from "@/staking/tx/types/transactionStatusUiPhase"
```

`useStakingCtaState.ts` re-exports:

```ts
export type { StakingCtaActionType } from "@/staking/cta/types/stakingCtaContracts"
```

**Consumers still on bridge path (unchanged imports, valid):**

- `TransactionStatusProvider.tsx`, `TransactionStatusSurface.tsx`
- `StakingAppDepositForm.tsx`, `StakingAppWithdrawForm.tsx`
- `stakingTxSessionPersistence.ts`, `stakingTxOnChainRecovery.ts`
- `TransactionStatusContext.tsx`

---

## 5. DEV boundary guard

**Module:** `src/staking/core/runtimeCoreLayerBoundaryDev.ts`

- On DEV load, scans `staking/core/**/*.ts` and `staking/dev/**/*.ts` via `import.meta.glob` (raw source).
- Forbidden prefixes: `@/components/`, `@/hooks/`, `components/pages/`, `@/pages/`.
- Logs `[runtime-core-boundary]` success or `console.error` with violation list.

**Installed from:** `runtimeSelectionContext.tsx` (dynamic import when `import.meta.env.DEV`).

**Verification (2026-05-15):** `rg` over `staking/core` and `staking/dev` — **zero** `@/components/` or `@/hooks/` imports.

---

## 6. Remaining layer inversions (documented, not Phase B scope)

| From | To | Notes |
| ---- | -- | ----- |
| `lib/staking/stakingTxSessionPersistence.ts` | `transactionStatusModel` | Types + `createIdleTransactionStatusSnapshot` — Phase C/D: import types from `@/staking/tx/types`, keep factory in model |
| `lib/staking/stakingTxOnChainRecovery.ts` | `transactionStatusModel` | Types + `deriveCurrentTxHashFromSnapshot` — extract hash helper to `staking/tx/` later |
| `staking/core/runtimeSwapPolicy.ts` | (none forbidden) | Uses neutral types only |
| `useStakingCtaState.ts` | `useStakingVault` (`StakingTokenMetaError`) | Hook → hook; fix when vault types extracted |
| `lib/stakingUiPhase.ts` | `useStakingCtaState` | Lib → hook for CTA UI phase derivation |
| `staking/core/runtimeSwapPolicy.ts` | `lib/staking` | N/A — no lib inversion for policy |

**Structural inversion (type-only, acceptable for Phase B):**

- `transactionStatusSnapshot.ts` depends on `lib/staking/stakingFeeCanonical` and `lib/stakingDepositApprovalExecution` — not UI; OK for neutral tx types.

---

## 7. Blocked / deferred extractions

| Item | Reason | Target phase |
| ---- | ------ | ------------- |
| `OpenPendingInput`, `TransactionStatusContextValue`, reducer API | UI + behavior surface; not types-only | Phase C+ / tx module split |
| `deriveCurrentTxHashFromSnapshot` | Logic in model file; moving changes import graph | Phase C (`staking/tx/`) |
| `createIdleTransactionStatusSnapshot` | Factory tied to model empty state | Phase C |
| `StakingCtaState` full type | Hook-owned; only inline snapshot extracted | Phase E |
| `StakingCtaTxPhase` | Already in `@/types/stakingCtaTxPhase` | Optional merge into `staking/cta/types` later |
| `TransactionStatusSnapshot` implementation helpers in model | Intentionally left in bridge file | Phase C |

---

## 8. Future cleanup candidates

1. Point all `transactionStatusModel` type-only imports → `@/staking/tx/types` (wide codemod).
2. Remove duplicate `TERMINAL_UI_PHASES` — single source in `transactionStatusUiPhase.ts` (done for policy).
3. Move `deriveStakingCtaTxPhaseFromSnapshot` next to neutral snapshot type (lib stays pure).
4. Extract `StakingTokenMetaError` to `staking/vault/types` to decouple `useStakingCtaState` from vault hook.
5. ESLint `no-restricted-imports` for `staking/core/**` mirroring DEV guard (CI).
6. Delete re-export bridge in `transactionStatusModel.ts` after consumer codemod.

---

## 9. Verification

| Check | Result |
| ----- | ------ |
| `pnpm typecheck` | Pass |
| `pnpm build` | Pass |
| Swap policy semantics | Unchanged — `TERMINAL_UI_PHASES_FOR_RUNTIME_SWAP` moved verbatim; `evaluateRuntimeSwapPolicy` logic untouched |
| Tx modal lifecycle | Unchanged — `transactionStatusModel.ts` retains all functions and `TransactionStatusContextValue` |
| Runtime soak | Unchanged — soak modules not modified; `window.__stakingRuntimeSoakDump` / `__printStakingRuntimeHealth` still wired from vault |
| `staking/core` forbidden imports | None (`rg` verified) |

**Manual smoke (recommended):** connect → deposit preview → cancel; runtime swap with modal closed; DEV console `[runtime-core-boundary] staking/core+dev: no forbidden imports` on `/staking/app` load.

---

## 10. Dependency graphs (before / after)

### 10.1 Runtime core (`staking/core`)

**Before (Phase A violation):**

```mermaid
flowchart LR
  runtimeSwapPolicy[runtimeSwapPolicy.ts]
  txModel[components/.../transactionStatusModel.ts]
  persistence[persistenceTypes.ts]
  runtimeSwapPolicy --> txModel
  runtimeSwapPolicy --> persistence
```

**After (Phase B):**

```mermaid
flowchart LR
  runtimeSwapPolicy[runtimeSwapPolicy.ts]
  txUiPhase[staking/tx/types/transactionStatusUiPhase.ts]
  persistence[persistenceTypes.ts]
  runtimeSwapPolicy --> txUiPhase
  runtimeSwapPolicy --> persistence
  txUiPhase -.->|no import| components[components/]
```

### 10.2 Tx model layer

**Before:**

```mermaid
flowchart TB
  subgraph ui [components/pages/staking]
    model[transactionStatusModel.ts]
    provider[TransactionStatusProvider]
  end
  subgraph core [staking/core]
    policy[runtimeSwapPolicy]
  end
  subgraph lib [lib/staking]
    persist[stakingTxSessionPersistence]
    ctaPhase[stakingSnapshotCtaPhase]
  end
  policy --> model
  persist --> model
  ctaPhase --> model
  provider --> model
  model --> persistenceTypes[persistenceTypes]
  model --> feeCanonical[stakingFeeCanonical]
```

**After:**

```mermaid
flowchart TB
  subgraph neutral [staking/tx/types]
    uiPhase[transactionStatusUiPhase]
    snapshot[transactionStatusSnapshot]
    scenario[transactionStatusScenario]
  end
  subgraph ui [components/pages/staking]
    model[transactionStatusModel.ts]
    provider[TransactionStatusProvider]
  end
  subgraph core [staking/core]
    policy[runtimeSwapPolicy]
  end
  subgraph lib [lib/staking]
    persist[stakingTxSessionPersistence]
    ctaPhase[stakingSnapshotCtaPhase]
  end
  policy --> uiPhase
  ctaPhase --> snapshot
  ctaPhase --> scenario
  model -->|re-export| neutral
  model -->|implements| snapshot
  persist -->|bridge import| model
  provider -->|bridge import| model
  snapshot --> persistenceTypes[persistenceTypes]
  snapshot --> feeCanonical[stakingFeeCanonical]
```

### 10.3 CTA layer

**Before:**

```mermaid
flowchart LR
  inlineResolver[stakingFormInlineReasonResolver]
  ctaHook[useStakingCtaState]
  inlineResolver --> ctaHook
  ctaHook --> txModel[transactionStatusModel]
```

**After:**

```mermaid
flowchart LR
  subgraph neutralCta [staking/cta/types]
    contracts[stakingCtaContracts]
  end
  subgraph neutralTx [staking/tx/types]
    snap[transactionStatusSnapshot]
  end
  inlineResolver[stakingFormInlineReasonResolver]
  ctaHook[useStakingCtaState]
  ctaPhase[stakingSnapshotCtaPhase]
  inlineResolver --> contracts
  ctaHook --> contracts
  ctaHook --> snap
  ctaPhase --> snap
  ctaHook -.->|StakingTokenMetaError| vaultHook[useStakingVault]
```

---

## 11. Files touched (summary)

| Action | Files |
| ------ | ----- |
| **Created** | `staking/tx/types/*` (5), `staking/cta/types/*` (2), `runtimeCoreLayerBoundaryDev.ts` |
| **Updated** | `transactionStatusModel.ts`, `runtimeSwapPolicy.ts`, `runtimeLifecycleAssertions.ts`, `stakingFormInlineReasonResolver.ts`, `stakingSnapshotCtaPhase.ts`, `stakingUiPhase.ts`, `useStakingCtaState.ts`, `runtimeSelectionContext.tsx` |
| **Not touched** | `useStakingVault.ts`, swap engine, coordinator, tx provider logic, AppKit, reownKit |

---

## 12. Related docs

- `docs/architecture-consolidation-census.md` — Phase A inventory
- `docs/architecture-consolidation-plan.md` — Phase B spec (§4)
- `docs/staking-runtime-wallet-migration-status.md` — runtime vs execution (unchanged)

---

*End of Phase B boundary report.*
