# Staking cleanup report — Phase P2

**Scope:** Controlled cleanup after G4d freeze + P1 audits. **No** topology, hook-order, plane ownership, orchestrator semantics, or refresh/history/tx contract changes.

**Verification:** `pnpm typecheck` ✅ · `pnpm build` ✅

---

## 1. Summary counts

| Metric | Value |
|--------|------|
| **Source files deleted** | 0 |
| **Public / barrel exports removed** | 0 |
| **Temporary debug prefixes removed** | 2 families (`[staking-balance-debug]`, `[staking-history-refresh-debug]`) — all call sites in repo |
| **Logic deduplication passes** | 1 (`StakingAppBalance` → `@/staking/affiliate/stakingAffiliatePresentation`) |
| **Helper symbols consolidated** | 8 (imports: direction, dust/settled checks, normalize, PnL floats, ROI selector) |

---

## 2. Code changes (by file)

### 2.1 Removed temporary DEV traces

| File | Change |
|------|--------|
| `src/staking/execution/stakingReadFactory.ts` | Removed `executeStakingFastRead` post-read `console.log` |
| `src/staking/refresh/useStakingVaultBalanceRefresh.ts` | Removed orchestrator guard/start/onCommit logs |
| `src/staking/history/useStakingVaultHistory.ts` | Removed all `refreshStakingHistory` tracing branches |
| `src/components/pages/staking/StakingAppTransactionHistory.tsx` | Removed button-path logs; trimmed `useCallback` deps (no longer needed for logging) |

**Preserved:** `logStakingHistoryConsoleError` on real load failures (non-debug).

### 2.2 Safe dedup (presentation-only)

| File | Change |
|------|--------|
| `src/components/pages/staking/StakingAppBalance.tsx` | Replaced inlined PnL/dust/ROI helpers with canonical exports from `staking/affiliate/stakingAffiliatePresentation.ts` (`selectStakingRoiPercent`, `selectPnlTokenFloat`, `selectCostBasisTokenFloat`, `getStakingPnlDirectionFromWei`, `isResidualDustStakingPosition`, `isSettledResidualPosition`, `normalizeSignedZeroDisplay`, `StakingPnlDirection`). Removed unused `formatUnits` import. |

**Behavior intent:** Identical formulas and thresholds (same module was the source of truth for affiliate PnL presentation).

---

## 3. Dead code audit (not executed aggressively)

| Area | Result |
|------|--------|
| Unused whole files | **Not** bulk-deleted — requires `knip`/full graph in a follow-up; risk of dynamic import / barrel side effects |
| Dead exports / barrels | **Not** changed — P2 avoids shrinking public surfaces without consumer audit |
| Obsolete migration comments in runtime | **Not** stripped — many double as invariant documentation (G4c, Phase numbers) |
| Refs / mirrors | **Not** removed — no proof of full unused wiring without runtime QA |

---

## 4. Duplicate logic — classification (remaining)

| Duplication | Class |
|-------------|--------|
| `removeTrailingZeros(formatUnits(...))` in deposit/withdraw | **Intentional** — UI-local max/amount strings; shared `removeTrailingZeros` in `@/lib/utils` |
| Gas / native `formatEther` in forms vs estimator | **Intentional** — different contexts (display vs RPC path) |
| `stakingVaultDisplaySelectors` vs form formatting | **Intentional** — vault public vs rich form UX |
| Large form files (deposit/withdraw) | **Risky dedup** — extract shared hooks only with golden UX tests |

---

## 5. Barrel / ESLint / smoke

| Check | Result |
|-------|--------|
| Frozen boundary rules (`eslint.config.js` + `stakingBoundaryRules`) | **Unchanged** |
| Architecture smoke / invariants / soak | **Unchanged** — no removals |

---

## 6. Documentation

| Doc | Action |
|-----|--------|
| `docs/archive/migration-phase-reports/staking-dev-cleanup-candidates.md` | Updated §1 to note P2 trace removal |
| Migration reports under `docs/*` | **Kept** — historical; not relocated in P2 |

---

## 7. Remaining technical debt (explicit)

- Full dead-export / unused-file pass with **`knip`** or **`ts-prune`** + CI.
- Optional: virtualize long transaction-history rows after Profiler proof (P1).
- `staking/execution/index.ts` remains a **wide** barrel — hot paths should prefer **direct** imports (product hygiene).

---

## 8. Dangerous areas intentionally untouched

- `useStakingVault` / composer hook order and network glue slot
- `stakingRefreshOrchestrator` tick, coalescing, commit gates
- History cache keys, merge, Tron/EVM loaders
- Tx execution and modal provider boundaries
- Chaos / torture / soak / smoke registration

---

*Phase P2 — controlled cleanup complete.*
