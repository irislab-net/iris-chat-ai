# Staking configuration canonicalization — Phase CFG2 report

**Date:** 2026-05-16  
**Type:** Non-destructive, additive extraction under `src/staking/config/`. **No env vars removed.**  
**Verification:** `pnpm typecheck` **pass** · `pnpm build` **pass**.

---

## 1. Objectives met

| Goal | Status |
|------|--------|
| Typed canonical staking config layer | Added `src/staking/config/*` |
| Preserve runtime behavior | Logic moved verbatim (ETH/USD TTL + stale clamp; CAIP fallbacks; literals) |
| Env fallbacks retained | `stakingEthConfig` still reads `import.meta.env` for tuning keys |
| Deployment-sensitive values stay env-backed | RPC, vault, Firebase, Reown, origins untouched; `getExpectedChainId` **re-exported** from `env.ts` only |
| Staking-tree-only edits | No changes under `src/components`, `vite.config`, CI, or `constants/` |

---

## 2. New modules

| File | Role |
|------|------|
| `stakingConfigTypes.ts` | Shared types (`LegacyEvmNativeCurrency`, chain family literals types). |
| `stakingEthConfig.ts` | `STAKING_ETH_CHAIN_FAMILY`, `STAKING_ETH_CAIP2_PREFIX`, `LEGACY_EVM_NATIVE_CURRENCY`, `readEthUsdCachePollTtlMs()`, `getEthUsdFeedStaleThresholdSec()` (singleton cache preserved). |
| `stakingTronConfig.ts` | `STAKING_TRON_CHAIN_FAMILY`, `EXPLICIT_TRON_ROW_CAIP2_WHEN_ENV_UNSET` (`"tron:mainnet"`). |
| `stakingUiConfig.ts` | `STAKING_DEFAULT_STABLECOIN_LABEL` (`"USDC"`) for staking-side presentation fallback. |
| `stakingFeatureFlags.ts` | Re-exports staking-relevant **env-backed** flags from `@/config/env` (no new defaults). |
| `stakingConfigRuntime.ts` | Runtime getters / re- exports: ETH helpers + Tron constants + UI label + **`getExpectedChainId`** bridge. |
| `stakingConfig.ts` | Namespaced `stakingConfig` object (`eth`, `tron`, `ui`, `featureFlags`). |
| `index.ts` | Public barrel for `@/staking/config`. |

---

## 3. Migration mapping table

| Config / API | Old source | New canonical source | Compatibility fallback | Risk |
|--------------|------------|----------------------|------------------------|------|
| ETH/USD poll TTL | `import.meta.env.VITE_ETH_USD_CACHE_TTL_MS` in `ethUsdPriceCache.ts` | `readEthUsdCachePollTtlMs()` → `@/staking/config` | Same env key inside `stakingEthConfig.ts` | Low — logic copied 1:1 |
| ETH/USD stale threshold | `import.meta.env.VITE_ETH_USD_FEED_STALE_AFTER_SEC` in `ethUsdPriceCache.ts` | `getEthUsdFeedStaleThresholdSec()` | Same env key; module-level cache unchanged | Low |
| `DEBUG_LOGS` | `@/config/env` | `@/staking/config` (re-export) | `env.ts` | Low |
| Runtime dev flags (chaos, torture, picker, stress harness, switch execution, AppKit Tron diag) | `@/config/env` | `@/staking/config` (re-export) | `env.ts` | Low |
| `getExpectedChainId` | `@/config/env` | `@/staking/config` via `stakingConfigRuntime.ts` re-export | `env.ts` | **Med** — bridge only; value still 100% env |
| Explicit EVM `chainFamily` + CAIP prefix | `"evm"`, `` `eip155:${id}` `` in `buildExplicitEnvDeploymentRows` | `STAKING_ETH_CHAIN_FAMILY`, `STAKING_ETH_CAIP2_PREFIX` | N/A (constants) | Low |
| Explicit Tron `chainFamily` + CAIP fallback | `"tron"`, `"tron:mainnet"` | `STAKING_TRON_CHAIN_FAMILY`, `EXPLICIT_TRON_ROW_CAIP2_WHEN_ENV_UNSET` | Env `VITE_STAKING_TRON_CAIP2` still wins when set | Low |
| Legacy row `chainFamily` | `"evm"` in `buildLegacyDeploymentFromEnv` | `STAKING_ETH_CHAIN_FAMILY` | N/A | Low |
| v2 session default `chainFamily` | `"evm"` in `stakingTxSessionPersistence` | `STAKING_ETH_CHAIN_FAMILY` | N/A | Low |
| Stablecoin display fallback | `STAKING_STABLECOIN_LABEL` from `@/constants/stakingVaultConfig` | `STAKING_DEFAULT_STABLECOIN_LABEL` | Same string `"USDC"`; **constants export unchanged** for non-staking | Low (duplicate label until CFG3 aligns `stakingVaultConfig`) |
| `LEGACY_EVM_NATIVE_CURRENCY` | Duplicated in `stakingVaultConfig` `defineChain` | Canonical in `stakingEthConfig`; **non-staking** copy **not** updated (scope) | `stakingVaultConfig` still embedded literal | Low (values identical) |

---

## 4. Env keys: consumption model after CFG2

### 4.1 No longer read via raw `import.meta.env` in `src/staking/*` (except below)

- `VITE_ETH_USD_CACHE_TTL_MS` — read only inside `stakingEthConfig.ts`.
- `VITE_ETH_USD_FEED_STALE_AFTER_SEC` — read only inside `stakingEthConfig.ts`.

### 4.2 Still read via raw `import.meta.env` in staking (intentional)

| Key | Location | Reason |
|-----|---------|--------|
| `VITE_RUNTIME_SWAP_STRESS` | `runtimeTransitionTelemetry.ts` | Deployment-varying dev/stress path; **not** moved per CFG2 rules |

All other `VITE_*` staking usage flows through `@/config/env` or `@/staking/config` re-exports.

### 4.3 Remaining env-only (unchanged)

- Full legacy + Phase 46 explicit blocks: RPC/WS, vault, token addresses, explorer URLs, `VITE_STAKING_TX_HISTORY_ORIGIN`, Firebase, Reown, metadata URLs, telemetry/switch rollout, etc. — **unchanged**; still read in `env.ts` / `ethUsdChainlinkFeeds` / affiliate modules as before.

---

## 5. Dangerous keys intentionally untouched

- `VITE_STAKING_*`, `VITE_STAKING_ETH_*`, `VITE_STAKING_TRON_*` deployment fields  
- `VITE_STAKING_DEPLOYMENTS_JSON`  
- `VITE_*_RPC_URL`, `VITE_*_WS_URL`, vault/token addresses  
- `VITE_FIREBASE_*`, `VITE_AFFILIATE_*`, `VITE_REOWN_PROJECT_ID`  
- `VITE_STAKING_TX_HISTORY_ORIGIN`, `VITE_STAKING_TRON_TX_HISTORY_GRID_API_URL`  
- `VITE_CHAINLINK_ETH_USD_FEED` (still read in `constants/ethUsdChainlinkFeeds.ts`, non-staking path)  
- Rollout / telemetry layers (still implemented in `env.ts`; re-exported only)

---

## 6. Blast radius

| Area | Radius |
|------|--------|
| ETH/USD presentation cache | **Low** — pure refactor of env read site + shared helper |
| Deployment registry explicit rows | **Low** — string constants and CAIP prefix must match previous literals |
| Stablecoin label in staking selectors / lifecycle assertions | **Low** — same `"USDC"`; **drift risk** if `stakingVaultConfig` ever changes independently |
| Feature-flag import path | **Low** — same functions from `env.ts` |

---

## 7. Rollback

- Revert commits touching `src/staking/config/**` and listed consumers; restore prior imports from `@/config/env` and inline literals.  
- No env or deployment changes required for rollback.

---

## 8. Follow-ups (CFG3+)

1. **De-duplicate** `STAKING_STABLECOIN_LABEL` in `stakingVaultConfig` vs `STAKING_DEFAULT_STABLECOIN_LABEL` (requires touching `src/constants`, out of CFG2 scope).  
2. **Adopt** `LEGACY_EVM_NATIVE_CURRENCY` in `stakingVaultConfig` or vice versa to single-source native currency metadata.  
3. **Route** `VITE_RUNTIME_SWAP_STRESS` through a tiny reader in `stakingFeatureFlags` if raw `import.meta.env` in staking should go to zero (behavior-neutral wrapper).

---

*End of CFG2 report.*
