# Vault refresh + read topology report (Phase D3b0)

**Scope:** `src/hooks/useStakingVault.ts`, `src/lib/staking/stakingRefreshOrchestrator.ts`, read execution shims, runtime transition gates.  
**Rules:** Analysis only — no refactors, extractions, effect moves, renames, or behavior changes.  
**Companion:** [`vault-anatomy-report.md`](vault-anatomy-report.md) (D0), [`architecture-consolidation-plan.md`](architecture-consolidation-plan.md) (D3a complete → D3b).

---

## Executive summary

| Finding | Detail |
| ------- | ------ |
| **Dual refresh engines** | EVM: module singleton orchestrator (`startStakingRefreshOrchestrator`). Tron: vault-owned 45s interval + visibility/pageshow (orchestrator **stopped**). |
| **Single merge authority** | `balanceSnapshotRef` + `lastDisplayBalancesRef` — written by orchestrator `onCommit`, Tron `refetchTronPassiveBalances`, reset/continuity effects. |
| **Highest-risk contract** | Effect order: EVM chain reconciliation (L1037) **before** `void loadMeta()` (L1088); `refreshBalances` (L479) **before** `tronPassiveRefetchRef` wiring (L842). |
| **Coordinator gates** | Every async commit path: `coordinatorAtStart` captured at start + `canRuntimeOperationCommitWithDevTrace(label, start, latestRef.current)` at boundaries. |
| **Tx → balance path** | `setRefreshKey` → effect → `notifyStakingRefresh("tx-state-change")` (semantic mask); approve uses `refreshBalances()` directly. |
| **Safest D3b1** | Pure read **executors** (no hooks/refs) or **Tron-only** passive read hook with explicit ref bag from composer — not orchestrator/reset bundle. |
| **Impossible without co-move** | Orchestrator session, `vaultBalanceResetKey`, `poolSnapshotContinuityKey`, EVM orchestrator effect, Tron interval effect, `refreshKey` effect as isolated units. |

---

## A. Refresh topology graph

```mermaid
flowchart TB
  subgraph triggers [Refresh triggers]
    RB[refreshBalances]
    RK[refreshKey effect]
    EXT[notifyStakingRefresh external]
    VIS[visibility / pageshow]
    WS[WS block signal via orchestrator]
    T45[Tron 45s interval]
  end

  subgraph evm [EVM path]
    NS[notifyStakingRefresh → pendingMask]
    ORCH[stakingRefreshOrchestrator.tick]
    FAST[executeStakingFastRead]
    SLOW[executeStakingSlowRead]
    OC[onCommit → balanceSnapshotRef + setState]
  end

  subgraph tron [Tron passive path]
    TREF[tronPassiveRefetchRef.current]
    RPB[refetchTronPassiveBalances]
    TRPC[fetchTronPassiveReadBalances]
    TCOM[direct setState + balanceSnapshotRef]
  end

  RB --> NS
  RB --> TREF
  RK --> NS
  EXT --> NS
  VIS --> TREF
  VIS --> NS
  T45 --> RPB
  WS --> NS

  NS --> ORCH
  ORCH --> FAST
  ORCH --> SLOW
  FAST --> OC
  SLOW --> OC

  TREF --> RPB
  RPB --> TRPC
  TRPC --> TCOM
```

### Trigger inventory

| Source | Mechanism | Semantic / path |
| ------ | --------- | ----------------- |
| `refreshBalances()` | `notifyStakingRefresh("wallet-state-change")` + `tronPassiveRefetchRef.current?.()` | Wallet + Tron parallel |
| `refreshKey` effect (`refreshKey > 0`) | `notifyStakingRefresh("tx-state-change")` | EVM orchestrator only (Tron orchestrator stopped) |
| `deposit` / `withdraw` (receipt) | `setRefreshKey(k => k + 1)` | Indirect tx semantic |
| `approveStakeAmount` | `refreshBalances()` after allowance | Direct wallet semantic + Tron refetch |
| `StakingAppBalance` | `notifyStakingRefresh("profit-boundary")` | Maps to `periodic-sync` |
| Orchestrator start | `pendingMask \|= network \| wallet` | Initial burst |
| Orchestrator visibility | `notifyStakingRefreshSemantic("visibility-state-change")` | Module listener |
| Diagnostics chaos | `notifyStakingRefresh("chaos-simulated-wallet-reconnect")` | DEV |
| Tron effect | `setInterval(45_000)` + `visibilitychange` + `pageshow` | No orchestrator |

### EVM orchestrator lifecycle (vault effect ~L1098)

**Start when all true:** `!isTronPassiveRuntime`, connected, `address`, `tokenAddress`, `isEthereumNetwork`, `!isWrongNetwork`, `assetResolved`, `chainId === expectedChainId`.

**Stop when:** Tron runtime, gates fail, wrong chain, missing token/wallet, cleanup on dep change.

**Session fields:** `executionIdentity`, `coordinatorSnapshot` (capture at start), `getLatestCoordinatorSnapshot`, `walletAddress`, `tokenAddress`, `isVisible`, `isChainOk`, `getPrevious`, `onCommit`.

**Note:** Orchestrator RPC uses **legacy** `executeStakingFastRead` / `executeStakingSlowRead` **without** `stakingReadOptions` — implicit env deployment (see orchestrator header). Vault direct reads use `stakingReadOptions: { runtime: stakingRuntime }`.

### Tron polling topology (vault effect ~L1198)

| Event | Action |
| ----- | ------ |
| Effect mount (valid owner + token) | `void refetchTronPassiveBalances()` |
| Every 45s | `void refetchTronPassiveBalances()` |
| `visibilitychange` → visible | refetch |
| `pageshow` persisted | refetch |
| Cleanup | `clearInterval`, bump `tronPassiveFetchGenRef`, reset fail streak |
| `requestNetworkSwitch` (Tron, switched) | `setBalancesFetched(false)` + `void refetchTronPassiveBalances()` |
| Tron rehydrate effect | `void refetchTronPassiveBalances()` + shallow history |

---

## B. Read ownership graph

```mermaid
flowchart LR
  subgraph react [React state - vault]
    TA[tokenAddress]
    TD[tokenDecimals / symbol / name]
    WB[walletBalance .. minWithdrawalFeeWei]
    FLAGS[tokenMetaFetched / balancesFetched / assetResolved]
  end

  subgraph refs [Vault refs]
    BSR[balanceSnapshotRef]
    LDB[lastDisplayBalancesRef]
    OBS[observedBalanceRef]
    LMR[loadMetaRunIdRef]
    TFG[tronPassiveFetchGenRef]
  end

  subgraph module [Module singletons]
    ORCH_S[orchestrator session state]
    HIST[stakingTransactionHistoryCache]
    RF_CACHE[stakingReadFactory erc20/vault caches]
  end

  subgraph reads [Read implementations]
    LA[loadAsset effect - vault.asset]
    LM[loadMeta - ERC20 meta / Tron meta]
    ORCH_R[orchestrator fast/slow RPC]
    TRON_R[fetchTronPassiveReadBalances]
  end

  LA --> TA
  LM --> TD
  ORCH_R --> BSR
  ORCH_R --> WB
  TRON_R --> BSR
  TRON_R --> WB
  BSR --> ORCH_S
  LDB --> BSR
```

### Read path by subsystem

| Subsystem | Owner | Inputs | Outputs |
| --------- | ----- | ------ | ------- |
| **Asset resolution** | `loadAsset` effect | `chainId`, `stakingReadJsonRpc`, coordinator gates | `tokenAddress`, `assetResolved` |
| **Token meta** | `loadMeta` callback + effect | `tokenAddress`, Tron env, EVM chain match | `tokenDecimals`, symbol, name, `tokenMetaFetched`, `tokenMetaError` |
| **EVM balances** | Orchestrator → `onCommit` | `address`, `tokenAddress` | React balance state + refs |
| **Tron balances** | `refetchTronPassiveBalances` | `runtimeWalletAddress`, Tron token env | Same ref/state shape |
| **Direct vault reads (tx)** | `deposit`/`withdraw`/`ensureAllowance` | `signer`, env `STAKING_VAULT_ADDRESS` | Not via refresh pipeline |
| **History** | `refreshStakingHistory` | `stakingOwnerAddress`, deployment | Rows/totals + module cache |

### Flag semantics (`vaultDataReady`)

Requires: `assetResolved`, `tokenAddress`, `tokenMetaFetched`, `balancesFetched`, plus family-specific connect/network rules (`selectVaultDataReady`).

---

## C. Effect ordering dependency graph

**Registration order in `useStakingVaultState` (approximate line order):**

| # | Line | Effect / hook | Hard dependency |
| - | ---- | ------------- | --------------- |
| 1 | 376 | Abort history on `isWrongNetwork` | — |
| 2 | 443 | `isMountedRef` | — |
| 3 | — | `useStakingVaultDiagnosticsMount()` | After mount ref |
| 4 | 453 | Sync `numericChainIdRef` | Planes `chainId` |
| 5 | 458 | Sync `tokenMetaErrorRef` | — |
| 6 | 484 | Reset `assetResolved` on chain (EVM) | `numericChainId` |
| 7 | 489 | `loadAsset` | Before meta needs `tokenAddress` (EVM) |
| 8 | 842 | Wire `tronPassiveRefetchRef` | **After** `refreshBalances` defined (L479) |
| 9 | 950 | Cleanup switch verify interval | — |
| 10 | 975 | **`vaultBalanceResetKey` reset** | Zeros refs + flags |
| 11 | 1011 | **`poolSnapshotContinuityKey` seed** | After reset key family |
| 12 | 1037 | **EVM chain reconciliation** | **Must run before `loadMeta`** (comment L1035) |
| 13 | 1088 | `void loadMeta()` | Depends on chain effect clearing WRONG_NETWORK |
| 14 | 1092 | `refreshKey` → notify | After orchestrator may be running |
| 15 | 1098 | **EVM orchestrator start/stop** | After `assetResolved`, token, chain |
| 16 | 1198 | **Tron interval + visibility** | Mutually exclusive with orchestrator |
| 17 | 1453 | Tron network rehydrate | Calls refetch + shallow history |
| 18 | 1488 | History stall watchdog | — |
| 19 | 1531 | History abort on key change | — |
| 20 | 1539 | History cache hydrate | — |
| 21 | 1572 | Auto-fetch history when `vaultDataReady` | After reads ready |

```mermaid
flowchart TD
  RESET[vaultBalanceResetKey effect]
  POOL[poolSnapshotContinuityKey effect]
  CHAIN[EVM chain reconciliation]
  META[loadMeta effect]
  ORCH[EVM orchestrator effect]
  TRON[Tron interval effect]

  RESET --> POOL
  CHAIN --> META
  META --> ORCH
  META --> TRON
```

**Blocked reorderings:**

- Moving `loadMeta` before chain reconciliation → wrong-network meta flapping / premature RPC.
- Moving `tronPassiveRefetchRef` wiring before `refreshBalances` → Rules of Hooks violation (callback used before assignment).
- Running EVM orchestrator + Tron interval together → double refresh / wrong RPC family.

---

## D. Ref mutation graph

| Ref | Writers | Readers |
| --- | ------- | ------- |
| `balanceSnapshotRef` | Reset effect; continuity seed; orchestrator `onCommit`; Tron commit; Tron invalid-owner zero | `getPrevious()` orchestrator; share-change detection |
| `lastDisplayBalancesRef` | Same writers as snapshot (mirror on commit) | Continuity effect seeds `balanceSnapshotRef` |
| `observedBalanceRef` | Tron/orchestrator when `sharesChanged` | `stakingBalanceAnchorMs` memo |
| `loadMetaRunIdRef` | Increment at `loadMeta` start | `stillCurrent()` guard |
| `tronPassiveFetchGenRef` | Increment start + cleanup | Stale Tron balance guard |
| `numericChainIdRef` | Chain sync effect | Switch verify interval |
| `tokenMetaErrorRef` | Meta error state sync | Switch timeout path |
| `tronPassiveRefetchRef` | Tron wiring effect | `refreshBalances` |
| `stakingHistoryFetchGenRef` | History fetch + abort + stall | Stale history guard |
| `stakingHistoryAbortRef` | History fetch / abort effects | Abort in-flight |
| `stakingHistoryInFlightRef` | History fetch | `skipIfInFlight` |
| `historyLoadWallStartedMsRef` | History fetch | Stall watchdog |
| `tronPassiveReadFailStreakRef` | Tron catch | Telemetry |
| `isMountedRef` | Mount effect | All async commits |
| `wrongNetworkToastShown` | Chain / switch paths | Deduped toast |
| `lastRpcMetaErrToastAtRef` | Tron/EVM meta errors | Toast cooldown |
| `switchVerifyIntervalRef` | Auto-switch | Poll cleanup |
| `isSwitchingRef` | Switch handlers | Reentrancy guard |
| `refreshStakingHistoryRef` | Always latest callback | Stall + Tron rehydrate |

**Orchestrator module refs (not in vault):** `session`, `invalidationGen`, `abortCtrl`, `inFlight`, `pendingMask`, `lastCommitPerf`, `lastFastPerf`, `lastSlowPerf`.

---

## E. Async invalidation graph

```mermaid
sequenceDiagram
  participant V as Vault async
  participant O as Orchestrator tick
  participant C as Coordinator latest ref

  Note over V: loadMeta / loadAsset / Tron refetch
  V->>V: capture coordinatorAtStart
  V->>C: read latest at commit boundary
  V->>V: canRuntimeOperationCommitWithDevTrace

  Note over O: tick in-flight
  O->>O: myGen = ++invalidationGen
  O->>O: fast read
  alt myGen !== invalidationGen
    O-->>O: return stale
  end
  O->>C: gateMid before slow
  O->>O: slow read
  O->>C: canRuntimeOperationCommit(captured, latest)
  O->>V: onCommit
```

### Invalidation patterns

| Pattern | Location | Invalidate condition |
| ------- | -------- | -------------------- |
| `loadMetaRunIdRef` | `loadMeta` | New `loadMeta` invocation or unmount |
| `tronPassiveFetchGenRef` | Tron balances | New fetch or effect cleanup |
| `stakingHistoryFetchGenRef` | History | New fetch, key change, stall recovery |
| `cancelled` flag | `loadAsset` effect | Effect cleanup |
| `invalidationGen` | Orchestrator | `stopStakingRefreshOrchestrator`, new tick superseded |
| `abortCtrl` | Orchestrator | Stop or new tick |
| `stakingHistoryAbortRef` | History | New fetch, key change, wrong network |

**Coordinator vs run-id:** Run-id prevents stale **invocation** clobber; coordinator gate prevents stale **runtime epoch** commit. Both required — do not merge.

---

## F. Safe extraction boundaries

| Boundary | Safe? | Rationale |
| -------- | ----- | --------- |
| Pure RPC helpers wrapping `fetchTronPassive*` / ERC20 meta `Promise.all` | **Yes** | No state; pass inputs + signal |
| Types: `BalanceSnapshot`, `VaultReadRefs` bag | **Yes** | Documentation / typing only |
| `loadMeta` body as `async function` in separate **file** called from vault | **Medium** | Must preserve deps, gates, `stillCurrent` |
| Tron `refetchTronPassiveBalances` in hook with **refs passed in** | **Medium** | Isolated from orchestrator; still needs transition |
| History subsystem | **Medium** | Separate API; cache singleton + many effects |
| EVM orchestrator registration effect | **No** (alone) | Tied to `balanceSnapshotRef` + transition capture |
| `vaultBalanceResetKey` + continuity effects | **No** (alone) | Shared ref pipeline |
| `refreshBalances` + `tronPassiveRefetchRef` | **No** (split) | Hook order contract |
| `refreshKey` effect | **No** (alone) | Couples tx plane to global orchestrator |

---

## G. Unsafe split zones

1. **F+C ref pipeline** — Orchestrator `getPrevious` vs reset zeroing vs continuity seed on same render generation.
2. **B→C effect order** — Chain reconciliation before `loadMeta` (L1035 comment).
3. **`refreshBalances` / `tronPassiveRefetchRef` order** — L337–338 comment; callback defined L479, ref wired L842.
4. **EVM vs Tron refresh mutex** — Effects L1098 and L1198 must remain mutually exclusive per `isTronPassiveRuntime`.
5. **Coordinator capture** — `orchestratorCoordinatorAtStart` closed over in `onCommit`; changing to single snapshot breaks swap safety.
6. **Dual address model** — `stakingOwnerAddress` (history) vs `address`/`executionAddress` (EVM reads/affiliate).
7. **Orchestrator legacy reads vs vault `stakingReadOptions`** — Extraction must not accidentally thread runtime into orchestrator without explicit product decision.
8. **Global `stakingTransactionHistoryCache`** — Second provider instance cross-contamination in tests.

---

## H. Must remain co-located (minimum bundles)

Until a ref-bag composer pattern exists, these **must ship together** in one hook module or one composed hook with shared refs:

1. `balanceSnapshotRef` + `lastDisplayBalancesRef` + `observedBalanceRef`
2. `vaultBalanceResetKey` effect + `poolSnapshotContinuityKey` effect
3. EVM orchestrator effect (L1098) + `onCommit` closure
4. Tron interval effect (L1198) + `refetchTronPassiveBalances` + `tronPassiveRefetchRef` wiring effect
5. `refreshBalances` + `tronPassiveRefetchRef` assignment (order fixed)
6. EVM chain reconciliation effect (L1037) + `loadMeta` effect (L1088)
7. `refreshKey` state + `refreshKey` effect (L1092) + tx `setRefreshKey` call sites
8. `transition` subscription + all `canRuntimeOperationCommitWithDevTrace` call sites in this bundle

**Composer (thin `useStakingVault`) must always own:**

- `useRuntimeTransitionSnapshot()`
- Sub-hook wiring order matching table in §C
- `withDeprecatedVaultBridgeDevInstrumentation` return wrapper

---

## I. Recommended extraction order (post-D3b0)

| Phase | Target | Risk | Notes |
| ----- | ------ | ---- | ----- |
| **D3b1** | Pure read executors + types (`src/staking/reads/`) | Low | Move `loadMeta`/`loadAsset`/`refetchTron` **bodies** only; vault keeps effects |
| **D3b2** | `useStakingVaultTokenReads` hook | Medium | `loadAsset`, `loadMeta`, token state; receives `transition` + ref bag |
| **D3b3** | `useStakingVaultBalanceRefresh` hook | High | Orchestrator + Tron interval + reset + continuity + `refreshBalances`/`refreshKey` |
| **D3c** | `useStakingVaultHistory` | Medium | Already bounded in anatomy |
| **D3d** | `useStakingVaultTx` | Medium | Inject refresh callbacks |

Do **not** start with orchestrator extraction (D3b3 before D3b1–b2).

---

## J. Potential future `src/staking/reads/` package structure

```
src/staking/reads/
  index.ts
  types.ts                    # BalanceSnapshot, TokenMetaResult, ReadRefBag (types only)
  stakingVaultChainReads.ts   # normalizeChainId helpers (or re-export runtime/)
  evm/
    loadEvmPoolAsset.ts       # vault.asset() + coordinator gate wrapper
    loadEvmTokenMeta.ts       # decimals/symbol/name
    commitEvmOrchestratorBalances.ts  # onCommit field mapping (pure)
  tron/
    loadTronTokenMeta.ts
    fetchTronPassiveBalances.ts
  hooks/                      # later phases only
    useStakingVaultTokenReads.ts
    useStakingVaultBalanceRefresh.ts
```

**Orchestrator stays** at `src/lib/staking/stakingRefreshOrchestrator.ts` (production-frozen Phase 42) until an explicit migration phase threads `stakingReadOptions`.

---

## Audit target deep-dives

### 1. `loadMeta` lifecycle

| Stage | Behavior |
| ----- | -------- |
| Trigger | `useEffect(() => void loadMeta(), [loadMeta])` — runs on every `loadMeta` identity change |
| Tron branch | `fetchTronPassiveTokenMeta`; sets decimals/symbol/name; `tokenMetaFetched` in `finally` with gates |
| EVM early exit | Wrong chain → `WRONG_NETWORK` + `tokenMetaFetched=true` without RPC |
| EVM RPC | Requires `tokenAddress`, correct chain, `stakingReadJsonRpc`; parallel `decimals/symbol/name` |
| Stale guard | `loadMetaRunIdRef` + `stillCurrent()` + coordinator commit trace |
| Related | Chain effect clears `WRONG_NETWORK` and calls `void loadMeta()` when back on expected chain |

### 2. `refreshBalances` topology

```ts
refreshBalances = () => {
  notifyStakingRefresh("wallet-state-change")  // → orchestrator pendingMask (EVM)
  tronPassiveRefetchRef.current?.()            // → Tron RPC path
}
```

- **Approve path** uses this (not `refreshKey`).
- **Does not** bump React state directly.

### 3. `stakingRefreshOrchestrator` interactions

| API | Role |
| --- | ---- |
| `startStakingRefreshOrchestrator(session)` | Vault effect registers session |
| `stopStakingRefreshOrchestrator()` | Cleanup; Tron effect calls on mount |
| `notifyStakingRefresh(raw)` | Maps string → semantic bit mask |
| `tick()` | Single-flight fast/slow reads + commit gates |
| `acquireStakingWsBlockSignal()` | WS hint on session start (does not drive timer directly) |

**Commit gate sequence inside `tick()`:**

1. `canRuntimeOperationRefresh(latest)` — tick entry
2. `inFlight` / `ABSOLUTE_MIN_MS` spacing
3. Fast read (if `needFast`)
4. `invalidationGen` check
5. `canRuntimeOperationRefresh(gateMid)` — before slow read
6. Slow read (if `needSlow`)
7. `invalidationGen` check
8. `canRuntimeOperationCommit(captured, latest)` — before `onCommit`
9. Vault `onCommit` → `canRuntimeOperationCommitWithDevTrace` again

### 4. `balanceSnapshotRef` ownership graph

See §B and §D. **Authoritative merge target** for orchestrator; **display seed** via `lastDisplayBalancesRef` on pool token change.

### 5. `poolSnapshotContinuityKey` lifecycle

- **Key:** `tokenAddress|owner` (Tron: `runtimeWalletAddress`; EVM: `address|connected|ethereum|wrongNetwork`)
- **Effect:** When token + valid owner, copy `lastDisplayBalancesRef` → `balanceSnapshotRef` (stale-while-refresh)
- **Does not** reset React balance state — only ref seed
- Runs after `vaultBalanceResetKey` may have zeroed both refs

### 6. `vaultBalanceResetKey` lifecycle

- **Key:** Tron: `runtimeKey|deploymentId|runtimeWalletAddress|identityOrigin`; EVM: `runtimeKey|address|chain|connected|ethereum`
- **Effect:** `tokenMetaFetched=false`, `balancesFetched=false`, clear decimals/error, zero both balance refs
- **Triggers downstream:** `loadMeta` deps, orchestrator stop/start, `vaultDataReady` false

### 7. Tron polling interval topology

- **45_000 ms** fixed interval (not orchestrator adaptive timer)
- Visibility/pageshow mirror orchestrator semantics but call `refetchTronPassiveBalances` directly
- Cleanup bumps `tronPassiveFetchGenRef` to invalidate in-flight Tron reads
- **No** `notifyStakingRefresh` on Tron interval (by design)

### 8. EVM refresh orchestration topology

- Adaptive `scheduleNext()` with `FAST_FLOOR_MS` (45s), `SLOW_FLOOR_MS` (420s), hidden heartbeat
- Semantic coalescing via `pendingMask`
- Tx semantic forces fast path and may force slow when `sequenceAllowsSlowRpc`
- Shares commit version counter inside module (not exposed to vault)

### 9. Runtime transition interaction points

| Call site | Gate |
| --------- | ---- |
| `loadAsset` | `canRuntimeOperationCommitWithDevTrace` after RPC |
| `loadMeta` (tron/evm paths) | after reads, catch, finally |
| `refetchTronPassiveBalances` | before state write |
| `onCommit` | `canRuntimeOperationCommitWithDevTrace` |
| Orchestrator internal | `canRuntimeOperationRefresh` / `canRuntimeOperationCommit` |

**Inputs:** `transition.coordinatorSnapshot`, `transition.latestCoordinatorSnapshotRef`, `transition.executionIdentity` (orchestrator session).

### 10. Commit gate sequencing

See §3 orchestrator + vault `onCommit`. **Sequence stages** (`transition.sequenceStage`):

- Balance refresh blocked until `resume_requested` (`sequenceStageAllowsBalanceRefresh`)
- Async commits blocked in `begin_requested`, `refresh_paused`, `runtime_swapped`

### 11. History invalidation dependencies

| Dependency | Invalidation |
| ---------- | ------------- |
| `stakingHistoryKey` change | Abort, bump gen, reset in-flight |
| `stakingOwnerAddress` / key | Cache hydrate effect |
| `isWrongNetwork` | Abort controller |
| `vaultDataReady` | Auto full fetch |
| Post-tx | Direct `refreshStakingHistory()` (not `refreshKey`) |
| Tron rehydrate | Shallow history if network ok |
| Stall 90s | Bump gen, abort, re-fetch deep |

**Independent from balance orchestrator** except shared `vaultDataReady` / `tokenDecimals`.

### 12. `refreshKey` → tx-state-change chain

```
deposit/withdraw success
  → setRefreshKey(n+1)
  → useEffect [refreshKey]
  → if refreshKey > 0: notifyStakingRefresh("tx-state-change")
  → orchestrator pendingMask |= tx-state-change
  → tick may force fast+slow reads
```

**Tron:** `refreshKey` effect still runs but orchestrator is stopped — **tx balance refresh on Tron relies on** manual `refreshStakingHistory` + user calling `refreshBalances` or waiting for 45s interval. *Product note for manual QA.*

### 13. All balance-related refs

Listed in §D: `balanceSnapshotRef`, `lastDisplayBalancesRef`, `observedBalanceRef`, plus orchestrator `getPrevious` indirection.

### 14. Async cancellation / runId patterns

| Mechanism | Used in |
| --------- | ------- |
| `loadMetaRunIdRef` | `loadMeta` |
| `tronPassiveFetchGenRef` | Tron balances |
| `stakingHistoryFetchGenRef` | History |
| `cancelled` boolean | `loadAsset` effect only |
| `invalidationGen` + `AbortController` | Orchestrator module |
| `stakingHistoryAbortRef` | History fetch |
| `isMountedRef` | All vault commits |

---

## Impossible extractions (without behavior change)

1. **`refreshBalances` below `tronPassiveRefetchRef` effect** — Rules of Hooks.
2. **Orchestrator registration without `balanceSnapshotRef` ownership** — `getPrevious` / `onCommit` contract.
3. **`refreshKey` effect separated from tx methods** — Loses post-tx semantic unless `notifyStakingRefresh("tx-state-change")` called directly (behavior change).
4. **`loadMeta` before chain reconciliation effect** — Documented race fix.
5. **Orchestrator on Tron or Tron 45s interval on EVM** — Family mutex.
6. **Single coordinator snapshot for start+latest** — Breaks swap-generation safety.
7. **Move `vaultBalanceResetKey` without continuity + balance effects** — Ref desync.
8. **Thread `stakingReadOptions` into orchestrator** — Not a pure extraction; changes RPC routing (Phase 19 note).

---

## Safest first read extraction (D3b1 recommendation)

**Target: `src/staking/reads/` pure functions only (D3b1)**

Extract **stateless** helpers:

- EVM token meta read (`decimals`, `symbol`, `name`) given `read` + `tokenAddress`
- EVM `loadAsset` vault.asset read
- Tron meta/balance wrappers around existing `fetchTronPassive*` (pass `deployment`, addresses)

Vault retains: all `useEffect`s, refs, `useState`, coordinator captures, `stillCurrent`, toast side effects.

**Why safest:** Zero hook order change; zero ref ownership move; validates import boundaries before any `useStakingVaultTokenReads` hook.

**Do not as D3b1:** `useStakingVaultBalanceRefresh`, orchestrator move, or reset/continuity effects.

---

## Verification (D3b0)

| Check | Status |
| ----- | ------ |
| Code behavior unchanged | Yes — documentation only |
| `pnpm typecheck` | Run after doc write |
| `pnpm build` | Run after doc write |

---

*Generated for Architecture Consolidation Phase D3b0. No production code modified.*
