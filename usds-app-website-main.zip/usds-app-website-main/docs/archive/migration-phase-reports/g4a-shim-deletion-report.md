# G4a shim deletion report

Destructive cleanup of obsolete compatibility shims after G3/G3.5 canonical import migration. **No runtime behavior changes. No public vault bridge removal.**

Verification: `pnpm typecheck` ✅ · `pnpm build` ✅

---

## 1. Summary

| Metric | Value |
|--------|------:|
| **Files deleted** | **49** |
| **Remaining real legacy `from` imports** | **0** |
| **Surviving re-export / compatibility shims** | **6** |
| **Surviving bridge surfaces (intentional)** | **2** (vault public + runtime planes) |
| **Blocked for G4b** | Tron implementation move + bridges |
| **Blocked for G4c** | Public vault bridge field removal |

---

## 2. Deleted files (49)

### `src/lib/staking/*.ts` (37)

All `@deprecated` re-export shims removed, including G3.5:

- `profitManagerStatusSingleton.ts`, `originalTelegramUrl.ts`
- UI: `stakingToast`, `stakingInputStyles`, `stakingAmountSliderVisual`
- Notifications: `stakingPassiveNotificationPolicy`, `receiptErrorSonnerPolicy`, `receiptSuccessSonnerPolicy`
- CTA: `stakingCtaEllipsisPolicy`, `stakingCtaDiagnostics`, `stakingCtaInlineReasonPolicy`, `stakingFormInlineReasonResolver`, `stakingSnapshotCtaPhase`
- Refresh: `stakingRefreshOrchestrator`, `stakingRefreshMetrics`
- Tx: `stakingFeeCanonical`, `stakingTxOnChainRecovery`, `stakingTxSessionPersistence`
- Execution: `buildNetworkFeePresentation`, `ethUsdPriceCache`, `stakingReadFactory`, `stakingReadProviders`, `stakingTxExplorerFromDeployment`
- Identity: `stakingRuntimeWalletIdentity`, `stakingRuntimeWalletIdentityBridge`, `stakingNavbarVisualHold`, `stakingPassiveRuntimeUx`
- Orchestration: `stakingMobileResumeCoordinator`
- Diagnostics: `stakingTxIntegrityDev`, `stakingLifecycleInstrumentation`, `stakingRuntimeSoak*`, `stakingRuntimeExecutionPlaneTelemetry`, `stakingVaultDeprecated*`, `stakingVaultSemanticAssertionsDev`

### Hook / service / lib root shims (6)

- `src/hooks/useUnifiedWalletOrchestration.ts`
- `src/hooks/useStakingGasToastDedupe.ts`
- `src/services/gasEstimator.ts`
- `src/lib/stakingTxMobileLifecycleDebug.ts`
- `src/lib/stakingEtherscanHistory.ts`
- `src/lib/wallet/openUnifiedWallet.ts`

### Core orchestration shims (5)

- `src/staking/core/runtimeTransitionCoordinator.ts`
- `src/staking/core/runtimeTransitionSequence.ts`
- `src/staking/core/runtimeSwapEngine.ts`
- `src/staking/core/runtimeSwapPolicy.ts`
- `src/staking/core/createTronReceiptResolver.ts`

### Dev orchestration shim (1)

- `src/staking/dev/runtimeLifecycleAssertions.ts`  
  → Dev imports updated to `@/staking/orchestration/runtimeLifecycleAssertions` in:
  - `runtimeReadinessGate.ts`
  - `runtimeTortureSuite.ts`
  - `runtimeChaosSuite.ts`

### Left in `src/lib/staking/` (docs only)

- `ETH_USD_FEED_STAKING.md`
- `STAKING_MOBILE_LIFECYCLE.md`
- `REALTIME_STAKING_ARCHITECTURE.md`

---

## 3. Grep evidence (post-deletion)

### Required patterns — non-shim `from` imports

| Pattern | Result |
|---------|--------|
| `@/lib/staking/` | **0** (only diagnostics message string in `stakingCanonicalBoundaryDev.ts`) |
| `@/hooks/useUnifiedWalletOrchestration` | **0** |
| `@/hooks/useStakingGasToastDedupe` | **0** |
| `@/services/gasEstimator` | **0** |
| `@/lib/stakingTxMobileLifecycleDebug` | **0** |
| `@/lib/stakingEtherscanHistory` | **0** |
| `@/lib/wallet/openUnifiedWallet` | **0** |
| `@/staking/core/runtimeTransitionCoordinator` | **0** |
| `@/staking/core/runtimeTransitionSequence` | **0** |
| `@/staking/core/runtimeSwapEngine` | **0** |
| `@/staking/core/runtimeSwapPolicy` | **0** |

### `@/lib/tron/` — `from` imports

Only canonical **bridges** (G4b):

- `src/staking/identity/tron/tronWalletIdentity.ts`
- `src/staking/history/tronTransactionHistory.ts`

No app/component/hook consumers import `@/lib/tron/*` directly.

---

## 4. Surviving shims (6)

| File | Canonical target | Phase |
|------|------------------|-------|
| `src/lib/tron/tronPassiveReads.ts` | `@/staking/execution` | G4b |
| `src/lib/tron/resolveUnifiedTronIdentity.ts` | `@/staking/identity/tron/resolveUnifiedTronIdentity` | G4b |
| `src/staking/identity/tron/tronWalletIdentity.ts` | `lib/tron` (bridge) | G4b |
| `src/staking/history/tronTransactionHistory.ts` | `lib/tron` (bridge) | G4b |
| `src/staking/core/runtimeCoreLayerBoundaryDev.ts` | `@/staking/diagnostics` | G4b optional |
| `src/staking/vault/composer/useStakingVaultEvmNetworkGlue.ts` | `@/staking/runtime/network` | G4d (delegates; not pure re-export) |

**Tron implementations** (not shims — delete only after move):

- `src/lib/tron/tronWalletIdentity.ts`
- `src/lib/tron/tronTransactionHistory.ts`

---

## 5. Remaining bridge files & compatibility exports

### Public vault bridge (`useStakingVault()` return)

Still assembled in `stakingVaultPublicAssembly.ts` and wrapped by `withDeprecatedVaultBridgeDevInstrumentation`:

| Field | Status |
|-------|--------|
| `address` | Exported — use `executionAddress` |
| `isConnected` | Exported — use `executionConnected` / `runtimeWallet` |
| `chainId` | Exported — use `executionChainId` |
| `activeRuntimeSelection` | Exported — use `useActiveRuntimeSelection()` |

DEV: `stakingVaultDeprecatedFieldDev.ts`, `stakingVaultDeprecatedBridgeDev.ts`

### Runtime planes deprecated aliases

`useStakingVaultRuntimePlanes.ts` still exports `isConnected`, `address`, `chainId` with `@deprecated` JSDoc.  
DEV: `withDeprecatedRuntimePlanesDevInstrumentation`

### Not removed (per G4a scope)

- Orchestration semantics (`runtimeTransitionController` in **core** — real implementation, not a shim)
- Tx persistence / recovery modules
- Diagnostics behavior
- AppKit orchestration (`useUnifiedWalletOrchestration` in `@/staking/orchestration`)

---

## 6. Blocked deletions

| Item | Blocker | Next phase |
|------|---------|------------|
| Tron bridges + `lib/tron/*` shims | Implementation still in `lib/tron` | **G4b** |
| `useStakingVaultEvmNetworkGlue` | Composer entry; user scope excluded runtime-plane glue | **G4d** |
| Public vault bridge fields | Explicit G4a exclusion | **G4c** |
| `runtimeCoreLayerBoundaryDev` | Low-traffic diagnostics shim | **G4b** optional |

---

## 7. G4c blast radius estimate

Removing `address`, `isConnected`, `chainId`, `activeRuntimeSelection` from the public vault object:

| Area | Risk |
|------|------|
| In-repo staking UI | **Low** — already on `execution*` / `runtimeWallet*` / context hook |
| External integrators | **High** — any consumer of `useStakingVault()` deprecated fields |
| Types / topology tests | **Medium** — `stakingVaultPublicTopology.ts`, DEV assertions |
| Bundle | **Neutral** — small surface removal |

Recommended: semver note + grep external repos before G4c.

---

## 8. G4 deletion candidates (remaining)

### G4b — Tron (4 shims + 2 impl)

1. Move `lib/tron/tronWalletIdentity.ts` → `staking/identity/tron/`
2. Move `lib/tron/tronTransactionHistory.ts` → `staking/history/`
3. Delete bridges + `lib/tron/tronPassiveReads.ts` + `lib/tron/resolveUnifiedTronIdentity.ts`

### G4c — Public bridge removal

1. Remove deprecated fields from `assembleStakingVaultPublicValue`
2. Update `stakingVaultPublicTopology.ts` / types
3. Remove `withDeprecatedVaultBridgeDevInstrumentation` usage

### G4d — Composer / runtime cleanup

1. Route refresh plane directly to `useStakingVaultNetworkGlue`
2. Delete `useStakingVaultEvmNetworkGlue.ts`
3. Remove runtime planes deprecated alias exports (optional, separate from vault bridge)

---

## 9. Manual QA checklist

1. `/staking/app` loads  
2. Navbar wallet  
3. EVM connect  
4. Tron passive runtime  
5. Runtime swap  
6. Wrong network  
7. Tx modal  
8. Deposit/withdraw  
9. History  
10. Refresh orchestration  
11. Profit manager polling  
12. Telegram escalation  
13. Soak monitor  

---

## 10. Next recommended phase

**G4b — Tron implementation relocation** (move `lib/tron` into `staking/`, delete 4 remaining tron shims/bridges).

Then **G4c — public vault bridge removal** after external compatibility check.

---

*Generated: Phase G4a — 49 shim files deleted, 0 legacy consumer imports remaining.*
