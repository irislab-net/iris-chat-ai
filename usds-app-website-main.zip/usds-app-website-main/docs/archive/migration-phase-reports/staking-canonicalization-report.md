# Staking canonicalization report (Phase G2)

Generated after canonical path consolidation. **Shims and public bridges were not deleted** — implementations moved under `@/staking/*`; `lib/staking/*` re-exports with DEV warnings.

Verification: `pnpm typecheck` ✅ · `pnpm build` ✅

---

## 1. Grep evidence (`src/staking/**`)

| Pattern | Result |
|---------|--------|
| `@/lib/staking/` | **0** imports |
| Deprecated `@/staking/core/*` shims (`runtimeTransitionCoordinator`, `runtimeSwapPolicy`, `runtimeSwapEngine`, `runtimeTransitionSequence`, `createTronReceiptResolver`) | **0** imports |
| `useStakingVaultEvmNetworkGlue` | **2** — `vault/composer` shim + barrel re-export only |

Legitimate `@/staking/core/*` imports (types, registry, `runtimeOperationContext`, `persistenceTypes`, etc.) remain inside the core package and cross-plane modules — **expected**.

---

## 2. Canonical ownership table

| Concern | Canonical home | Barrel |
|---------|----------------|--------|
| Toast / Sonner adapters | `staking/ui/stakingToast.ts` | `@/staking/ui` |
| Input / slider styles | `staking/ui/stakingInputStyles.ts`, `stakingAmountSliderVisual.ts` | `@/staking/ui` |
| Passive notification policy | `staking/notifications/stakingPassiveNotificationPolicy.ts` | `@/staking/notifications` |
| Receipt toast policies | `staking/notifications/receipt*SonnerPolicy.ts` | `@/staking/notifications` |
| Balance refresh orchestrator | `staking/refresh/stakingRefreshOrchestrator.ts` | `@/staking/refresh` |
| Refresh metrics | `staking/refresh/stakingRefreshMetrics.ts` | `@/staking/refresh` |
| Network fee presentation | `staking/execution/buildNetworkFeePresentation.ts` | `@/staking/execution` |
| Fee canonical (tx modal) | `staking/tx/stakingFeeCanonical.ts` | `@/staking/tx` |
| CTA ellipsis / phase / inline | `staking/cta/*` | `@/staking/cta` |
| Tx integrity DEV | `staking/diagnostics/stakingTxIntegrityDev.ts` | `@/staking/diagnostics` |
| Mobile resume store | `staking/orchestration/stakingMobileResumeCoordinator.ts` | `@/staking/orchestration` |
| Network glue | `staking/runtime/network/*` | `@/staking/runtime/network` |
| Runtime planes | `staking/runtime/useStakingVaultRuntimePlanes.ts` | `@/staking/runtime` |
| Transition / swap / refresh gates | `staking/orchestration/*` | `@/staking/orchestration` |
| Contract reads / RPC | `staking/execution/*` | `@/staking/execution` |
| Vault composer | `staking/vault/composer/*` | `@/staking/vault/composer` |
| Deployment registry / selection | `staking/core/*` | (core is authoritative for registry) |

---

## 3. New canonical packages (G2)

```
src/staking/ui/              — toast, input styles, slider visual
src/staking/notifications/   — passive + receipt Sonner policies
src/staking/cta/             — CTA ellipsis, phase, inline resolver, diagnostics
```

Extended barrels:

- `staking/refresh/index.ts` — orchestrator + metrics exports
- `staking/tx/index.ts` — fee canonical
- `staking/execution/index.ts` — network fee presentation
- `staking/orchestration/index.ts` — mobile resume store

---

## 4. Remaining `lib/staking` shims (~29 files)

All marked `@deprecated` and re-export from `@/staking/*`. **Do not delete until Phase G** after app/components migrate.

| Shim category | Canonical target | Still imported from `lib/` by |
|---------------|------------------|--------------------------------|
| Toast / passive / fee / refresh / network fee | ui, notifications, tx, refresh, execution | Staking UI components, hooks, providers |
| CTA / input / slider | cta, ui | Deposit/withdraw forms, CTA hooks |
| Identity / navbar (G1) | identity | Navbar (migrated in G-prep1) |
| Execution reads (G1) | execution | ethUsd hooks, mtx ico |
| Tx session (G1) | tx | TransactionStatusProvider |
| Diagnostics (G1) | diagnostics | Bootstrap, mobile |
| Soak / telemetry | diagnostics | Dev tooling |
| `profitManagerStatusSingleton`, `originalTelegramUrl` | (no staking home yet) | hooks, Telegram provider |

---

## 5. Remaining compatibility exports (public — Phase G)

| Export | Location | Consumers |
|--------|----------|-----------|
| `address`, `isConnected`, `chainId` | vault public assembly + DEV getters | External / zero in-repo UI reads |
| `activeRuntimeSelection` | vault public assembly | Zero in-repo (UI uses `useActiveRuntimeSelection`) |
| `useStakingVaultEvmNetworkGlue` | vault composer shim | Zero callers |
| Runtime planes `isConnected` / `address` / `chainId` | planes return + DEV getters | Internal composer selectors only |

---

## 6. Internal-only legacy imports

**Inside `src/staking/**`:** none from `@/lib/staking/*` or deprecated core orchestration shims.

**Outside `src/staking/**` (still on shims — G3 target):**

- `src/components/pages/staking/*` — toast, CTA, input styles, fee, refresh notify
- `src/hooks/useStakingCtaState.ts`, `useStakingGasEstimate.ts`, etc.
- `src/providers/BootstrapOrchestrationProvider.tsx` — mobile resume
- `src/lib/stakingUiPhase.ts` — CTA inline policy

---

## 7. DEV canonical boundary assertions

`staking/diagnostics/stakingCanonicalBoundaryDev.ts`:

- Documents forbidden patterns (`lib_staking_inside_staking_tree`, deprecated core shims, network glue shim)
- `STAKING_DEPRECATED_CORE_SHIM_PREFIXES` for audit tooling
- Existing `stakingMigrationAssertionsDev` warns on `lib/staking` shim **loads** (app-wide)

---

## 8. Safe-delete candidates (after Phase G app migration)

| Item | Prerequisite |
|------|----------------|
| Entire `src/lib/staking/*.ts` shim files | Zero `@/lib/staking` imports repo-wide |
| `staking/core/runtimeTransitionCoordinator.ts` (+ 5 core shims) | Zero imports (only re-export files left) |
| `useStakingVaultEvmNetworkGlue.ts` | Zero imports |
| Public bridge fields on vault return | DEV grep + integrator notice |
| `withDeprecatedRuntimePlanesDevInstrumentation` | Planes aliases removed |

---

## 9. Blocked-delete candidates

| Item | Why |
|------|-----|
| `staking/core/*` registry/selection | Authoritative deployment SSOT — not a shim |
| `stakingRefreshOrchestrator` body | Production balance truth path — delete only with `lib` shim |
| `stakingToast` | Wide component surface still on `lib/` path |
| Public vault topology keys | API contract until major version |
| `TransactionStatusProvider` fee/session imports | Still via `lib/` from components |

---

## 10. Counts (post-G2)

| Metric | Count |
|--------|-------|
| `lib/staking` shim files (`@deprecated`) | **~29** |
| Public bridge fields on vault return | **3** (`address`, `isConnected`, `chainId`) |
| Public `activeRuntimeSelection` | **1** (export only) |
| `useStakingVaultEvmNetworkGlue` | **1** shim + barrel |
| `@/lib/staking/` inside `src/staking/**` | **0** |

---

## 11. Phase G blast radius (after G2)

| Workstream | Est. files | Risk |
|------------|------------|------|
| Migrate `components/` + `hooks/` off `lib/staking` | ~25–35 | Low (shims preserve behavior) |
| Delete `lib/staking` shims | ~29 | Low after migration |
| Remove public vault bridge fields | 2–3 | Medium (API) |
| Delete core orchestration shim files | 6 | Low |
| Delete network glue shim | 2 | Very low |

**Overall:** Canonical tree is authoritative; Phase G is now **mostly deletion + app import path updates**, not logic moves.

---

## 12. Related docs

- [bridge-removal-readiness-report.md](./bridge-removal-readiness-report.md) — G-prep1 consumer audit
- [staking-network-topology.md](./staking-network-topology.md) — network glue sequencing
