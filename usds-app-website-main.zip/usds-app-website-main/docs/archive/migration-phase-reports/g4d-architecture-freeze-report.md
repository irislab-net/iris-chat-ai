# Phase G4d — architecture freeze report

**Date:** 2026-05-16 (session)  
**Scope:** Retire transitional `useStakingVaultEvmNetworkGlue`, canonicalize network ownership under `staking/runtime/network`, freeze staking plane boundaries (documentation + DEV smoke + ESLint). **No intentional runtime behavior, hook order, or semantic changes.**

---

## 1. Files deleted

| Path |
|------|
| `src/staking/vault/composer/useStakingVaultEvmNetworkGlue.ts` |

## 2. Files touched (summary)

| Area | Change |
|------|--------|
| `src/staking/vault/composer/index.ts` | Removed barrel export of retired shim |
| `src/staking/diagnostics/stakingCanonicalBoundaryDev.ts` | Renamed violation kind to `retired_composer_network_shim` |
| `src/staking/diagnostics/stakingG4dFrozenTopologyDev.ts` | **New** — retired-module catalog for smoke |
| `src/staking/diagnostics/stakingArchitectureSmokeDev.ts` | G4d smoke check for retired shim catalog |
| `src/staking/diagnostics/stakingBoundaryRules.ts` | G4d frozen imports: refresh/history ↔ network; tx ↔ refresh internals; ESLINT pattern split |
| `eslint.config.js` | Mirror: tx + refresh + history + orchestration restricted-import blocks |
| `src/staking/vault/composer/stakingVaultComposerContracts.ts` | Ownership note (canonical network, G4d) |
| `docs/staking-domain-boundaries.md` | Ownership matrix, §1b frozen topology, rules |
| `docs/staking-runtime-contracts.md` | `network_glue` row, §9 G4d freeze |
| `docs/archive/migration-phase-reports/staking-network-topology.md` | Module map: shim removed |

---

## 3. Ownership matrix (authoritative summary)

| Layer | Owns |
|-------|------|
| `staking/runtime` | Runtime planes, identity wiring, chain normalization |
| `staking/runtime/network` | Chain reconciliation, switch UX, ref mirrors, topology DEV markers |
| `staking/refresh` | Balance orchestrator, notify, Tron polling — **not** network reconciliation |
| `staking/history` | History load/merge/cache — **not** switching |
| `staking/tx` | Execution, persistence, recovery — **not** refresh internals |
| `staking/vault/composer` | Wiring + public assembly — **no new network logic** |
| `staking/orchestration` | Runtime transition / swap semantics |

---

## 4. Behavioral note

Refresh plane **already** called `useStakingVaultNetworkGlue` via `buildStakingVaultNetworkGlueInput`; the deleted file was a **delegate-only** shim and had **zero runtime call sites** in `src/`. Removal is **topology / API surface** cleanup only.

---

## 5. Remaining transitional layers

| Item | Status |
|------|--------|
| `runtimeCoreLayerBoundaryDev` (under `staking/core`) | Still noted as cross-layer DEV debt in domain boundaries |
| `lib/stakingDepositApprovalExecution` | Shared with components — product debt, not G4d scope |

---

## 6. Architecture freeze verdict

**Yes — staking plane topology is frozen** for ordinary feature work. Changes that **reorder** composer hooks, **move** reconciliation, or **import** `staking/runtime/network` from `refresh`/`history` are **architecture changes** and require an explicit migration phase.

---

## 7. Future work

Most new staking work can be **feature-only** (UI, copy, deployment config, selectors) **provided** imports respect `stakingBoundaryRules.ts` + `eslint.config.js`. Work that adds **new planes**, **new cross-plane imports**, or **alters refresh orchestration semantics** remains **architecture work**.

---

## 8. Verification

- `pnpm typecheck`
- `pnpm build`
- Manual QA: EVM connect, Tron passive, wrong network, runtime swap, deposit / withdraw / approval, activity + history refresh, `refreshBalances`, reconnect, visibility resume, `window.__STAKING_ARCHITECTURE_SMOKE__?.()`
