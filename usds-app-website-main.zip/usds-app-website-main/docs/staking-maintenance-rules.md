# Staking operational maintenance rules

Steady-state rules for changing staking documentation and runtime-adjacent code after the architecture freeze. This file is policy; runtime contracts live in `staking-runtime-contracts.md`.

## Safe changes

- Copy, labels, and non-semantic UI that do not add data wiring.
- Pure helpers inside the owning package without new cross-layer imports.
- Tests and fixtures that do not alter production hook order.
- DEV-only diagnostics that observe existing behavior.
- Env value updates through `src/config/env.ts` / staking config boundaries.
- Documentation updates that reflect current behavior and keep historical reports archived.

## Requires architecture review

- Hook-order changes in composer, refresh, history, diagnostics, or network registration.
- AppKit adapter/network registration changes.
- Transaction status state machine or persistence changes.
- Runtime swap/orchestrator policy changes.
- Provider registry key strategy or multi-map construction changes.
- CFG6 sentinel, hard-disable, or family hydration semantics.
- New package ownership, new runtime planes, or cross-layer imports.

## Forbidden patterns

- Composer-local network glue.
- Passive effects that open or manage AppKit/WalletConnect as normal reconnect/session ownership.
- Parallel tx status stores outside `TransactionStatusProvider` and `staking/tx` helpers.
- `@/lib/staking/*` or `@/lib/tron/*` imports from canonical `src/staking/*` modules.
- Deprecated public vault bridge keys or runtime plane aliases.
- Unconditional polling additions in refresh/history.
- Wrapper hooks or facades that only hide ownership boundaries.

Existing guarded stale-session recovery paths may perform destructive WalletConnect/AppKit cleanup after known stale-session failures. Treat those as narrow defensive exceptions; do not add new reset/repair paths without architecture review and runtime evidence.

## Rollout and env policy

- Family toggles such as `VITE_ENABLE_ETHEREUM` / `VITE_ENABLE_TRON` filter registry rows and hydration; they are not arbitrary feature flags inside planes.
- Adding a chain family is a major architecture change.
- Runtime telemetry flags must not change product semantics.
- Production env reads stay centralized in `src/config/env.ts`; feature code must not hardcode RPC URLs, addresses, explorers, or deployment ids.

## Debugging workflow

1. Audit relevant code paths and canonical docs before changing behavior.
2. Trace ownership first: AppKit protocol lifecycle, app orchestration, staking runtime planes, tx state machine.
3. Use DEV tools and telemetry before adding logs: `window.__STAKING_ARCHITECTURE_SMOKE__`, `window.__STAKING_ARCH_FREEZE__`, runtime telemetry, and `stakingLifecycleTrace`.
4. Report root cause, blast radius, and smallest fix.
5. Patch minimally and verify with typecheck/lint plus manual wallet return flows when staking tx behavior is touched.

Soak, torture, and chaos flags are DEV-only. Never enable them in production builds for debugging.

## Documentation policy

- Active docs should be small canonical references, not phase reports.
- Historical reports belong in `docs/archive/migration-phase-reports/` and stay preserved for forensics.
- When a report is superseded, archive it and link to the canonical replacement instead of deleting it.
- Large migrations should update the archive index with chronology, milestones, and preserved context.
