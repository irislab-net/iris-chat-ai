# Phase 44 operational rollout anchor

This path is retained because env documentation references it. Active operational guidance has been consolidated into focused canonical docs. Treat this file as a compatibility anchor plus historical rollout summary, not the current operational playbook.

## Canonical replacements

| Topic | Canonical doc |
| --- | --- |
| Deploy/runtime observability and release correlation | `docs/deploy-runtime-assets.md` |
| Runtime telemetry and Sentry events | `docs/staking-sentry-event-taxonomy.md` |
| Runtime lifecycle edge cases and mobile/BFCache QA | `docs/staking-runtime-edgecases.md` |
| Runtime ownership and tx continuity | `docs/staking-runtime-contracts.md` |
| Maintenance and rollout guardrails | `docs/staking-maintenance-rules.md` |

## Preserved Phase 44 rules

- Runtime switch rollout and runtime telemetry rollout are separate gates.
- Public production runtime switching remains a product/security decision, not a default behavior.
- Internal testing must cover real wallet return, BFCache, degraded RPC, wrong network, and persisted tx hydration.
- Rollback should prefer disabling rollout flags rather than changing runtime ownership.
