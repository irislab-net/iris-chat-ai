# Staking architecture boundaries

Canonical ownership and dependency boundaries for staking after the architecture freeze. This document answers **who owns what**. Runtime sequencing lives in `staking-runtime-contracts.md`; stress behavior lives in `staking-runtime-edgecases.md`.

## Active documentation map

| Topic | Canonical doc |
| --- | --- |
| Architecture boundaries | `docs/staking-domain-boundaries.md` |
| Runtime ownership and tx continuity | `docs/staking-runtime-contracts.md` |
| Runtime edge cases and lifecycle behavior | `docs/staking-runtime-edgecases.md` |
| Operational maintenance rules | `docs/staking-maintenance-rules.md` |
| Deploy/runtime observability | `docs/deploy-runtime-assets.md` |
| Sentry/runtime telemetry taxonomy | `docs/staking-sentry-event-taxonomy.md` |
| Historical stabilization archive | `docs/archive/migration-phase-reports/README.md` |

## Ownership matrix

| Package | Owns | Must not own |
| --- | --- | --- |
| `staking/core` | Deployment IDs, address codecs, runtime operation context types | UI, refresh sessions, tx modals |
| `staking/runtime` | Runtime planes, runtime identity, selection wiring | Components, vault composer implementation |
| `staking/runtime/network` | Chain reconciliation, network switching, topology DEV markers | UI/components, vault composer implementation |
| `staking/execution` | On-chain reads, gas/fee presentation builders, passive Tron reads | React components, `staking/ui` |
| `staking/tx` | Tx session persistence, recovery, snapshot helpers | Page components, modal providers, `staking/refresh` internals |
| `staking/refresh` | Balance refresh orchestrator, notify/coalesce | UI surfaces, network reconciliation |
| `staking/orchestration` | Runtime swap, transition coordinator, unified wallet open | UI surfaces |
| `staking/history` | History keys, merge, EVM + Tron loaders | UI surfaces, network switching |
| `staking/identity` | Wallet identity resolution | Tx execution |
| `staking/vault/composer` | Wiring and public assembly only | Modal/provider JSX, network logic |
| `components/pages/staking` | App UX, forms, transaction status provider | Vault hook order, orchestrator internals |
| `staking/diagnostics` | DEV assertions, soak monitor, boundary rules | Production behavior |

## Dependency direction

`components/pages/staking` may consume the vault composer and presentation helpers. The vault composer may assemble runtime, execution, tx, refresh, history, orchestration, and selectors. Lower planes must not import upward into UI, page components, or composer internals.

Boundary checks live in `src/staking/diagnostics/stakingBoundaryRules.ts` and `eslint.config.js`. Treat them as the intended direction of travel, not a claim that every current import is already perfectly isolated. In particular, `staking/runtime/network` still has limited pragmatic coupling for toast/UI helpers and composer ref/DTO types; do not expand those exceptions without architecture review.

- `staking/runtime` must not import components, `staking/ui`, or vault composer.
- `staking/execution` must not import components or `staking/ui`.
- `staking/tx` must not import staking pages, `staking/ui`, or `staking/refresh/*`.
- `staking/refresh` and `staking/history` must not import `staking/runtime/network`.
- `staking/vault/composer` is composition only; it does not own provider/modal UI or network implementation.
- `src/staking/*` must not import retired `@/lib/staking/*` or `@/lib/tron/*` shims.

## Frozen topology (G4d)

Network implementation is centralized in `@/staking/runtime/network`; composer-local network glue remains retired. The current implementation still has narrow type/UI coupling noted above, so this freeze is an ownership target plus guardrail, not permission to add more cross-layer imports.

## Network and AppKit boundaries

AppKit owns WalletConnect sessions, adapter lifecycle, and connector state. The app owns UX orchestration and calls AppKit only from user gestures through the existing unified wallet flow.

Network glue is canonical in `@/staking/runtime/network`:

- Reconcile EVM chain before token meta load.
- Switch EVM chains through AppKit/network APIs exposed by runtime planes.
- Keep passive Tron network state separate from EVM execution state.
- Never publish passive Tron as an EVM execution chain.

The composer may call network glue only through fixed refresh-plane wiring. It must not reintroduce composer-local network implementations.

## Public vault API

`useStakingVault()` exposes execution and runtime-wallet planes, not legacy bridge aliases.

| Use case | Canonical field / hook |
| --- | --- |
| EVM signing address | `executionAddress` |
| EVM wallet connected | `executionConnected` |
| EVM chain | `executionChainId` |
| Tron / unified wallet | `runtimeWallet`, `runtimeWalletConnected`, `runtimeWalletAddress` |
| Active deployment / capabilities | `useActiveRuntimeSelection()` from `@/staking/core/runtimeSelectionContext` |

Removed bridge keys such as `address`, `isConnected`, `chainId`, and `activeRuntimeSelection` must not return on the public vault object.

## Identity and history ownership

| Concern | Owner |
| --- | --- |
| EVM AppKit identity | `staking/runtime`, `staking/orchestration` |
| Tron passive identity | `staking/identity/tron/tronWalletIdentity.ts` |
| Unified wallet open/connect UX | `staking/orchestration/openUnifiedWallet.ts` |
| Runtime selection | `staking/core` + runtime planes |
| History cache keys and merge | `staking/history` |
| EVM indexer reads | `staking/history` + `lib/stakingEtherscanHistory` |
| Tron history rows | `staking/history/tron/tronTransactionHistory.ts` |

## Review triggers

Architecture review is required before changing package ownership, adding a new runtime plane, changing AppKit adapter/network registration, reintroducing retired bridge fields, or changing hook order. Operational rules are in `staking-maintenance-rules.md`.
