# Staking runtime edge cases and lifecycle behavior

Canonical behavior reference for retry, continuity, mobile lifecycle, BFCache, and user-return flows. This document describes how the current runtime behaves under stress; it does not propose redesigns.

## Balance refresh and retry ownership

| Edge case | Behavior |
| --- | --- |
| Duplicate refresh sessions | Starting the orchestrator stops the previous session first. |
| Stale in-flight tick | Invalidation generation and abort controller cause the tick to bail. |
| Stale commit | Captured runtime/generation must pass commit gates before state update. |
| RPC latency | Single-flight execution, fast/slow floors, and semantic coalescing avoid request storms. |
| Reconnect storm | Refresh reasons are bitmasked/coalesced instead of one RPC per event. |
| Hidden tab / resume | `visibilitychange` and `pageshow` notify semantic refresh; hidden tabs may skip nonessential work. |

## Network and token meta races

Network glue runs before token meta load. Correct-chain reconciliation clears wrong-network meta and may reload token meta. Wrong EVM chain disables transact surfaces and drives CTA/toast state. Passive Tron clears EVM verification intervals and uses passive balance refetch on successful switch.

## History refresh

History loads use run ids, abort controllers, and `skipIfInFlight` for shallow/polling fetches. Resume events debounce for about 8 seconds to avoid foreground storms. Manual refresh may bypass `skipIfInFlight`, but the button is disabled while loading.

## Transaction lifecycle and detached flows

| Concern | Behavior |
| --- | --- |
| Dialog close on mobile | Radix `onOpenChange(false)` is non-authoritative; provider/user handlers own real closes. |
| Persistence | Active tx snapshots persist to `sessionStorage` with wallet, chain, and TTL guards. |
| Reload mid-flow | Hydration may restore the modal and reconcile with on-chain receipt state. |
| Identity drift | Account/chain mismatch clears or resets lifecycle instead of applying stale state. |
| Receipt polling | Tx recovery owns receipt checks; refresh only observes tx completion notifications. |
| Runtime swap during pending tx | Policy/coordinator gates prevent unsafe swaps; manual QA remains required for critical paths. |

## Signer hydration and AppKit return

Wallet app handoff can background the tab before signer hydration completes. The app observes signer hydration stalls and breadcrumbs, but does not repair AppKit sessions on boot or route mount. Any open/connect action must stay on the user-gesture stack.

## Safari, mobile, and BFCache

Mobile Safari and in-app browsers can preserve old page state through BFCache or kill/revive tabs around wallet deep links.

Expected behavior:

- `pageshow` with `persisted` follows the same semantic refresh path as visibility resume.
- Staking mobile resume diagnostics track visibility, pagehide/pageshow, freeze/resume, and return windows.
- The transaction modal remains controlled by `TransactionStatusProvider`, not browser focus churn.
- Splash/bootstrap waits for AppKit readiness and staking vault hydration on the staking app route.
- `sessionStorage` is per-tab; multi-tab divergence is a known limitation.

## Input and visual lifecycle

Amount input normalization handles zero-width characters, separator variants, bidi/Arabic digits, and mobile keyboard constraints. Staking inputs keep mobile font sizing high enough to avoid iOS zoom-on-focus.

Navbar wallet identity may visually hold through transient disconnect flicker; this is presentation behavior only and does not change runtime ownership.

## Manual QA minimum

Run on real devices for mobile wallet flows:

1. Connect, sign, switch to wallet app, and return on iOS Safari.
2. Repeat on Android Chrome with MetaMask or WalletConnect.
3. Reload during submitted/confirming state and verify restore/reconcile behavior.
4. Background and resume with stale balance/history.
5. Switch account or network during preview/pending flows and verify reset behavior.
