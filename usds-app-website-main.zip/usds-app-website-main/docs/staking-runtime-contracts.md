# Staking runtime ownership and tx continuity

Canonical runtime contracts for vault hook order, refresh ownership, transaction continuity, and async commit safety. This document defines **runtime sequencing and ownership**; architecture package boundaries live in `staking-domain-boundaries.md`.

## Runtime invariants

| Invariant | Owner / enforcement |
| --- | --- |
| Active deployment has a stable `RuntimeOperationContext` | Runtime context DEV assertions |
| Async commits validate captured vs latest runtime generation | `canRuntimeOperationCommit` / `canRuntimeOperationCommitWithDevTrace` |
| Passive Tron never exposes EVM executable surfaces | Runtime capability checks + diagnostics |
| History load key matches active deployment | History plane DEV assertion |
| Public vault object exposes no internal plane keys | Public topology assertions |

Runtime selection is in-memory. Reloads return to configured defaults unless product explicitly ships persisted selection.

## Vault composer hook order

The exact order is defined in `staking/vault/composer/stakingVaultComposerContracts.ts` and implemented by `useStakingVaultState`. This doc intentionally does not duplicate the full numbered sequence because the implementation includes runtime setup, composer refs, affiliate/identity selectors, diagnostics/lifecycle effects, chain mirrors, refresh, history, presentation, tx execution, and public assembly.

Invariant: do not reorder composer, refresh, history, diagnostics, network registration, or tx execution slots without a dedicated migration review. Reordering is a behavior change.

## Refresh plane registration order

`useStakingVaultRefreshPlane` must register these phases in order:

| Phase | Responsibility |
| --- | --- |
| `asset_lifecycle` | Asset lifecycle and token address resolution |
| `balance_callbacks` | Balance refresh callback wiring |
| `tron_ref_wiring` | Tron passive refetch refs |
| `reset_continuity` | Reset / continuity on runtime change |
| `network_glue` | Canonical `useStakingVaultNetworkGlue` from `@/staking/runtime/network` |
| `load_meta_mount` | Token meta mount load |
| `tx_notify` | Tx completion to balance notify |
| `orchestrator` | Balance refresh orchestrator session |
| `tron_polling` | Tron passive polling |

Network reconciliation must happen before `loadMeta`. Refresh owns balance orchestration, not network switching logic.

## Refresh orchestration

`startStakingRefreshOrchestrator` has a single active session per vault mount. New sessions stop the previous session, bump invalidation generation, and abort in-flight work. Ticks are gated by connection, chain correctness, asset resolution, visibility, and runtime commit checks.

Commit ownership is strict: captured runtime/generation must match the latest coordinator snapshot before UI state or balance data is committed.

## Runtime transition ownership

| Concern | Owner |
| --- | --- |
| Admission policy | `evaluateRuntimeSwapPolicy` |
| State mutation | `executeRuntimeSwap` |
| Sequence state | `runtimeTransitionSequence.ts` |
| Refresh/commit gates | `runtimeTransitionCoordinator.ts` |
| Execution identity for frozen tx work | `deriveRuntimeExecutionTarget` |

Direct runtime state mutation outside the swap engine is not supported.

## Transaction continuity

`components/pages/staking/TransactionStatusProvider` owns the UI snapshot lifecycle. `staking/tx` owns persistence, snapshot helpers, and on-chain recovery. The tx plane must not import page/provider implementations.

Operational rules:

- Detached or reloaded transactions hydrate from `sessionStorage` only when wallet, chain, and TTL guards pass.
- Modal state may outlive the originating render; commits must validate runtime identity before updating visible state.
- Receipt polling and on-chain recovery belong to tx helpers, not refresh orchestration.
- Balance refresh reacts to tx completion through the refresh notify path; it does not maintain a parallel tx status store.
- User rejection and wrong-network outcomes are terminal UX states, not AppKit/session repair triggers.

## Signer hydration

Signer hydration failures are observed and reported, and normal connect/open actions stay user-gesture driven through unified wallet orchestration. AppKit remains the primary owner of provider/session lifecycle.

Narrow destructive recovery exceptions exist for stale WalletConnect/AppKit session failures: global stale-session recovery, signer-hydration stale-session recovery, and tx-execution stale-session catch paths may invoke guarded reset/cleanup. These are defensive exception handlers, not normal reconnect/session ownership and not a replacement for AppKit restore.

## Public assembly contract

The public vault return shape is frozen by topology constants and DEV assertions. Internal refs, deprecated bridge keys, runtime-plane aliases, and implementation-only DTO fields must not leak into the returned object.

## Diagnostics and soak

DEV tools may assert these contracts without changing runtime paths:

- `window.__STAKING_ARCHITECTURE_SMOKE__`
- `window.__STAKING_ARCH_FREEZE__`
- runtime soak / torture / chaos flags in DEV builds only

Production debugging uses telemetry and Sentry taxonomy from `staking-sentry-event-taxonomy.md`.
