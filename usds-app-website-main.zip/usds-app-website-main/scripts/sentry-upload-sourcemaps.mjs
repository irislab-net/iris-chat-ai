/**
 * Optional post-build source map upload when SENTRY_AUTH_TOKEN is set.
 * Vite plugin handles upload during build when configured; this script is a CI fallback.
 */
import { execSync } from "node:child_process"
import { existsSync } from "node:fs"
import { dirname, join } from "node:path"
import { fileURLToPath } from "node:url"
import { resolveBuildRelease } from "./resolveBuildRelease.mjs"

const root = join(dirname(fileURLToPath(import.meta.url)), "..")
const distDir = join(root, "dist")

const authToken = process.env.SENTRY_AUTH_TOKEN?.trim()
const org = process.env.SENTRY_ORG?.trim()
const project = process.env.SENTRY_PROJECT?.trim()

if (!authToken || !org || !project) {
  console.log(
    "[sentry] Skipping source map upload (set SENTRY_AUTH_TOKEN, SENTRY_ORG, SENTRY_PROJECT)."
  )
  process.exit(0)
}

if (!existsSync(distDir)) {
  console.error("[sentry] dist/ not found — run pnpm build first.")
  process.exit(1)
}

const release = resolveBuildRelease(process.env)

execSync(
  `npx --yes @sentry/cli sourcemaps upload --org "${org}" --project "${project}" --release "${release}" "${distDir}"`,
  {
    cwd: root,
    stdio: "inherit",
    env: { ...process.env, SENTRY_AUTH_TOKEN: authToken },
  }
)

console.log(`[sentry] Uploaded source maps for release ${release}`)
