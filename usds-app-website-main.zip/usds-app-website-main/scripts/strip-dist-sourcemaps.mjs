import { existsSync, readdirSync, statSync, unlinkSync } from "node:fs"
import { join } from "node:path"

const dist = join(process.cwd(), "dist")

function walk(dir) {
  if (!existsSync(dir)) return
  for (const name of readdirSync(dir)) {
    const p = join(dir, name)
    if (statSync(p).isDirectory()) walk(p)
    else if (name.endsWith(".map")) unlinkSync(p)
  }
}

/** Remove .map files from dist when Sentry upload did not run (maps are not linked in bundles). */
if (!process.env.SENTRY_AUTH_TOKEN?.trim()) {
  walk(dist)
  console.log("[build] Removed dist/**/*.map (no SENTRY_AUTH_TOKEN — maps not uploaded).")
}
