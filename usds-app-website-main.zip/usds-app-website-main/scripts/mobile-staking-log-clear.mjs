import fs from "node:fs"
import path from "node:path"
import { fileURLToPath } from "node:url"

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..")
const logPath = path.join(root, ".local-debug", "mobile-staking.ndjson")

fs.mkdirSync(path.dirname(logPath), { recursive: true })
fs.writeFileSync(logPath, "", "utf8")
console.log(`Cleared ${logPath}`)
