import fs from "node:fs"
import path from "node:path"
import { fileURLToPath } from "node:url"

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..")
const logPath = path.join(root, ".local-debug", "mobile-staking.ndjson")

if (!fs.existsSync(logPath)) {
  console.error(`Log file not found: ${logPath}`)
  process.exit(1)
}

let offset = fs.statSync(logPath).size

function printNew() {
  const stat = fs.statSync(logPath)
  if (stat.size < offset) {
    offset = 0
  }
  if (stat.size <= offset) return
  const fd = fs.openSync(logPath, "r")
  const len = stat.size - offset
  const buf = Buffer.alloc(len)
  fs.readSync(fd, buf, 0, len, offset)
  fs.closeSync(fd)
  offset = stat.size
  process.stdout.write(buf.toString("utf8"))
}

printNew()
console.error(`Tailing ${logPath} (Ctrl+C to stop)`)
fs.watch(logPath, { persistent: true }, () => {
  try {
    printNew()
  } catch (err) {
    console.error(err)
  }
})
