export type BuildCorrelation = Readonly<{
  appBuildId: string
  viteBuildHash: string
  deploymentId: string
  runtimeAssetVersion: string
  release: string
}>

export function resolveBuildRelease(
  env?: Record<string, string | undefined>,
): string

export function resolveBuildCorrelation(
  env?: Record<string, string | undefined>,
): BuildCorrelation
