import { execSync } from "node:child_process"
import { readFileSync } from "node:fs"
import { dirname, join } from "node:path"
import { fileURLToPath } from "node:url"

const root = join(dirname(fileURLToPath(import.meta.url)), "..")

/**
 * Canonical Sentry release id: `wallet-landing@{version}+{shortSha}`.
 * Override with VITE_SENTRY_RELEASE in env when set.
 */
export function resolveBuildRelease(env = process.env) {
  const explicit = env.VITE_SENTRY_RELEASE?.trim()
  if (explicit) return explicit

  const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf8"))
  const version = pkg.version ?? "0.0.0"

  let sha =
    env.GITHUB_SHA?.trim() ||
    env.COMMIT_SHA?.trim() ||
    env.SENTRY_COMMIT_SHA?.trim() ||
    ""

  if (!sha) {
    try {
      sha = execSync("git rev-parse --short HEAD", {
        cwd: root,
        encoding: "utf8",
        stdio: ["ignore", "pipe", "ignore"],
      }).trim()
    } catch {
      sha = ""
    }
  } else if (sha.length > 12) {
    sha = sha.slice(0, 12)
  }

  return sha ? `wallet-landing@${version}+${sha}` : `wallet-landing@${version}`
}

/**
 * Deploy/runtime correlation ids injected at production build time (see `vite.config.ts`).
 * `deployment_id` here is the **frontend deploy** id (not staking chain deployment).
 */
export function resolveBuildCorrelation(env = process.env) {
  const release = resolveBuildRelease(env)
  const explicitBuildId = env.VITE_APP_BUILD_ID?.trim()
  let shortSha = ""
  const plusMatch = release.match(/\+([a-f0-9]+)$/i)
  if (plusMatch) shortSha = plusMatch[1]

  const appBuildId = explicitBuildId || shortSha || release
  const viteBuildHash =
    env.VITE_VITE_BUILD_HASH?.trim() ||
    env.VITE_BUILD_HASH?.trim() ||
    shortSha ||
    appBuildId
  const deploymentId =
    env.VITE_DEPLOYMENT_ID?.trim() ||
    env.CF_PAGES_DEPLOYMENT_ID?.trim() ||
    appBuildId
  const runtimeAssetVersion =
    env.VITE_RUNTIME_ASSET_VERSION?.trim() || release

  return { appBuildId, viteBuildHash, deploymentId, runtimeAssetVersion, release }
}
