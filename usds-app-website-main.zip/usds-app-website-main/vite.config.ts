import { sentryVitePlugin } from "@sentry/vite-plugin";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import path from "path";
import { visualizer } from "rollup-plugin-visualizer";
import { defineConfig, loadEnv } from "vite";
import { REQUIRED_ENV_KEYS } from "./src/config/envRequiredKeys";
import {
  resolveBuildCorrelation,
  resolveBuildRelease,
} from "./scripts/resolveBuildRelease.mjs";
import { mobileStakingLogDevPlugin } from "./vite/plugins/mobileStakingLogDevPlugin";
export default defineConfig(({ mode, command }) => {
  const analyze = mode === "analyze";
  const envSource = analyze ? "production" : mode;
  const env = loadEnv(envSource, process.cwd(), "");
  const devServer = command === "serve";
  const shouldValidate = mode === "production" && !analyze;

  const isProductionBundle = mode === "production" && !analyze;
  const sentryRelease = isProductionBundle ? resolveBuildRelease(env) : null;
  const buildCorrelation = isProductionBundle
    ? resolveBuildCorrelation(env)
    : null;
  const sentryAuthToken = process.env.SENTRY_AUTH_TOKEN?.trim();
  const sentryOrg = env.SENTRY_ORG?.trim() ?? process.env.SENTRY_ORG?.trim();
  const sentryProject =
    env.SENTRY_PROJECT?.trim() ?? process.env.SENTRY_PROJECT?.trim();
  const sentryUploadEnabled = Boolean(
    isProductionBundle &&
      env.VITE_SENTRY_DSN?.trim() &&
      sentryAuthToken &&
      sentryOrg &&
      sentryProject
  );

  return {
    define: isProductionBundle
      ? {
          "process.env.NODE_ENV": JSON.stringify("production"),
          ...(sentryRelease
            ? {
                "import.meta.env.VITE_SENTRY_RELEASE": JSON.stringify(
                  sentryRelease
                ),
              }
            : {}),
          ...(buildCorrelation
            ? {
                "import.meta.env.VITE_APP_BUILD_ID": JSON.stringify(
                  buildCorrelation.appBuildId
                ),
                "import.meta.env.VITE_BUILD_HASH": JSON.stringify(
                  buildCorrelation.viteBuildHash
                ),
                "import.meta.env.VITE_DEPLOYMENT_ID": JSON.stringify(
                  buildCorrelation.deploymentId
                ),
                "import.meta.env.VITE_RUNTIME_ASSET_VERSION": JSON.stringify(
                  buildCorrelation.runtimeAssetVersion
                ),
              }
            : {}),
        }
      : undefined,

    build: isProductionBundle
      ? {
          // Lit (Reown modal) ships a dev build unless NODE_ENV is production at bundle time.
          minify: "esbuild",
          sourcemap: "hidden",
        }
      : undefined,

    plugins: [
      react(),
      tailwindcss(),
      ...(devServer && !analyze ? [mobileStakingLogDevPlugin()] : []),
      ...(sentryUploadEnabled
        ? [
            sentryVitePlugin({
              org: sentryOrg!,
              project: sentryProject!,
              authToken: sentryAuthToken,
              release: {
                name: sentryRelease!,
              },
              sourcemaps: {
                assets: "./dist/**",
                filesToDeleteAfterUpload: ["./dist/**/*.map"],
              },
              telemetry: false,
            }),
          ]
        : []),
      ...(analyze
        ? [
            visualizer({
              filename: "dist/stats.html",
              gzipSize: true,
              brotliSize: true,
              template: "treemap",
            }),
          ]
        : []),
      {
        name: "validate-required-env",
        buildStart() {
          if (!shouldValidate) return;

          const missing = REQUIRED_ENV_KEYS.filter((key) => !env[key]?.trim());

          if (missing.length > 0) {
            throw new Error(
              `Missing required env vars for production build: ${missing.join(", ")}`,
            );
          }
        },
      },
    ],

    server: {
      port: 5173,
      strictPort: true,
    },

    resolve: {
      alias: {
        "@": path.resolve(__dirname, "./src"),
      },
    },
  };
});
