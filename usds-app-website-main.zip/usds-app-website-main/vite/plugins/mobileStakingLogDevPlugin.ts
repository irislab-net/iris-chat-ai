import fs from "node:fs"
import path from "node:path"
import type { Plugin, ViteDevServer } from "vite"
import { loadEnv } from "vite"

const LOG_REL = ".local-debug/mobile-staking.ndjson"
const POST_PATH = "/__mobile-staking-log"
const CLEAR_PATH = "/__mobile-staking-log/clear"

function logFilePath(root: string): string {
  return path.join(root, LOG_REL)
}

function ensureLogDir(root: string): void {
  const dir = path.dirname(logFilePath(root))
  fs.mkdirSync(dir, { recursive: true })
}

function appendNdjson(root: string, line: string): void {
  ensureLogDir(root)
  fs.appendFileSync(logFilePath(root), `${line}\n`, "utf8")
}

function clearLogFile(root: string): void {
  ensureLogDir(root)
  fs.writeFileSync(logFilePath(root), "", "utf8")
}

function readBody(req: import("node:http").IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    req.on("data", (c: Buffer) => chunks.push(c))
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")))
    req.on("error", reject)
  })
}

/**
 * DEV-only Vite middleware: accepts mobile staking NDJSON from the LAN device and
 * appends to `.local-debug/mobile-staking.ndjson`.
 */
export function mobileStakingLogDevPlugin(): Plugin {
  return {
    name: "mobile-staking-log-dev",
    apply: "serve",
    configureServer(server: ViteDevServer) {
      const env = loadEnv(server.config.mode, server.config.root, "")
      if (env.VITE_MOBILE_STAKING_LOGS !== "1") return

      server.middlewares.use(async (req, res, next) => {
        const url = req.url?.split("?")[0] ?? ""
        if (url !== POST_PATH && url !== CLEAR_PATH) {
          next()
          return
        }

        const root = server.config.root

        if (req.method === "OPTIONS") {
          res.statusCode = 204
          res.setHeader("Access-Control-Allow-Origin", "*")
          res.setHeader("Access-Control-Allow-Methods", "POST, DELETE, OPTIONS")
          res.setHeader("Access-Control-Allow-Headers", "Content-Type")
          res.end()
          return
        }

        if (url === CLEAR_PATH && (req.method === "DELETE" || req.method === "POST")) {
          try {
            clearLogFile(root)
            res.statusCode = 200
            res.setHeader("Content-Type", "application/json")
            res.setHeader("Access-Control-Allow-Origin", "*")
            res.end(JSON.stringify({ ok: true, cleared: true }))
          } catch (err) {
            res.statusCode = 500
            res.end(
              JSON.stringify({
                ok: false,
                error: err instanceof Error ? err.message : String(err),
              }),
            )
          }
          return
        }

        if (url === POST_PATH && req.method === "POST") {
          try {
            const raw = await readBody(req)
            const parsed = JSON.parse(raw) as Record<string, unknown>
            const event =
              typeof parsed.event === "string" ? parsed.event : "unknown_event"
            const record = {
              ...parsed,
              event,
              serverReceivedAt: Date.now(),
            }
            appendNdjson(root, JSON.stringify(record))
            res.statusCode = 204
            res.setHeader("Access-Control-Allow-Origin", "*")
            res.end()
          } catch (err) {
            res.statusCode = 400
            res.setHeader("Access-Control-Allow-Origin", "*")
            res.end(
              JSON.stringify({
                ok: false,
                error: err instanceof Error ? err.message : String(err),
              }),
            )
          }
          return
        }

        res.statusCode = 405
        res.end()
      })
    },
  }
}
